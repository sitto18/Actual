-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-01-2014 a las 20:43:35
-- Versión del servidor: 5.5.34
-- Versión de PHP: 5.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `dayz_origins`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `BugFix`()
BEGIN

	UPDATE `character_data` SET `Alive` = '0' WHERE `Inventory` = '[[],[]]' AND `Backpack` LIKE '%["",[[],[]],[[],[]]]%' AND `Alive` = '1';

	

  UPDATE `object_data` SET `Damage`='1' WHERE `Worldspace` NOT LIKE '[%,[%,%,%]]';

	UPDATE `object_data` SET `Damage`='1' WHERE `Hitpoints` NOT LIKE '%[["%' AND `Hitpoints` NOT LIKE '%[]%';

 

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pCleanup`()
BEGIN

	DELETE
	FROM object_data
	WHERE Damage = '1';

	DELETE
			FROM `object_data` 
			WHERE `ObjectUID` 
			NOT LIKE '0000%' 
			AND (	`Classname` NOT LIKE 'Tentstorage' AND 
					`Classname` NOT LIKE 'TentstorageR' AND 
					`Classname` NOT LIKE 'wooden_shed_lvl_1' AND 
					`Classname` NOT LIKE 'log_house_lvl_2' AND 
					`Classname` NOT LIKE 'wooden_house_lvl_3' AND 
					`Classname` NOT LIKE 'large_shed_lvl_1' AND 
					`Classname` NOT LIKE 'small_house_lvl_2' AND 
					`Classname` NOT LIKE 'big_house_lvl_3' AND 
					`Classname` NOT LIKE 'small_garage' AND 
					`Classname` NOT LIKE 'big_garage' AND 
					`Classname` NOT LIKE 'object_x');

	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500000393';
	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500000394';
	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500000395';

	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500001393';
	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500001394';
	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500001395';
	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500001396';
	DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500001397';

	INSERT INTO `object_data` 
			VALUES (NULL, '0000500001393', '1', 'UralCivil2', '0.05000', '0', '[180,[22462.2,19495.5,0]]', '[[[],[]],[[\"ItemAntibiotic\",\"ItemBandage\",\"ItemBloodbag\",\"ItemEpinephrine\",\"ItemMorphine\",\"ItemPainkiller\",\"FoodCanBakedBeans\",\"FoodCanFrankBeans\",\"FoodCanPasta\",\"FoodCanSardines\",\"ItemSodaCoke\",\"ItemSodaPepsi\",\"ItemHeatPack\"],[15,15,15,15,15,15,15,15,15,15,15,15,15]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[[\"motor\",0.8],[\"karoserie\",1],[\"palivo\",0.8],[\"wheel_1_1_steering\",1],[\"wheel_2_1_steering\",1],[\"wheel_1_2_steering\",1],[\"wheel_2_2_steering\",1]]', '0.01000', NOW());
	INSERT INTO `object_data` 
			VALUES (NULL, '0000500001394', '1', 'UralCivil2', '0.05000', '0', '[269,[22180.7,19833.1,0]]', '[[[\"ItemPickaxe\"],[2]],[[\"ItemBpt_b1\",\"ItemBpt_b2\",\"ItemBpt_h1\",\"ItemBpt_h2\",\"ItemBpt_g_s\",\"ItemBpt_g_b\",\"ItemBattery\",\"ItemPin\",\"ItemRocks\",\"ItemCementBag\",\"PartScrap\",\"PartWoodPile\",\"ItemCeMix\"],[3,3,3,3,3,1,7,7,15,5,10,15,3]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[[\"motor\",0.8],[\"karoserie\",1],[\"palivo\",0.8],[\"wheel_1_1_steering\",1],[\"wheel_2_1_steering\",1],[\"wheel_1_2_steering\",1],[\"wheel_2_2_steering\",1]]', '0.01000', NOW());
	INSERT INTO `object_data` 
			VALUES (NULL, '0000500001395', '1', 'UralCivil2', '0.05000', '0', '[90,[22452.8,20074.8,0]]', '[[[\"AKS_74_kobra\",\"M16A2GL\",\"AKS_74_U\",\"FN_FAL\",\"M9SD\",\"PK_DZ\",\"Pecheneg_DZ\",\"bizon_silenced\",\"M4A3_RCO_GL_EP1\",\"NVGoggles\",\"ItemGPS\",\"G36K\"],[3,3,3,3,3,3,3,3,3,2,2,1]],[[\"ItemBloodbag\",\"100Rnd_762x54_PK\",\"30Rnd_556x45_Stanag\",\"100Rnd_762x51_M240\",\"30Rnd_556x45_G36SD\",\"10Rnd_9x39_SP5_VSS\",\"ItemAntibiotic\",\"30Rnd_545x39_AK\",\"20Rnd_762x51_FNFAL\",\"15Rnd_9x19_M9SD\",\"64Rnd_9x19_SD_Bizon\",\"1Rnd_HE_GP25\",\"PartGeneric\",\"PartEngine\",\"PartGlass\",\"PartVRotor\",\"ItemJerrycan\",\"ItemTent\"],[10,10,10,10,10,10,10,10,10,10,10,10,4,2,6,2,10,2]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[[\"motor\",0.8],[\"karoserie\",1],[\"palivo\",0.8],[\"wheel_1_1_steering\",1],[\"wheel_2_1_steering\",1],[\"wheel_1_2_steering\",1],[\"wheel_2_2_steering\",1]]', '0.01000', NOW());
	INSERT INTO `object_data` 
			VALUES (NULL, '0000500001396', '1', 'UralCivil2', '0.05000', '0', '[178,[22533,20073,0]]', '[[[\"AKS_74_kobra\",\"M16A2GL\",\"AKS_74_U\",\"FN_FAL\",\"M9SD\",\"PK_DZ\",\"Pecheneg_DZ\",\"bizon_silenced\",\"M4A3_RCO_GL_EP1\",\"NVGoggles\",\"ItemGPS\",\"G36K\"],[3,3,3,3,3,3,3,3,3,2,2,1]],[[\"ItemBloodbag\",\"100Rnd_762x54_PK\",\"30Rnd_556x45_Stanag\",\"100Rnd_762x51_M240\",\"30Rnd_556x45_G36SD\",\"10Rnd_9x39_SP5_VSS\",\"ItemAntibiotic\",\"30Rnd_545x39_AK\",\"20Rnd_762x51_FNFAL\",\"15Rnd_9x19_M9SD\",\"64Rnd_9x19_SD_Bizon\",\"1Rnd_HE_GP25\",\"PartGeneric\",\"PartEngine\",\"PartGlass\",\"PartVRotor\",\"ItemJerrycan\",\"ItemTent\"],[10,10,10,10,10,10,10,10,10,10,10,10,4,2,6,2,10,2]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[[\"motor\",0.8],[\"karoserie\",1],[\"palivo\",0.8],[\"wheel_1_1_steering\",1],[\"wheel_2_1_steering\",1],[\"wheel_1_2_steering\",1],[\"wheel_2_2_steering\",1]]', '0.01000', NOW());
	INSERT INTO `object_data` 
			VALUES (NULL, '0000500001397', '1', 'UralCivil2', '0.05000', '0', '[178,[22549.2,20071.9,0]]', '[[[\"AKS_74_kobra\",\"M16A2GL\",\"AKS_74_U\",\"FN_FAL\",\"M9SD\",\"PK_DZ\",\"Pecheneg_DZ\",\"bizon_silenced\",\"M4A3_RCO_GL_EP1\",\"NVGoggles\",\"ItemGPS\",\"G36K\"],[3,3,3,3,3,3,3,3,3,2,2,1]],[[\"ItemBloodbag\",\"100Rnd_762x54_PK\",\"30Rnd_556x45_Stanag\",\"100Rnd_762x51_M240\",\"30Rnd_556x45_G36SD\",\"10Rnd_9x39_SP5_VSS\",\"ItemAntibiotic\",\"30Rnd_545x39_AK\",\"20Rnd_762x51_FNFAL\",\"15Rnd_9x19_M9SD\",\"64Rnd_9x19_SD_Bizon\",\"1Rnd_HE_GP25\",\"PartGeneric\",\"PartEngine\",\"PartGlass\",\"PartVRotor\",\"ItemJerrycan\",\"ItemTent\"],[10,10,10,10,10,10,10,10,10,10,10,10,4,2,6,2,10,2]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[[\"motor\",0.8],[\"karoserie\",1],[\"palivo\",0.8],[\"wheel_1_1_steering\",1],[\"wheel_2_1_steering\",1],[\"wheel_1_2_steering\",1],[\"wheel_2_2_steering\",1]]', '0.01000', NOW());

	
DELETE
			FROM `object_data`
			WHERE `ObjectUID` = '0000500000431';
	
	INSERT INTO `object_data` 
			VALUES (NULL, '0000500000431', '1', 'DC3', '0.05000', '0', '[1,[22687.3,19239.3,0]]', '[]', '[]', '1', NOW());

	
	DELETE
	FROM object_data
	WHERE DATE(Datestamp) < CURDATE() - INTERVAL 5 DAY
	AND Classname != 'Hedgehog_DZ'
	AND Classname != 'Wire_cat1'
	AND Classname != 'Sandbag1_DZ'
	AND Classname != 'TrapBear'
	AND Classname != 'TentStorage'
	AND Classname != 'TentStorageR' AND
	Classname != 'wooden_shed_lvl_1' AND 
	Classname != 'log_house_lvl_2' AND 
	Classname != 'wooden_house_lvl_3' AND 
	Classname != 'large_shed_lvl_1' AND 
	Classname != 'small_house_lvl_2' AND 
	Classname != 'big_house_lvl_3' AND 
	Classname != 'small_garage' AND 
	Classname != 'big_garage' AND 
	Classname != 'object_x';

	
	DELETE
		FROM `object_data`
		WHERE `Classname` = 'TentStorage'
			AND  DATE(Datestamp) < CURDATE() - INTERVAL 6 DAY;

	
	DELETE
	FROM object_data
	WHERE Classname = 'TentStorage'
	AND DATE(Datestamp) < CURDATE() - INTERVAL 7 DAY
	AND Inventory = '[[[],[]],[[],[]],[[],[]]]';

	DELETE
	FROM object_data
	WHERE Classname = 'TentStorage'
	AND DATE(Datestamp) < CURDATE() - INTERVAL 7 DAY
	AND Inventory = '[]';	

	DELETE
	FROM object_data
	WHERE Classname = 'TentStorageR'
	AND DATE(Datestamp) < CURDATE() - INTERVAL 7 DAY
	AND Inventory = '[[[],[]],[[],[]],[[],[]]]';

	DELETE
	FROM object_data
	WHERE Classname = 'TentStorageR'
	AND DATE(Datestamp) < CURDATE() - INTERVAL 7 DAY
	AND Inventory = '[]';

	
	DELETE
	FROM object_data
	WHERE Classname = 'Wire_cat1'
	AND DATE(Datestamp) <= CURDATE();

	
	DELETE
	FROM object_data
	WHERE Classname = 'Hedgehog_DZ'
	AND DATE(Datestamp) <= CURDATE();

	
	DELETE
	FROM object_data
	WHERE Classname = 'Sandbag1_DZ'
	AND DATE(Datestamp) <= CURDATE();

	
	DELETE
	FROM object_data
	WHERE Classname = 'TrapBear'
	AND DATE(Datestamp) <= CURDATE();

END$$

CREATE DEFINER=`root`@`` PROCEDURE `pCleanupOOB`()
BEGIN



	DECLARE intLineCount	INT DEFAULT 0;

	DECLARE intDummyCount	INT DEFAULT 0;

	DECLARE intDoLine			INT DEFAULT 0;

	DECLARE intWest				INT DEFAULT 0;

	DECLARE intNorth			INT DEFAULT 0;



	SELECT COUNT(*)

		INTO intLineCount

		FROM object_data;



	SELECT COUNT(*)

		INTO intDummyCount

		FROM object_data

		WHERE Classname = 'dummy';



	WHILE (intLineCount > intDummyCount) DO

	

		SET intDoLine = intLineCount - 1;



		SELECT ObjectUID, Worldspace

			INTO @rsObjectUID, @rsWorldspace

			FROM object_data

			LIMIT intDoLine, 1;



		SELECT REPLACE(@rsWorldspace, '[', '') INTO @rsWorldspace;

		SELECT REPLACE(@rsWorldspace, ']', '') INTO @rsWorldspace;

		SELECT REPLACE(SUBSTRING(SUBSTRING_INDEX(@rsWorldspace, ',', 2), LENGTH(SUBSTRING_INDEX(@rsWorldspace, ',', 2 -1)) + 1), ',', '') INTO @West;

		SELECT REPLACE(SUBSTRING(SUBSTRING_INDEX(@rsWorldspace, ',', 3), LENGTH(SUBSTRING_INDEX(@rsWorldspace, ',', 3 -1)) + 1), ',', '') INTO @North;



		SELECT INSTR(@West, '-') INTO intWest;

		SELECT INSTR(@North, '-') INTO intNorth;



		IF (intNorth = 0) THEN

			SELECT CONVERT(@North, DECIMAL(16,8)) INTO intNorth;

		END IF;

			

		SET intLineCount = intLineCount - 1;



	END WHILE;



END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pFixMaxNum`()
BEGIN

	DECLARE iCounter INT DEFAULT 0;

	SELECT COUNT(`Classname`) INTO @iClassesCount FROM `object_classes` WHERE Classname<>'';
	WHILE (iCounter < @iClassesCount) DO
		SELECT `Classname`, `MaxNum` INTO @Classname, @MaxNum FROM `object_classes` LIMIT iCounter,1;
		SELECT COUNT(`Classname`) INTO @iMaxClassSpawn FROM object_spawns WHERE `Classname` LIKE @Classname;
		IF (@MaxNum > @iMaxClassSpawn) THEN
			UPDATE `object_classes` SET MaxNum = @iMaxClassSpawn WHERE Classname = @Classname;
		END IF;
		SET iCounter = iCounter + 1;
	END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pMain`()
    MODIFIES SQL DATA
BEGIN

DECLARE sInstance VARCHAR(8) DEFAULT '1';

DECLARE iVehSpawnMax INT DEFAULT 387;

DECLARE iTimeoutMax INT DEFAULT 450; 
DECLARE iTimeout INT DEFAULT 0; 
DECLARE iNumVehExisting INT DEFAULT 0; 
DECLARE iNumClassExisting INT DEFAULT 0; 
DECLARE i INT DEFAULT 1; 


CALL pCleanup();

SELECT COUNT(*) 
	INTO iNumVehExisting
FROM object_data
	WHERE Instance = sInstance
		AND Classname != 'Hedgehog_DZ' 
		AND Classname != 'Wire_cat1' 
		AND Classname != 'Sandbag1_DZ' 
		AND Classname != 'TrapBear' 
		AND Classname != 'TentStorage' 
		AND Classname != 'TentStorageR' AND 
		Classname != 'wooden_shed_lvl_1' AND 
		Classname != 'log_house_lvl_2' AND 
		Classname != 'wooden_house_lvl_3' AND 
		Classname != 'large_shed_lvl_1' AND 
		Classname != 'small_house_lvl_2' AND 
		Classname != 'big_house_lvl_3' AND 
		Classname != 'small_garage' AND 
		Classname != 'big_garage' AND 
		Classname != 'object_x';

WHILE (iNumVehExisting < iVehSpawnMax) DO 

	
	SELECT Classname, Chance, MaxNum, Damage
	INTO @rsClassname, @rsChance, @rsMaxNum, @rsDamage
	FROM object_classes ORDER BY RAND() LIMIT 1;

	
	SELECT COUNT(*)
	INTO iNumClassExisting
	FROM object_data
	WHERE Instance = sInstance
	AND Classname = @rsClassname;

	IF (iNumClassExisting < @rsMaxNum) THEN
		IF (rndspawn(@rschance) = 1) THEN
			INSERT INTO object_data (ObjectUID, Instance, Classname, Damage, CharacterID, Worldspace, Inventory, Hitpoints, Fuel, Datestamp)
				SELECT OS.ObjectUID, '1', OC.Classname, RAND(@rsOC.Damage), NULL AS `CharacterID`, OS.Worldspace, '[]' AS `Inventory`, OC.Hitpoints, RAND(1), SYSDATE()
					FROM object_spawns OS
					INNER JOIN object_classes OC
					ON OS.Classname = OC.Classname
				WHERE OC.Classname = @rsClassname
				AND NOT OS.ObjectUID IN (SELECT ObjectUID FROM object_data WHERE instance = sInstance)
			ORDER BY RAND()
			LIMIT 0, 1;

			SELECT COUNT(*)
			INTO iNumVehExisting
			FROM object_data
			WHERE Instance = sInstance
			AND Classname != 'Hedgehog_DZ' 
			AND Classname != 'Wire_cat1' 
			AND Classname != 'Sandbag1_DZ' 
			AND Classname != 'TrapBear' 
			AND Classname != 'TentStorage' 
			AND Classname != 'TentStorageR' AND 
			Classname != 'wooden_shed_lvl_1' AND 
			Classname != 'log_house_lvl_2' AND 
			Classname != 'wooden_house_lvl_3' AND 
			Classname != 'large_shed_lvl_1' AND 
			Classname != 'small_house_lvl_2' AND 
			Classname != 'big_house_lvl_3' AND 
			Classname != 'small_garage' AND 
			Classname != 'big_garage' AND 
			Classname != 'object_x';	

			
			SELECT COUNT(*)
			INTO iNumClassExisting
			FROM object_data
			WHERE Instance = sInstance
			AND Classname = @rsClassname;

		END IF;
	END IF;	

	SET iTimeout = iTimeout + 1; 
	IF (iTimeout >= iTimeoutMax) THEN
		SET iNumVehExisting = iVehSpawnMax;
	END IF;
END WHILE;
SET i = i + 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pMoveDead`()
BEGIN
	
	DECLARE iNumVehExisting INT DEFAULT 0; 
	DECLARE iPlayerUID INT DEFAULT 1; 
	
	SELECT count(DISTINCT `PlayerUID`) 
		INTO @rsMaxNum
		FROM `character_data` 
		WHERE `Alive` = '0';
	
	WHILE (iPlayerUID < @rsMaxNum) DO
	
		SELECT DISTINCT `PlayerUID`
			INTO @nPlayerUID
			FROM `character_data` 
			WHERE `Alive` = '0' 
			ORDER BY `PlayerUID` LIMIT iPlayerUID,1;

		SELECT count(`PlayerUID`) 
			INTO @numPlayerUID
			FROM `character_data` 
			WHERE `Alive` = '0' 
			AND `PlayerUID`=@nPlayerUID;
		
		IF (@numPlayerUID>1) THEN 
			SELECT `CharacterID`
				INTO @nCharacterID
				FROM `character_data` 
				WHERE `Alive` = '0' 
				AND `PlayerUID`=@nPlayerUID  
				ORDER BY `Datetime` DESC LIMIT 1,1;
	
			INSERT INTO `character_data_dead` (CharacterID,PlayerUID,Alive,InstanceID,Worldspace,Inventory,Backpack,Medical,Generation,Datestamp,LastLogin,LastAte,LastDrank,Humanity,KillsZ,HeadshotsZ,distanceFoot,duration,currentState,KillsH,KillsB,Model,Datetime) 
				SELECT CharacterID,PlayerUID,Alive,InstanceID,Worldspace,Inventory,Backpack,Medical,Generation,Datestamp,LastLogin,LastAte,LastDrank,Humanity,KillsZ,HeadshotsZ,distanceFoot,duration,currentState,KillsH,KillsB,Model,Datetime 
				FROM `character_data` WHERE `Alive` = '0' AND `PlayerUID`=@nPlayerUID AND `CharacterID` <> @nCharacterID;
			
			DELETE FROM `character_data` WHERE `Alive` = '0' AND `PlayerUID`=@nPlayerUID AND `CharacterID` <> @nCharacterID; 
		END IF;
	SET iPlayerUID = iPlayerUID + 1;

	END WHILE;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pSpawn`()
BEGIN

    DECLARE bSpawned        TINYINT(1) DEFAULT 0;

    DECLARE iLID            INT DEFAULT 0;

    WHILE (bSpawned = 0) DO
        SET iLID = LAST_INSERT_ID();
        INSERT INTO `object_data` (ObjectUID, Instance,Classname, Damage, CharacterID, Worldspace, Inventory, Hitpoints, Fuel, Datestamp)
        SELECT ot.ObjectUID, '1', ot.Classname, ot.Damage, '0', ot.Worldspace, '[]', ot.Hitpoints, '0.01', SYSDATE()
            FROM (SELECT oc.Classname, oc.Chance, oc.MaxNum, oc.Damage, oc.Hitpoints, os.ObjectUID, os.Worldspace
                FROM object_classes AS oc
                INNER JOIN `object_spawns` AS os
                ON oc.Classname = os.Classname
                ORDER BY RAND()) AS ot
            WHERE NOT EXISTS (SELECT od.ObjectUID
                            FROM `object_data` AS od
                            WHERE ot.ObjectUID = od.ObjectUID)
            AND fGetClassCount(ot.Classname) < ot.MaxNum
            AND fGetSpawnFromChance(ot.Chance) = 1
            LIMIT 1;
          

            IF (LAST_INSERT_ID() <> iLID) THEN
                SET bSpawned = 1;
            END IF;
    END WHILE;
END$$

--
-- Funciones
--
CREATE DEFINER=`root`@`localhost` FUNCTION `fGetClassCount`(`clname` varchar(32)) RETURNS smallint(3)
    READS SQL DATA
BEGIN
	DECLARE iClassCount SMALLINT(3) DEFAULT 0;
	
	SELECT COUNT(`Classname`) 
		INTO iClassCount 
		FROM `object_data` 
		WHERE `Classname` = clname;
	RETURN iClassCount;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `fGetSpawnFromChance`(`chance` double) RETURNS tinyint(1)
    NO SQL
BEGIN
	DECLARE bspawn TINYINT(1) DEFAULT 0;
	IF (RAND() <= chance) THEN
		SET bspawn = 1;
	END IF;
	RETURN bspawn;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `fGetVehCount`() RETURNS int(3)
    READS SQL DATA
BEGIN
	DECLARE iVehCount	INT(3) DEFAULT 0;
	SELECT COUNT(`Classname`) 
		INTO iVehCount
		FROM `object_data` 
		WHERE `Classname` != 'dummy'
			AND `Classname` != 'TentStorage'  
			AND `Classname` != 'Hedgehog_DZ'	
			AND `Classname` != 'Wire_cat1'		
			AND `Classname` != 'Sandbag1_DZ'	
			AND `Classname` != 'TrapBear';		
	RETURN iVehCount;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `rndspawn`(`chance` double) RETURNS tinyint(1)
BEGIN

DECLARE bspawn tinyint(1) DEFAULT 0;

IF (RAND() <= chance) THEN
SET bspawn = 1;
END IF;

RETURN bspawn;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `character_data`
--

CREATE TABLE IF NOT EXISTS `character_data` (
  `CharacterID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PlayerUID` varchar(20) NOT NULL DEFAULT '',
  `Alive` tinyint(1) NOT NULL DEFAULT '1',
  `InstanceID` tinyint(2) NOT NULL,
  `Worldspace` varchar(128) NOT NULL DEFAULT '[]',
  `Inventory` longtext NOT NULL,
  `Backpack` longtext NOT NULL,
  `Medical` varchar(300) NOT NULL DEFAULT '[]',
  `Generation` smallint(4) unsigned NOT NULL DEFAULT '0',
  `Datestamp` timestamp NULL DEFAULT NULL,
  `LastLogin` timestamp NULL DEFAULT NULL,
  `LastAte` timestamp NULL DEFAULT NULL,
  `LastDrank` timestamp NULL DEFAULT NULL,
  `Humanity` int(10) DEFAULT NULL,
  `KillsZ` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `HeadshotsZ` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `distanceFoot` bigint(15) unsigned NOT NULL DEFAULT '0',
  `duration` int(10) NOT NULL DEFAULT '0',
  `currentState` varchar(128) NOT NULL DEFAULT '[]',
  `KillsH` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `KillsB` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `Model` varchar(50) NOT NULL DEFAULT '"Survivor1_DZ"',
  `Datetime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`CharacterID`,`PlayerUID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

--
-- Volcado de datos para la tabla `character_data`
--

INSERT INTO `character_data` (`CharacterID`, `PlayerUID`, `Alive`, `InstanceID`, `Worldspace`, `Inventory`, `Backpack`, `Medical`, `Generation`, `Datestamp`, `LastLogin`, `LastAte`, `LastDrank`, `Humanity`, `KillsZ`, `HeadshotsZ`, `distanceFoot`, `duration`, `currentState`, `KillsH`, `KillsB`, `Model`, `Datetime`) VALUES
(1, '159122886', 0, 1, '[7,[13197.9,16653.1,0.002]]', '[["ItemFlashlight","ItemEtool","ItemKnife","ItemWatch","Binocular","ItemMap","ItemToolbox","ItemPickaxe","ItemGPS","Makarov","ItemHatchet","bizon_silenced"],[["64Rnd_9x19_SD_Bizon",58],["64Rnd_9x19_SD_Bizon",57],["64Rnd_9x19_SD_Bizon",63],"FoodCanFrankBeans","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,false,false,true,60,["aimpoint"],[0.799,0],0,[1981.73,326.19]]', 1, '2014-01-15 19:41:53', '2014-01-17 17:12:54', '2014-01-15 19:41:53', '2014-01-15 19:41:53', 4000, 119, 0, 209879, 369, '["","amovpercmstpsnonwnondnon_amovppnemstpsnonwnondnon",42]', 0, 0, 'Hero1_5DZ', '2014-01-17 17:13:00'),
(2, '159165638', 0, 1, '[256,[9205.37,6517.02,0]]', '[["ItemFlashlight","ItemEtool","ItemKnife","ItemWatch","ItemToolbox","ItemGPS","ItemMap","FN_FAL","Colt1911","ItemPickaxe","ItemHatchet"],["ItemJerrycan","ItemJerrycanBEmpty","ItemBandage","ItemBandage",["7Rnd_45ACP_1911",1],["7Rnd_45ACP_1911",5],["7Rnd_45ACP_1911",6],["7Rnd_45ACP_1911",6],["7Rnd_45ACP_1911",6],"ItemBandage"]]', '["DZ_CivilBackpack_EP1",[[],[]],[["ItemBandage","7Rnd_45ACP_1911","8Rnd_9x18_Makarov"],[1,2,2]]]', '[false,false,false,false,false,false,true,10750,[],[0.419,0],0,[957.945,614.779]]', 1, '2014-01-15 19:41:55', '2014-01-18 00:24:16', '2014-01-15 19:41:55', '2014-01-15 19:41:55', 2500, 23, 0, 96163, 254, '["","",42]', 0, 0, 'Survivor8_2DZ', '2014-01-18 00:24:16'),
(3, '159122886', 0, 1, '[344,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov"],["ItemWaterbottle",["8Rnd_9x18_Makarov",7],"8Rnd_9x18_Makarov","8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,11150,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[5.447,0],0,[220.499,291.698]]', 2, '2014-01-17 17:14:23', '2014-01-17 17:44:50', '2014-01-17 17:14:23', '2014-01-17 17:14:23', 4000, 1, 0, 29005, 0, '["","aidlpercmstpsnonwnondnon_player_idlesteady01",100]', 0, 0, 'Hero1_6DZ', '2014-01-17 17:45:21'),
(4, '159122886', 0, 1, '[277,[6066.18,10043.5,0]]', '[["ItemFlashlight","Makarov","ItemHatchet","ItemPickaxe","ItemToolbox","SVD_CAMO","ItemRadio","ItemMap","ItemCompass"],["10Rnd_762x54_SVD","FoodCanBakedBeans","ItemSodaCoke","30Rnd_556x45_Stanag","ItemSodaCoke","ItemSodaCoke","FoodCanBakedBeans","Skin_Survivor2_DZ","8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,false,false,false,false,false,true,8650,[],[0.147,0],0,[583.042,602.553]]', 3, '2014-01-17 17:46:40', '2014-01-17 21:37:15', '2014-01-17 17:46:40', '2014-01-17 17:46:40', 4055, 2, 0, 65907, 12, '["","",42]', 0, 1, 'Sniper1_DZ', '2014-01-17 21:37:15'),
(5, '162616006', 0, 1, '[68,[13199.2,16653.9,0.002]]', '[["ItemFlashlight","ItemFlashlightRed","ItemWatch","Binocular","ItemCompass","ItemMatchbox","ItemMap","ItemKnife","BAF_L85A2_UGL_ACOG","ItemPickaxe","ItemEtool","ItemHatchet","ItemToolbox"],["ItemSodaPepsi",["30Rnd_556x45_Stanag",14],"FoodCanFrankBeans","ItemSodaPepsi","ItemJerrycanEmpty","PartGeneric","Skin_Sniper1_DZ","8Rnd_9x18_MakarovSD","8Rnd_9x18_MakarovSD","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage","ItemBandage","ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[["huntingrifle","ItemCompass"],[1,1]],[["FoodCanFrankBeans","FoodCanSardines","5x_22_LR_17_HMR"],[1,2,2]]]', '[false,false,false,true,true,false,true,8510,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[3.75,0],0,[296.425,559.864]]', 1, '2014-01-17 22:02:08', '2014-01-18 20:21:57', '2014-01-17 22:02:08', '2014-01-17 22:02:08', 2315, 17, 0, 73417, 85, '["","aidlpercmstpsnonwnondnon_player_idlesteady04",42]', 1, 2, 'Survivor2_DZ', '2014-01-18 20:22:26'),
(6, '159122886', 0, 1, '[25,[9208.41,6510.11,0]]', '[["ItemFlashlight","M4A1_HWS_GL_SD_Camo","ItemWatch","ItemToolbox","Binocular","Makarov","ItemEtool","ItemKnife","ItemMap","ItemPickaxe","ItemHatchet"],["ItemJerrycanBEmpty","ItemJerrycanEmpty","ItemBandage","ItemBandage","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,false,false,false,true,11830,[],[0,0],0,[406.363,393.902]]', 4, '2014-01-17 22:02:08', '2014-01-18 00:24:16', '2014-01-17 22:02:08', '2014-01-17 22:02:08', 4055, 24, 0, 39033, 4, '["","",42]', 0, 0, 'Hero1_1DZ', '2014-01-18 00:24:16'),
(13, '159122886', 0, 1, '[87,[13198.3,16653.699,0.002]]', '[["ItemFlashlight","Makarov","ItemToolbox","ItemCompass","ItemHatchet","ItemKnife","ItemPickaxe","ItemEtool","LeeEnfield","Binocular","ItemMap"],["10x_303","FoodCanFrankBeans","FoodCanSardines","ItemBandage",["8Rnd_9x18_Makarov",2],"ItemBandage",["8Rnd_9x18_Makarov",7],["8Rnd_9x18_Makarov",7],["8Rnd_9x18_Makarov",5],"8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,true,false,true,true,false,true,8860,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[17.482,0],5,[314.262,10.791]]', 8, '2014-01-18 19:36:09', '2014-01-18 22:33:39', '2014-01-18 19:36:09', '2014-01-18 19:36:09', 4075, 16, 0, 59593, 126, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",42]', 0, 0, 'Hero1_2DZ', '2014-01-18 22:33:47'),
(7, '159122886', 0, 1, '[246,[13197.9,16653,7.935e-04]]', '[["ItemFlashlight","ItemFlashlightRed","ItemToolbox","ItemKnife","ItemEtool","ItemPickaxe","Binocular","Sa61_EP1","ItemWatch","G36C","ItemMap","ItemCompass","ItemRadio"],["30Rnd_556x45_Stanag","ItemSodaCoke","ItemSodaCoke","ItemBpt_h3","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage"]]', '["DZ_CivilBackpack_EP1",[["M4A3_CCO_EP1"],[1]],[[],[]]]', '[false,false,false,true,true,false,true,7960,["aimpoint","lelbow","LeftFoot","pilot"],[9.632,0],0,[1218.97,3.792]]', 5, '2014-01-18 00:31:27', '2014-01-18 17:07:28', '2014-01-18 00:31:27', '2014-01-18 00:31:27', 4055, 26, 0, 260887, 259, '["","amovppnemstpsnonwnondnon",42]', 0, 0, 'Hero1_6DZ', '2014-01-18 17:07:46'),
(8, '159165638', 0, 1, '[28,[13199.2,16653.9,0.002]]', '[["ItemFlashlight","Makarov","ItemEtool","ItemToolbox","ItemCompass","ItemMap","ItemRadio","ItemHatchet","ItemPickaxe","ItemWatch"],["ItemBpt_h1","ItemBandage","17Rnd_9x19_glock17","6Rnd_45ACP","6Rnd_45ACP",["8Rnd_9x18_Makarov",1],["8Rnd_9x18_Makarov",4],"ItemBandage"]]', '["DZ_CivilBackpack_EP1",[[],[]],[["ItemSodaPepsi"],[2]]]', '[false,false,false,true,true,false,true,8770,["aimpoint","lelbow","relbow","RightFoot","neck","pilot"],[7.493,0],0,[282.004,368.725]]', 2, '2014-01-18 00:33:11', '2014-01-18 18:44:46', '2014-01-18 00:33:11', '2014-01-18 00:33:11', 2520, 11, 0, 63210, 152, '["","amovppnemstpsnonwnondnon",42]', 0, 0, 'Sniper1_DZ', '2014-01-18 18:45:04'),
(11, '159122886', 0, 1, '[135,[13198.2,16652.699,0.002]]', '[["ItemFlashlight","UZI_EP1","ItemHatchet","ItemWatch"],["FoodCanBakedBeans","FoodCanBakedBeans","200Rnd_556x45_M249","30Rnd_556x45_Stanag","30Rnd_556x45_Stanag","30Rnd_762x39_AK47","ItemPainkiller","2Rnd_shotgun_74Slug","ItemSodaPepsi","ItemBandage",["30Rnd_9x19_UZI",20],"30Rnd_9x19_UZI","ItemBandage","ItemBandage","6Rnd_45ACP"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,12000,["aimpoint","relbow","neck","pilot"],[0,0],0,[272.6,289.652]]', 7, '2014-01-18 19:02:13', '2014-01-18 19:34:39', '2014-01-18 19:02:13', '2014-01-18 19:02:13', 4055, 15, 0, 55941, 12, '["","amovppnemstpsnonwnondnon",42]', 0, 0, 'Hero1_7DZ', '2014-01-18 19:34:48'),
(9, '159122886', 0, 1, '[141,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov","ItemMap","ItemWatch","ItemHatchet","ItemEtool","ItemPickaxe","ItemToolbox"],["ItemWaterbottle","FoodCanFrankBeans","ItemSodaCoke","ItemBandage","ItemBandage","ItemBandage","15Rnd_9x19_M9"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,11400,["aimpoint","lelbow","relbow","RightFoot","neck","pilot"],[12.399,0],0,[217.175,234.944]]', 6, '2014-01-18 17:09:14', '2014-01-18 18:44:33', '2014-01-18 17:09:14', '2014-01-18 17:09:14', 4055, 4, 0, 27658, 31, '["","aidlpercmstpsnonwnondnon_player_idlesteady04",42]', 0, 0, 'Hero1_2DZ', '2014-01-18 18:45:03'),
(10, '159165638', 0, 1, '[314,[13197.9,16653,0.001]]', '[["ItemFlashlight","Makarov"],["ItemBandage","ItemPainkiller","8Rnd_9x18_Makarov"]]', '["",[],[]]', '[false,false,true,true,true,false,true,440,["aimpoint","neck","pilot"],[6.989,0],0,[0,0]]', 3, '2014-01-18 19:01:12', '2014-01-18 19:16:32', '2014-01-18 19:01:12', '2014-01-18 19:01:12', 2520, 0, 0, 13724, 4, '["","aidlpercmstpsnonwnondnon_player_idlesteady03",36]', 0, 0, 'Survivor2_1DZ', '2014-01-18 19:16:39'),
(12, '159165638', 0, 1, '[203,[13197.9,16653,9.766e-04]]', '[["ItemFlashlight","ItemWatch","ItemMap","ItemRadio","ItemHatchet","ItemEtool","ItemPickaxe","Makarov","ItemKnife","ItemToolbox","M249_DZ"],["ItemBandage","ItemBandage","ItemBandage","ItemBandage","ItemBandage","6Rnd_45ACP","6Rnd_45ACP","17Rnd_9x19_glock17","200Rnd_556x45_M249"]]', '["",[[],[]],[[],[]]]', '[false,true,false,true,true,false,true,720,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[7.243,0],5,[289.756,194.184]]', 4, '2014-01-18 19:23:21', '2014-01-19 12:26:15', '2014-01-18 19:23:21', '2014-01-18 19:23:21', 2840, 20, 0, 61349, 119, '["","aidlpercmstpsnonwnondnon_player_idlesteady04",42]', 0, 0, 'Survivor4_2DZ', '2014-01-19 12:26:31'),
(14, '162616006', 0, 1, '[18,[13197.1,16651.801,0.003]]', '[["Binocular"],["FoodCanSardines","ItemSodaCoke"]]', '["",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,11100,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[49.72,0],0,[835.031,536.265]]', 2, '2014-01-18 20:24:03', '2014-01-18 22:33:39', '2014-01-18 20:24:03', '2014-01-18 20:24:03', 2615, 9, 0, 39543, 5, '["","amovppnemstpsnonwnondnon",100]', 0, 0, 'Survivor2_DZ', '2014-01-18 22:33:53'),
(15, '159122886', 0, 1, '[129,[13197.9,16653,0.002]]', '[["ItemFlashlight","ItemMap","ItemRadio","ItemToolbox","ItemKnife","ItemEtool","ItemWatch","Binocular","ItemPickaxe","ItemHatchet","Colt1911","M4A3_CCO_EP1"],["30Rnd_556x45_G36","ItemPainkiller","ItemSodaCoke","FoodCanSardines","ItemBandage","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","7Rnd_45ACP_1911","ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,false,false,true,12000,["Pelvis","aimpoint"],[0,0],0,[117.34,24.053]]', 9, '2014-01-18 22:35:07', '2014-01-21 23:11:27', '2014-01-18 22:35:07', '2014-01-18 22:35:07', 6285, 122, 0, 363453, 432, '["","aidlpercmstpsnonwnondnon_player_idlesteady01",42]', 0, 6, 'Sniper1_DZ', '2014-01-21 23:11:35'),
(16, '162616006', 0, 1, '[311,[5305.91,7173.73,6.714e-04]]', '[["ItemFlashlight","ItemToolbox","ItemMatchbox","ItemCompass","ItemEtool","ItemFlashlightRed","ItemHatchet","ItemKnife","ItemPickaxe","ItemWatch","Binocular","ItemMap","ItemRadio","Colt1911","BAF_L85A2_UGL_ACOG"],[["30Rnd_556x45_Stanag",21],["30Rnd_556x45_Stanag",3],["30Rnd_556x45_Stanag",29],"30Rnd_556x45_Stanag","30Rnd_556x45_StanagSD","ItemSodaCoke","ItemSodaCoke","ItemSodaCoke","ItemSodaCoke","FoodCanPasta","FoodCanPasta","ItemPainkiller","ItemBandage",["7Rnd_45ACP_1911",4],["7Rnd_45ACP_1911",6],["7Rnd_45ACP_1911",6],["7Rnd_45ACP_1911",6],["7Rnd_45ACP_1911",6],["7Rnd_45ACP_1911",6]]]', '["DZ_ALICE_Pack_EP1",[["M4A3_CCO_EP1"],[1]],[["FoodSteakRaw","FoodCanBakedBeans","ItemSodaCoke","FoodCanSardines","FoodCanPasta","ItemBpt_b3","HandGrenade_East","ItemMorphine"],[1,1,1,2,1,1,2,1]]]', '[false,false,false,false,false,false,true,10580,[],[0,0],0,[816.499,469.603]]', 3, '2014-01-18 22:35:23', '2014-01-22 20:53:47', '2014-01-18 22:35:23', '2014-01-18 22:35:23', 3085, 32, 0, 75635, 146, '["BAF_L85A2_UGL_ACOG","amovpercmevasraswrfldf",42]', 0, 6, 'Sniper1_DZ', '2014-01-22 20:53:47'),
(19, '159122886', 0, 1, '[339,[3097.52,6719.23,0.001]]', '[["ItemFlashlight","Makarov"],["ItemPainkiller","ItemBandage","8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,false,false,false,false,false,false,12000,[],[0,0],0,[13.92,22.596]]', 10, '2014-01-21 23:29:12', '2014-01-22 00:10:48', '2014-01-21 23:29:12', '2014-01-21 23:29:12', 6285, 0, 0, 14363, 1, '["Makarov","actspercmstpsnonwpstdnon_suicide1b",100]', 0, 0, 'Survivor3_DZ', '2014-01-22 00:10:48'),
(17, '159165638', 0, 1, '[169,[13197.9,16653,0.001]]', '[["ItemFlashlight","Binocular","ItemKnife","ItemEtool","ItemWatch","Colt1911","M4A1_Aim","ItemToolbox","ItemHatchet","ItemMap","ItemPickaxe","ItemRadio","Binocular_Vector"],["30Rnd_556x45_Stanag","ItemSodaPepsi",["HandRoadFlare",5],"ItemBandage","ItemBandage","7Rnd_45ACP_1911","ItemBandage","ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[["ItemRocks","HandRoadFlare","15Rnd_W1866_Slug","10x_303"],[15,2,1,1]]]', '[false,false,false,true,true,false,true,11700,["Pelvis","aimpoint","relbow","RightFoot","LeftFoot","neck"],[2.811,0],0,[1693.91,549.915]]', 5, '2014-01-19 12:27:52', '2014-01-19 16:06:37', '2014-01-19 12:27:52', '2014-01-19 12:27:52', 2840, 3, 0, 48652, 37, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",41]', 0, 0, 'Sniper1_DZ', '2014-01-19 16:06:59'),
(20, '159122886', 0, 1, '[40,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov"],["ItemPainkiller","ItemBandage","8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,false,false,false,false,false,false,12000,[],[0,0],0,[18.905,31.687]]', 11, '2014-01-22 00:18:34', '2014-01-22 14:28:25', '2014-01-22 00:18:34', '2014-01-22 00:18:34', 6285, 0, 0, 11917, 3, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",38]', 0, 0, 'Hero1_6DZ', '2014-01-22 14:28:33'),
(18, '159165638', 0, 1, '[135,[13197.9,16653,0.002]]', '[["Makarov","ItemToolbox","Binocular_Vector","ItemWatch","ItemRadio","ItemPickaxe","ItemMap","ItemKnife","ItemHatchet","ItemEtool","ItemCompass","ItemFlashlightRed","AKS_74_pso"],["8Rnd_9x18_Makarov","ItemBandage","ItemBandage","30Rnd_545x39_AK","30Rnd_545x39_AK","30Rnd_545x39_AK","8Rnd_9x18_MakarovSD"]]', '["DZ_ALICE_Pack_EP1",[["ItemHatchet","ItemPickaxe"],[1,1]],[["FoodCanBakedBeans","ItemSodaCoke"],[1,1]]]', '[false,true,false,true,true,false,true,8840,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[1.279,0],5,[553.073,284.994]]', 6, '2014-01-19 16:08:39', '2014-01-24 18:52:51', '2014-01-19 16:08:39', '2014-01-19 16:08:39', 3360, 42, 0, 193054, 375, '["","aidlpercmstpsnonwnondnon_player_idlesteady03",42]', 0, 1, 'Sniper1_DZ', '2014-01-24 18:53:33'),
(21, '159122886', 0, 1, '[287,[5162.95,7209.71,0.002]]', '[["ItemFlashlight","Makarov","ItemMatchbox","ItemWatch","ItemToolbox"],["FoodCanFrankBeans","FoodCanFrankBeans","ItemPainkiller","FoodCanBakedBeans","FoodCanBakedBeans","ItemBattery","100Rnd_762x51_M240","100Rnd_762x51_M240","ItemPin","8Rnd_9x18_MakarovSD","8Rnd_9x18_MakarovSD","8Rnd_9x18_MakarovSD",["8Rnd_9x18_Makarov",2],["8Rnd_9x18_Makarov",1]]]', '["CZ_VestPouch_EP1",[[],[]],[["8Rnd_9x18_Makarov","ItemPainkiller","ItemSodaPepsi"],[1,3,2]]]', '[false,true,false,true,true,false,true,4900,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","pilot"],[10.479,0],5,[476.144,684.288]]', 12, '2014-01-22 20:16:50', '2014-01-22 20:57:27', '2014-01-22 20:16:50', '2014-01-22 20:16:50', 6290, 7, 0, 20661, 0, '["Makarov","",41]', 0, 0, 'Hero1_2DZ', '2014-01-22 20:57:27'),
(24, '159122886', 0, 1, '[311,[13197.6,16653.199,0.001]]', '[["ItemFlashlight","Makarov"],["ItemBandage","ItemPainkiller","8Rnd_9x18_Makarov"]]', '["",[],[]]', '[false,false,false,true,true,false,true,10350,["Pelvis","aimpoint","lelbow","relbow","neck","pilot"],[0,0],0,[26.667,51.094]]', 14, '2014-01-22 21:03:03', '2014-01-22 21:06:54', '2014-01-22 21:03:03', '2014-01-22 21:03:03', 6290, 0, 0, 27709, 0, '["","amovppnemstpsnonwnondnon",39]', 0, 0, 'Hero1_4DZ', '2014-01-22 21:07:06'),
(22, '162616006', 1, 1, '[217,[18501.699,8354.41,-2.17e-05]]', '[["ItemFlashlight","ItemMap","ItemRadio","ItemWatch","ItemToolbox","ItemKnife","ItemFlashlightRed","ItemEtool","ItemCompass","ItemMatchbox","Binocular_Vector","BAF_L85A2_UGL_ACOG","ItemPickaxe","Colt1911","ItemHatchet"],["30Rnd_556x45_Stanag","30Rnd_556x45_Stanag","ItemSodaCoke","ItemBandage","ItemBandage","ItemBandage","7Rnd_45ACP_1911","7Rnd_45ACP_1911","7Rnd_45ACP_1911","30Rnd_556x45_Stanag","30Rnd_556x45_Stanag","ItemBpt_h3","ItemBloodbag","FoodCanBakedBeans","20Rnd_762x51_FNFAL","ItemSodaCoke","ItemSodaCoke","ItemSodaCoke"]]', '["DZ_ALICE_Pack_EP1",[["Binocular_Vector","FN_FAL_ANPVS4"],[1,1]],[[],[]]]', '[false,false,false,false,false,false,true,9572,[],[0.421,0],0,[371.923,70.658]]', 4, '2014-01-22 20:55:20', '2014-01-29 20:29:25', '2014-01-22 20:55:20', '2014-01-22 20:55:20', 6085, 81, 0, 113946, 244, '["BAF_L85A2_UGL_ACOG","aidlpercmstpsraswrfldnon_idlesteady04",38]', 0, 15, 'Sniper1_DZ', '2014-01-29 20:55:11'),
(23, '159122886', 0, 1, '[70,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov"],["ItemPainkiller","ItemBandage","8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,10800,["Pelvis","aimpoint","lelbow","LeftFoot","neck","pilot"],[0.888,0],0,[17.6,27.995]]', 13, '2014-01-22 20:59:00', '2014-01-22 21:01:40', '2014-01-22 20:59:00', '2014-01-22 20:59:00', 6290, 0, 0, 27760, 0, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",38]', 0, 0, 'Hero1_7DZ', '2014-01-22 21:01:49'),
(25, '159122886', 0, 1, '[117,[13197.9,16653,0.002]]', '[["ItemFlashlight","ItemToolbox","ItemWatch","ItemMatchbox","ItemMap","ItemRadio","ItemKnife","MakarovSD"],["ItemBandage","ItemBandage","ItemBandage","ItemBandage","8Rnd_9x18_MakarovSD","8Rnd_9x18_MakarovSD",["8Rnd_9x18_Makarov",6],["8Rnd_9x18_Makarov",3]]]', '["",[[],[]],[[],[]]]', '[false,false,false,false,false,false,true,11250,[],[0.475,0],0,[1661.57,1022.94]]', 15, '2014-01-22 21:08:18', '2014-01-23 20:16:22', '2014-01-22 21:08:18', '2014-01-22 21:08:18', 6590, 22, 0, 57944, 100, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",42]', 0, 0, 'Sniper1_DZ', '2014-01-23 20:16:32'),
(26, '159122886', 0, 1, '[63,[13197.9,16653,0.002]]', '[["ItemFlashlight","ItemMap","ItemRadio","ItemCompass","Binocular","ItemMatchbox","ItemKnife","MakarovSD","ItemWatch","ItemToolbox","FN_FAL_ANPVS4"],["Skin_Survivor2_DZ",["20Rnd_762x51_FNFAL",18],"17Rnd_9x19_glock17"]]', '["",[[],[]],[[],[]]]', '[false,false,false,false,true,false,true,1720,[],[10.309,0],0,[375.045,539.791]]', 16, '2014-01-23 20:17:56', '2014-01-23 21:08:27', '2014-01-23 20:17:56', '2014-01-23 20:17:56', 6490, 13, 0, 21619, 0, '["","amovppnemstpsnonwnondnon",41]', 0, 0, 'Sniper1_DZ', '2014-01-23 21:09:49'),
(40, '159122886', 0, 1, '[43,[13198,16653,0.002]]', '[["ItemFlashlight","Makarov","ItemFlashlightRed","ItemKnife","bizon_silenced","ItemPickaxe","ItemCompass","ItemMap","ItemRadio","ItemToolbox","ItemEtool"],["ItemPainkiller",["64Rnd_9x19_SD_Bizon",5],"ItemSodaPepsi","64Rnd_9x19_Bizon","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage","8Rnd_9x18_Makarov","ItemBandage"]]', '["CZ_VestPouch_EP1",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,8980,["Pelvis","aimpoint","pilot"],[0.707,0],0,[836.508,739.182]]', 26, '2014-01-28 19:58:14', '2014-01-28 21:36:19', '2014-01-28 19:58:14', '2014-01-28 19:58:14', 8440, 24, 0, 32457, 0, '["","amovppnemstpsnonwnondnon",42]', 0, 1, 'Hero2_4DZ', '2014-01-28 21:36:34'),
(27, '159122886', 0, 1, '[282,[13197.9,16653,0.001]]', '[["ItemFlashlight","Makarov","ItemToolbox","ItemEtool","ItemKnife","ItemRadio","ItemCompass","M4A1_Aim","Binocular_Vector","ItemMap","ItemPickaxe","NVGoggles","ItemHatchet"],[["30Rnd_556x45_Stanag",21],"ItemBandage",["8Rnd_9x18_Makarov",6],"8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage","8Rnd_9x18_Makarov"]]', '["DZ_ALICE_Pack_EP1",[["ItemPickaxe"],[2]],[[],[]]]', '[false,false,false,true,true,false,true,11400,["Pelvis","aimpoint","lelbow","RightFoot","LeftFoot","neck","pilot"],[1.967,0],0,[532.45,664.595]]', 17, '2014-01-24 16:59:02', '2014-01-24 21:38:49', '2014-01-24 16:59:02', '2014-01-24 16:59:02', 7070, 34, 0, 49802, 114, '["","aidlpercmstpsnonwnondnon_player_idlesteady01",41]', 0, 5, 'Sniper1_DZ', '2014-01-24 21:39:02'),
(28, '159165638', 0, 1, '[252,[13197.9,16653,8.545e-04]]', '[["Makarov","ItemCompass","ItemEtool","ItemFlashlightRed","ItemKnife","Binocular_Vector","ItemToolbox","ItemRadio","ItemWatch","ItemMap","ItemHatchet","ItemPickaxe"],["ItemPainkiller",["8Rnd_9x18_Makarov",4],"ItemBandage","8Rnd_9x18_MakarovSD","Ori_8Rnd_TT","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[["ItemBandage","ItemSodaPepsi","FoodCanPasta","ItemSodaCoke","ItemPainkiller","8Rnd_9x18_Makarov","ItemCementBag"],[5,2,1,3,1,1,2]]]', '[false,true,false,true,true,false,true,6600,["Pelvis","aimpoint","lelbow","relbow","neck","pilot"],[0.285,0],5,[480.92,388.174]]', 7, '2014-01-24 18:54:53', '2014-01-24 20:05:12', '2014-01-24 18:54:53', '2014-01-24 18:54:53', 3360, 3, 0, 19690, 0, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",41]', 0, 0, 'Hero1_6DZ', '2014-01-24 20:06:15'),
(29, '159165638', 0, 1, '[135,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov","ItemRadio","ItemWatch","Binocular_Vector","ItemToolbox","ItemMap","ItemKnife","ItemFlashlightRed","ItemCompass","M4A3_CCO_EP1","ItemMatchbox","ItemEtool","ItemHatchet","ItemPickaxe"],["30Rnd_556x45_Stanag","30Rnd_556x45_Stanag","30Rnd_556x45_Stanag",["8Rnd_9x18_Makarov",5],"8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage",["8Rnd_9x18_Makarov",5],"ItemBandage","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov"]]', '["DZ_ALICE_Pack_EP1",[["ItemHatchet"],[1]],[[],[]]]', '[false,false,true,true,true,false,true,1746,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[17.274,0],0,[1045.11,665.617]]', 8, '2014-01-24 20:09:38', '2014-01-25 13:51:45', '2014-01-24 20:09:38', '2014-01-24 20:09:38', 3795, 14, 0, 60520, 136, '["","amovppnemstpsnonwnondnon",42]', 0, 5, 'Sniper1_DZ', '2014-01-25 13:52:41'),
(30, '159122886', 0, 1, '[92,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov","Binocular_Vector","ItemToolbox","NVGoggles","ItemRadio","ItemMap","ItemKnife","ItemEtool","ItemCompass","M4A1_Aim","ItemWatch","ItemPickaxe"],[["30Rnd_556x45_Stanag",15],["30Rnd_556x45_Stanag",14],"ItemRocks","ItemRocks","ItemRocks","ItemRocks","ItemRocks","PartWoodPile",["8Rnd_9x18_Makarov",1],["8Rnd_9x18_Makarov",3],["8Rnd_9x18_Makarov",6],["8Rnd_9x18_Makarov",5],["8Rnd_9x18_Makarov",6],["8Rnd_9x18_Makarov",6]]]', '["DZ_ALICE_Pack_EP1",[[],[]],[["ItemRocks"],[20]]]', '[false,false,false,true,true,false,true,10350,["Pelvis","aimpoint","lelbow","relbow","neck","pilot"],[0.664,0],0,[278.552,154.351]]', 18, '2014-01-24 21:40:40', '2014-01-24 23:45:59', '2014-01-24 21:40:40', '2014-01-24 21:40:40', 6070, 26, 0, 60152, 25, '["","aidlpercmstpsnonwnondnon_player_idlesteady04",42]', 4, 4, 'Sniper1_DZ', '2014-01-24 23:46:11'),
(31, '159122886', 0, 1, '[27,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov"],["ItemPainkiller","30Rnd_556x45_Stanag","30Rnd_556x45_Stanag","ItemBandage","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,true,false,true,true,false,true,10050,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[1.243,0],5,[48.884,86.519]]', 19, '2014-01-24 23:47:33', '2014-01-24 23:53:41', '2014-01-24 23:47:33', '2014-01-24 23:47:33', 6070, 0, 0, 28644, 0, '["","aidlpercmstpsnonwnondnon_player_idlesteady04",38]', 0, 0, 'Hero1_5DZ', '2014-01-24 23:53:48'),
(32, '159122886', 0, 1, '[31,[13197.9,16653,0.002]]', '[["ItemFlashlight","Ori_APS_SD","ItemRadio","ItemWatch","ItemMap","ItemKnife","ItemEtool","ItemCompass","Binocular_Vector","ItemToolbox","ItemHatchet","ItemPickaxe","M4A1_Aim"],[["30Rnd_556x45_Stanag",11],"8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage","ItemBandage","6Rnd_45ACP","ItemBandage","Ori_20Rnd_APS_SD"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,10443,["aimpoint","RightFoot","LeftFoot","pilot"],[2.418,0],0,[683.227,387.743]]', 20, '2014-01-24 23:55:19', '2014-01-25 13:53:40', '2014-01-24 23:55:19', '2014-01-24 23:55:19', 6490, 21, 0, 47611, 120, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",42]', 0, 2, 'Hero1_5DZ', '2014-01-25 13:53:48'),
(33, '159165638', 0, 1, '[348,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov","ItemMap","ItemRadio","Binocular_Vector","ItemToolbox","ItemPickaxe","ItemCompass","ItemHatchet","ItemEtool","ItemFlashlightRed","ItemMatchbox","ItemWatch","ItemKnife","M4A3_CCO_EP1"],["30Rnd_556x45_Stanag","30Rnd_556x45_Stanag","30Rnd_556x45_Stanag","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage","ItemBandage","ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[["Binocular_Vector"],[1]],[[],[]]]', '[false,false,false,false,true,false,true,7610,[],[9.149,0],0,[69.71,258.698]]', 9, '2014-01-25 13:54:17', '2014-01-26 11:09:11', '2014-01-25 13:54:17', '2014-01-25 13:54:17', 4035, 2, 0, 54876, 252, '["","aidlpercmstpsnonwnondnon_player_idlesteady03",42]', 0, 3, 'Sniper1_DZ', '2014-01-26 11:17:21'),
(34, '159122886', 0, 1, '[345,[13197.9,16653,0.002]]', '[["ItemFlashlight","ItemToolbox","Binocular_Vector","ItemWatch","ItemRadio","ItemPickaxe","ItemMap","ItemHatchet","ItemEtool","ItemCompass","Ori_APS_SD","FN_FAL_ANPVS4"],["FoodCanBakedBeans","ItemSodaCoke",["20Rnd_762x51_FNFAL",13],"20Rnd_762x51_FNFAL","20Rnd_762x51_FNFAL","20Rnd_762x51_FNFAL",["Ori_20Rnd_APS_SD",2],"8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","6Rnd_45ACP"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,true,false,true,true,false,true,10950,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[10.522,0],5,[1120.18,210.533]]', 21, '2014-01-25 13:55:14', '2014-01-25 18:16:35', '2014-01-25 13:55:14', '2014-01-25 13:55:14', 6645, 5, 0, 47099, 36, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",42]', 0, 3, 'Sniper1_DZ', '2014-01-25 18:16:50'),
(35, '159122886', 0, 1, '[283,[13197.9,16653,0.001]]', '[["ItemFlashlight","Makarov","ItemHatchet","Binocular_Vector","ItemToolbox","ItemCompass","ItemEtool","ItemMap","ItemRadio","ItemWatch","BAF_L85A2_UGL_ACOG","ItemKnife","ItemPickaxe"],[["30Rnd_556x45_Stanag",29],["30Rnd_556x45_Stanag",28],["30Rnd_556x45_Stanag",18],"ItemMorphine","ItemSodaCoke",["30Rnd_556x45_Stanag",14],"PartGlass","30Rnd_762x39_AK47","FoodCanBakedBeans","30Rnd_556x45_Stanag","30Rnd_556x45_Stanag",["8Rnd_9x18_Makarov",2],"8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage","ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[["M4A3_CCO_EP1"],[1]],[["30Rnd_556x45_Stanag","8Rnd_9x18_Makarov","ItemBandage"],[1,5,2]]]', '[false,false,false,true,true,false,true,6990,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[6.257,0],0,[184.592,138.294]]', 22, '2014-01-25 18:18:28', '2014-01-26 11:38:14', '2014-01-25 18:18:28', '2014-01-25 18:18:28', 7740, 13, 0, 76943, 72, '["","amovppnemstpsnonwnondnon",42]', 0, 15, 'Sniper1_DZ', '2014-01-26 11:38:36'),
(36, '159165638', 1, 1, '[296,[3433.25,7888.31,1.012]]', '[["Makarov","ItemMap","ItemRadio","ItemMatchbox","ItemCompass","ItemEtool","ItemFlashlightRed","ItemKnife","Binocular_Vector","ItemToolbox","ItemWatch","ItemPickaxe","ItemHatchet","SVD_CAMO"],["5Rnd_762x51_M24","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","1Rnd_HE_M203","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","10Rnd_762x54_SVD","ItemPainkiller","ItemSodaCoke","ItemSodaCoke","ItemSodaPepsi"]]', '["DZ_ALICE_Pack_EP1",[["M24"],[1]],[["FoodCanBakedBeans","5Rnd_762x51_M24","ItemSodaCoke"],[1,1,1]]]', '[false,false,false,false,false,false,true,12000,[],[0,0],0,[196.335,77.961]]', 10, '2014-01-26 11:18:47', '2014-01-29 20:29:53', '2014-01-26 11:18:47', '2014-01-26 11:18:47', 3745, 20, 0, 140723, 247, '["SVD_CAMO","aidlpercmstpsraswrfldnon_aiming02",41]', 1, 1, 'Sniper1_DZ', '2014-01-29 20:31:27'),
(37, '159122886', 0, 1, '[58,[13197.9,16653,0.002]]', '[["ItemEtool","ItemKnife","ItemCompass","Binocular_Vector","ItemRadio","ItemToolbox","ItemWatch","ItemMap","Makarov","ItemFlashlightRed","ItemHatchet","BAF_L85A2_UGL_ACOG"],["FoodCanBakedBeans","ItemSodaCoke","30Rnd_556x45_Stanag","30Rnd_556x45_Stanag",["8Rnd_9x18_Makarov",2],["8Rnd_9x18_Makarov",2],["8Rnd_9x18_Makarov",2],["8Rnd_9x18_Makarov",3],"ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,12000,["aimpoint","lelbow","relbow","pilot"],[0.046,0],0,[198.301,490.08]]', 23, '2014-01-26 11:40:04', '2014-01-26 19:34:47', '2014-01-26 11:40:04', '2014-01-26 11:40:04', 8930, 46, 0, 127328, 293, '["","amovppnemstpsnonwnondnon",42]', 0, 3, 'Hero2_4DZ', '2014-01-26 19:35:03'),
(38, '159122886', 0, 1, '[160,[13197.9,16653,0.001]]', '[["ItemFlashlight","Makarov","M4A3_RCO_GL_EP1","ItemRadio","ItemMap","ItemKnife"],["ItemPainkiller",["30Rnd_556x45_Stanag",29],"30Rnd_556x45_Stanag","ItemSodaCoke","FoodCanBakedBeans","30Rnd_556x45_Stanag","10Rnd_762x54_SVD","ItemSodaCoke","ItemSodaCoke","ItemPainkiller","FoodCanBakedBeans","FoodCanBakedBeans","8Rnd_9x18_Makarov","ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,10250,["Pelvis","aimpoint","lelbow","RightFoot","pilot"],[0.758,0],0,[319.766,332.973]]', 24, '2014-01-26 20:46:19', '2014-01-26 21:12:31', '2014-01-26 20:46:19', '2014-01-26 20:46:19', 8280, 0, 0, 27739, 0, '["","aidlpercmstpsnonwnondnon_player_idlesteady04",100]', 1, 0, 'Hero2_3DZ', '2014-01-26 21:12:42'),
(39, '159122886', 0, 1, '[113,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov"],["ItemPainkiller","ItemBandage","8Rnd_9x18_Makarov","ItemBandage","ItemBandage","ItemBandage"]]', '["",[[],[]],[[],[]]]', '[false,false,false,true,false,false,true,9380,["aimpoint"],[0.28,0],0,[80.974,108.431]]', 25, '2014-01-26 21:14:03', '2014-01-26 21:18:22', '2014-01-26 21:14:03', '2014-01-26 21:14:03', 8180, 2, 0, 26812, 0, '["","actspercmstpsnonwpstdnon_suicide1b",40]', 0, 0, 'Hero2_4DZ', '2014-01-26 21:18:41'),
(41, '234775174', 0, 1, '[58,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov"],["ItemPainkiller","ItemBandage","8Rnd_9x18_Makarov"]]', '["",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,9200,["Pelvis","aimpoint","lelbow","relbow","neck","pilot"],[0.118,0],0,[25.8,34.934]]', 1, '2014-01-28 19:58:45', '2014-01-28 20:02:13', '2014-01-28 19:58:45', '2014-01-28 19:58:45', 2500, 0, 0, 28365, 4, '["","amovppnemstpsnonwnondnon",38]', 0, 0, 'Survivor4_DZ', '2014-01-28 20:03:16'),
(42, '234775174', 0, 1, '[30,[13199.2,16653.9,0.002]]', '[["ItemEtool","Makarov","ItemMap","ItemCompass","G36A_camo","ItemKnife"],["ItemMorphine","ItemBloodbag","ItemSodaCoke","ItemSodaPepsi","ItemJerrycan",["30Rnd_556x45_G36",20],["30Rnd_556x45_G36",27]]]', '["DZ_ALICE_Pack_EP1",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,9220,["aimpoint","lelbow","LeftFoot","pilot"],[1.407,0],0,[524.107,179.481]]', 2, '2014-01-28 20:05:01', '2014-01-29 21:39:41', '2014-01-28 20:05:01', '2014-01-28 20:05:01', 3640, 67, 0, 34885, 140, '["","aidlpercmstpsnonwnondnon_player_idlesteady02",41]', 0, 1, 'Sniper1_DZ', '2014-01-29 21:41:45'),
(44, '234775174', 0, 1, '[204,[13223.1,16654.9,0.002]]', '[["ItemFlashlight","Sa61_EP1","LeeEnfield"],["ItemPainkiller","ItemPainkiller","ItemPainkiller","10x_303","10x_303","20Rnd_B_765x17_Ball","8Rnd_9x18_Makarov","ItemBandage"]]', '["",[[],[]],[[],[]]]', '[false,true,false,true,true,false,true,5890,["Pelvis","aimpoint","lelbow","relbow","LeftFoot","neck","pilot"],[1.192,0],5,[248.705,402.848]]', 3, '2014-01-29 21:43:19', '2014-01-30 22:10:27', '2014-01-29 21:43:19', '2014-01-29 21:43:19', 3940, 10, 0, 42113, 25, '["","aidlpercmstpsnonwnondnon_player_idlesteady03",42]', 0, 0, 'Hero1_3DZ', '2014-01-30 22:10:51'),
(43, '159122886', 0, 1, '[136,[13197.9,16653,0.002]]', '[["ItemFlashlight","Makarov","ItemCompass","ItemEtool","ItemFlashlightRed","ItemMap","ItemRadio","ItemToolbox","ItemKnife","ItemPickaxe","ItemHatchet","G36A_camo"],["30Rnd_556x45_G36","30Rnd_556x45_G36","ItemBloodbag","ItemJerrycan","ItemMorphine","ItemSodaPepsi","ItemSodaCoke","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage"]]', '["DZ_ALICE_Pack_EP1",[["G36a","BAF_L85A2_RIS_Holo"],[1,1]],[[],[]]]', '[false,false,false,true,true,false,true,6870,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[12.615,0],0,[1402.05,143.376]]', 27, '2014-01-28 21:38:03', '2014-01-29 22:32:41', '2014-01-28 21:38:03', '2014-01-28 21:38:03', 9060, 14, 0, 80309, 113, '["","aidlpercmstpsnonwnondnon_player_idlesteady04",41]', 0, 3, 'Sniper1_DZ', '2014-01-29 22:32:55'),
(45, '159122886', 0, 1, '[280,[7413.22,20818.4,0.002]]', '[["Makarov","G36a","ItemEtool","ItemFlashlightRed","ItemKnife","ItemHatchet","ItemMap","ItemPickaxe","ItemRadio","ItemToolbox","ItemCompass"],["ItemPainkiller",["30Rnd_556x45_G36",25],"30Rnd_556x45_G36","ItemBloodbag","ItemMorphine","ItemSodaCoke","ItemSodaPepsi","ItemJerrycan","ItemBandage","8Rnd_9x18_Makarov","ItemBandage","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov"]]', '["DZ_ALICE_Pack_EP1",[["G36K"],[1]],[[],[]]]', '[false,true,false,true,true,false,true,150,["aimpoint","neck","pilot"],[3.43,0],5,[445.025,309.291]]', 28, '2014-01-29 22:34:15', '2014-01-30 21:49:12', '2014-01-29 22:34:15', '2014-01-29 22:34:15', 8960, 1, 0, 47678, 13, '["MuzzleFar","",42]', 0, 0, 'Hero2_10DZ', '2014-01-30 21:49:12'),
(46, '159122886', 0, 1, '[73,[13199.7,16652.301,0.002]]', '[["ItemFlashlight","Makarov","Sa58V_EP1","ItemMatchbox","ItemCompass","ItemWatch"],[["30Rnd_762x39_SA58",16],"ItemPainkiller","ItemSodaCoke","ItemMorphine","ItemMorphine","ItemSodaPepsi","FoodCanBakedBeans","ItemSodaCoke","FoodCanBakedBeans","FoodCanSardines","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","8Rnd_9x18_Makarov","ItemBandage"]]', '["",[[],[]],[[],[]]]', '[false,false,false,true,true,false,true,9640,["Pelvis","aimpoint","lelbow","relbow","RightFoot","LeftFoot","neck","pilot"],[4.009,0],0,[236.214,379.976]]', 29, '2014-01-30 21:50:46', '2014-01-30 22:10:30', '2014-01-30 21:50:46', '2014-01-30 21:50:46', 8330, 5, 0, 29002, 0, '["","amovpercmstpsnonwnondnon_amovppnemstpsnonwnondnon",42]', 1, 0, 'Hero2_10DZ', '2014-01-30 22:10:38'),
(47, '159122886', 1, 1, '[101,[3830.93,6390.33,0.002]]', '[["ItemFlashlight","Makarov","ItemMatchbox","Binocular","ItemCompass","ItemWatch","ItemRadio","ItemMap","bizon_silenced"],["ItemSodaCoke","30Rnd_9x19_MP5SD","30Rnd_556x45_Stanag","FoodCanBakedBeans","30Rnd_9x19_MP5SD","ItemBandage","ItemBandage","ItemBandage","ItemBandage","ItemBandage","ItemBandage","ItemHeatPack"]]', '["CZ_VestPouch_EP1",[[],[]],[[],[]]]', '[false,false,false,false,false,false,true,11770,[],[0.848,0],0,[817.316,1017.57]]', 30, '2014-01-30 22:12:03', '2014-01-31 19:30:26', '2014-01-30 22:12:03', '2014-01-30 22:12:03', 8250, 23, 0, 185519, 11, '["Makarov","aidlpercmstpsraswpstdnon_player_idlesteady02",42]', 0, 0, 'Hero2_10DZ', '2014-01-31 19:34:01'),
(48, '234775174', 1, 1, '[133,[7591.23,4637.68,0.001]]', '[["ItemFlashlight","Makarov","ItemMap","M4A3_CCO_EP1"],["ItemPainkiller","ItemPainkiller","30Rnd_545x39_AK","10x_303",["10x_303",9],"FoodCanSardines","10x_303","Skin_Sniper1_DZ","ItemHeatPack","20Rnd_B_765x17_Ball","ItemBandage","ItemBandage","ItemBandage","ItemBandage"]]', '["",[[],[]],[[],[]]]', '[false,false,false,false,false,false,true,10010,[],[0.052,0],0,[226.311,334.385]]', 4, '2014-01-30 22:12:18', '2014-01-30 22:12:18', '2014-01-30 22:12:18', '2014-01-30 22:12:18', 4760, 18, 0, 19215, 0, '["M4A3_CCO_EP1","amovppnemstpsraswrfldnon",41]', 0, 1, 'Hero1_2DZ', '2014-01-30 23:13:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `character_data_dead`
--

CREATE TABLE IF NOT EXISTS `character_data_dead` (
  `CharacterID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PlayerUID` varchar(20) NOT NULL DEFAULT '',
  `Alive` tinyint(1) NOT NULL DEFAULT '1',
  `InstanceID` tinyint(2) NOT NULL,
  `Worldspace` varchar(128) NOT NULL DEFAULT '[]',
  `Inventory` longtext NOT NULL,
  `Backpack` longtext NOT NULL,
  `Medical` varchar(300) NOT NULL DEFAULT '[]',
  `Generation` smallint(4) unsigned NOT NULL DEFAULT '0',
  `Datestamp` timestamp NULL DEFAULT NULL,
  `LastLogin` timestamp NULL DEFAULT NULL,
  `LastAte` timestamp NULL DEFAULT NULL,
  `LastDrank` timestamp NULL DEFAULT NULL,
  `Humanity` int(10) DEFAULT NULL,
  `KillsZ` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `HeadshotsZ` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `distanceFoot` bigint(15) unsigned NOT NULL DEFAULT '0',
  `duration` int(10) NOT NULL DEFAULT '0',
  `currentState` varchar(128) NOT NULL DEFAULT '[]',
  `KillsH` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `KillsB` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `Model` varchar(50) NOT NULL DEFAULT '"Survivor1_DZ"',
  `Datetime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`CharacterID`,`PlayerUID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dbver`
--

CREATE TABLE IF NOT EXISTS `dbver` (
  `version` mediumint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `dbver`
--

INSERT INTO `dbver` (`version`) VALUES
(123);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deployable`
--

CREATE TABLE IF NOT EXISTS `deployable` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq1_deployable` (`class_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1749 ;

--
-- Volcado de datos para la tabla `deployable`
--

INSERT INTO `deployable` (`id`, `class_name`) VALUES
(3, 'Hedgehog_DZ'),
(1, 'TentStorage'),
(43, 'Wire_cat1'),
(53, 'TrapBear'),
(54, 'Sandbag1_DZ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `object_classes`
--

CREATE TABLE IF NOT EXISTS `object_classes` (
  `Classname` varchar(32) NOT NULL DEFAULT '',
  `Chance` varchar(4) NOT NULL DEFAULT '0',
  `MaxNum` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Damage` varchar(20) NOT NULL DEFAULT '0',
  `Hitpoints` varchar(999) NOT NULL DEFAULT '[]',
  PRIMARY KEY (`Classname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `object_classes`
--

INSERT INTO `object_classes` (`Classname`, `Chance`, `MaxNum`, `Damage`, `Hitpoints`) VALUES
('ATV_US_EP1', '0.70', 1, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('car_hatchback', '0.73', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('datsun1_civil_3_open', '0.75', 8, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Fishing_Boat_DZ', '0.9', 7, '0.05000', '[["motor",0.8]]'),
('Ikarus', '0.66', 10, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Old_bike_TK_CIV_EP1', '0.64', 39, '0.05000', '[]'),
('S1203_TK_CIV_EP1', '0.69', 3, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Skoda', '0.68', 5, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('tractor', '0.7', 7, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('TT650_TK_CIV_EP1', '0.72', 7, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('UAZ_RU', '0.7', 10, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('UH1H_DZ', '0.59', 7, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]'),
('UralCivil2', '0.67', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('V3S_Civ', '0.66', 5, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Volha_2_TK_CIV_EP1', '0.71', 3, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('PBX_DZ', '0.4', 5, '0.05000', '[["motor",0.8]]'),
('AN2_DZ', '0.65', 3, '0.05000', '[]'),
('ATV_CZ_EP1', '0.70', 19, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('car_sedan', '0.7', 4, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('datsun1_civil_2_covered', '0.7', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('hilux1_civil_1_open', '0.70', 4, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('hilux1_civil_2_covered', '0.70', 4, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('hilux1_civil_3_open_EP1', '0.70', 7, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Ikarus_TK_CIV_EP1', '0.7', 3, '0.05000', '[]'),
('Lada1', '0.70', 3, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Lada1_TK_CIV_EP1', '0.70', 3, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Lada2_TK_CIV_EP1', '0.70', 3, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('LadaLM', '0.70', 5, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('LandRover_CZ_EP1', '0.70', 1, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('LandRover_TK_CIV_EP1', '0.70', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Mi17_Civilian_DZ', '0.70', 6, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]'),
('MMT_Civ', '0.70', 18, '0.05000', '[]'),
('Old_moto_TK_Civ_EP1', '0.70', 6, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('SUV_Special', '0.7', 10, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('SkodaBlue', '0.70', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('SkodaGreen', '0.70', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('SkodaRed', '0.70', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Smallboat_1_DZ', '0.70', 0, '0.05000', '[["motor",0.8]]'),
('Smallboat_2_DZ', '0.70', 0, '0.05000', '[["motor",0.8]]'),
('TowingTractor', '0.70', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('TT650_Gue', '0.7', 6, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('TT650_Ins', '0.7', 1, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('UAZ_Unarmed_TK_CIV_EP1', '0.7', 1, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('UAZ_Unarmed_TK_EP1', '0.7', 3, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('VWGolf', '0.7', 4, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('VolhaLimo_TK_CIV_EP1', '0.5', 6, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('UralCivil', '0.7', 2, '0.05000', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Mi17_DZ', '0.7', 5, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]'),
('AH6X_DZ', '0.7', 5, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]'),
('Pickup_PK_DZ', '0.7', 5, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('UAZ_MG_DZ', '0.7', 7, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Zodiac_DZ', '0.5', 2, '0.05', '[["motor",0.8]]'),
('TT650_Civ', '0.7', 3, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Ural_TK_CIV_EP1', '0.7', 2, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('Ural_UN_EP1', '0.7', 2, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('rth_ScrapBuggy', '0.5', 13, '0.05', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]'),
('rth_scrapbus', '0.5', 14, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('rth_ScrapApc', '0.5', 31, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]'),
('rth_copter_green', '0.5', 5, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]'),
('rth_copter_yellow', '0.5', 6, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]'),
('rth_raft', '0.5', 15, '0.05', '[["motor",0.8]]'),
('rth_raft_small', '0.5', 14, '0.05', '[["motor",0.8]]'),
('DC3', '0.9', 1, '0.05', '[]'),
('p85_cucv_pickup', '0.7', 5, '0.05', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["sklo_z",0.4],["levy predni tlumic",1],["levy zadni tlumic",0.1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.8],["motor",0.6],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('ori_p85_cucv', '0.7', 4, '0.05', '[["sklo_p",1],["sklo_p1",1],["sklo_p2",0.6],["sklo_l1",1],["sklo_l2",0.5],["sklo_z",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.4],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('ori_vil_volvo_fl290', '0.7', 6, '0.05', '[["sklo_p",0.7],["sklo_p1",1],["sklo_p2",0.9],["sklo_p3",0.3],["sklo_l1",0.1],["sklo_l2",0.1],["sklo_l3",1],["levy predni tlumic",0.5],["levy zadni tlumic",0.1],["pravy predni tlumic",0.2],["karoserie",0.1],["palivo",0.6],["motor",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('ori_vil_truck_civ2', '0.7', 4, '0', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",0.7],["levy predni tlumic",0.1],["levy zadni tlumic",0.1],["pravy predni tlumic",0.3],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.6],["motor",0.5],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('ori_vil_truck_civ1', '0.7', 4, '0', '[["sklo_p",1],["sklo_p1",0.8],["sklo_l1",0.3],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.4],["palivo",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('ori_vil_truck_civ', '0.7', 4, '0', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.9],["palivo",0.6],["motor",0.2],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('ori_vil_lublin_truck', '0.7', 4, '0', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",0.2],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.2],["sklo predni P",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]'),
('rth_amphicar', '0.7', 15, '0.05', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]'),
('origins_bathmobile', '0.7', 15, '0.05', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["front_plow",1],["wheel_guards",1],["windshield_guard",1]]');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `object_data`
--

CREATE TABLE IF NOT EXISTS `object_data` (
  `ObjectID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ObjectUID` varchar(20) DEFAULT NULL,
  `Instance` int(3) DEFAULT NULL,
  `Classname` varchar(32) DEFAULT NULL,
  `Damage` double(13,5) DEFAULT NULL,
  `CharacterID` int(10) unsigned DEFAULT NULL,
  `Worldspace` varchar(64) DEFAULT NULL,
  `Inventory` longtext,
  `Hitpoints` varchar(999) DEFAULT NULL,
  `Fuel` double(13,5) DEFAULT NULL,
  `Datestamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ObjectID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=982 ;

--
-- Volcado de datos para la tabla `object_data`
--

INSERT INTO `object_data` (`ObjectID`, `ObjectUID`, `Instance`, `Classname`, `Damage`, `CharacterID`, `Worldspace`, `Inventory`, `Hitpoints`, `Fuel`, `Datestamp`) VALUES
(843, '0000500001394', 1, 'UralCivil2', 0.05000, 0, '[269,[22180.7,19833.1,0]]', '[[["ItemPickaxe"],[2]],[["ItemBpt_b1","ItemBpt_b2","ItemBpt_h1","ItemBpt_h2","ItemBpt_g_s","ItemBpt_g_b","ItemBattery","ItemPin","ItemRocks","ItemCementBag","PartScrap","PartWoodPile","ItemCeMix"],[3,3,3,3,3,1,7,7,15,5,10,15,3]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1]]', 0.01000, '2014-01-31 15:42:03'),
(844, '0000500001395', 1, 'UralCivil2', 0.05000, 0, '[90,[22452.8,20074.8,0]]', '[[["AKS_74_kobra","M16A2GL","AKS_74_U","FN_FAL","M9SD","PK_DZ","Pecheneg_DZ","bizon_silenced","M4A3_RCO_GL_EP1","NVGoggles","ItemGPS","G36K"],[3,3,3,3,3,3,3,3,3,2,2,1]],[["ItemBloodbag","100Rnd_762x54_PK","30Rnd_556x45_Stanag","100Rnd_762x51_M240","30Rnd_556x45_G36SD","10Rnd_9x39_SP5_VSS","ItemAntibiotic","30Rnd_545x39_AK","20Rnd_762x51_FNFAL","15Rnd_9x19_M9SD","64Rnd_9x19_SD_Bizon","1Rnd_HE_GP25","PartGeneric","PartEngine","PartGlass","PartVRotor","ItemJerrycan","ItemTent"],[10,10,10,10,10,10,10,10,10,10,10,10,4,2,6,2,10,2]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1]]', 0.01000, '2014-01-31 15:42:03'),
(845, '0000500001396', 1, 'UralCivil2', 0.05000, 0, '[178,[22533,20073,0]]', '[[["AKS_74_kobra","M16A2GL","AKS_74_U","FN_FAL","M9SD","PK_DZ","Pecheneg_DZ","bizon_silenced","M4A3_RCO_GL_EP1","NVGoggles","ItemGPS","G36K"],[3,3,3,3,3,3,3,3,3,2,2,1]],[["ItemBloodbag","100Rnd_762x54_PK","30Rnd_556x45_Stanag","100Rnd_762x51_M240","30Rnd_556x45_G36SD","10Rnd_9x39_SP5_VSS","ItemAntibiotic","30Rnd_545x39_AK","20Rnd_762x51_FNFAL","15Rnd_9x19_M9SD","64Rnd_9x19_SD_Bizon","1Rnd_HE_GP25","PartGeneric","PartEngine","PartGlass","PartVRotor","ItemJerrycan","ItemTent"],[10,10,10,10,10,10,10,10,10,10,10,10,4,2,6,2,10,2]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1]]', 0.01000, '2014-01-31 15:42:03'),
(846, '0000500001397', 1, 'UralCivil2', 0.05000, 0, '[178,[22549.2,20071.9,0]]', '[[["AKS_74_kobra","M16A2GL","AKS_74_U","FN_FAL","M9SD","PK_DZ","Pecheneg_DZ","bizon_silenced","M4A3_RCO_GL_EP1","NVGoggles","ItemGPS","G36K"],[3,3,3,3,3,3,3,3,3,2,2,1]],[["ItemBloodbag","100Rnd_762x54_PK","30Rnd_556x45_Stanag","100Rnd_762x51_M240","30Rnd_556x45_G36SD","10Rnd_9x39_SP5_VSS","ItemAntibiotic","30Rnd_545x39_AK","20Rnd_762x51_FNFAL","15Rnd_9x19_M9SD","64Rnd_9x19_SD_Bizon","1Rnd_HE_GP25","PartGeneric","PartEngine","PartGlass","PartVRotor","ItemJerrycan","ItemTent"],[10,10,10,10,10,10,10,10,10,10,10,10,4,2,6,2,10,2]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1]]', 0.01000, '2014-01-31 15:42:03'),
(806, '0000000000015', 1, 'Ikarus', 0.15500, NULL, '[1,[3793,7072,0]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40500, '2014-01-28 21:30:08'),
(719, '0000000000070', 1, 'MMT_Civ', 0.62088, NULL, '[340,[8248,6115,0]]', '[]', '[]', 0.87161, '2014-01-26 11:54:09'),
(847, '0000500000431', 1, 'DC3', 0.05000, 0, '[1,[22687.3,19239.3,0]]', '[]', '[]', 1.00000, '2014-01-31 15:42:03'),
(714, '0000000000182', 1, 'datsun1_civil_3_open', 0.15522, NULL, '[130,[17837.9,6490.08,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:08'),
(715, '0000000000049', 1, 'ATV_CZ_EP1', 0.62088, NULL, '[145,[11798,1452,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 11:54:08'),
(716, '0000000000121', 1, 'Mi17_Civilian_DZ', 0.62088, NULL, '[290,[9983,18892,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-26 11:54:08'),
(717, '0000000000226', 1, 'MMT_Civ', 0.33109, NULL, '[268,[15840.2,9385.28,0]]', '[]', '[]', 0.09446, '2014-01-26 11:54:08'),
(607, '0000000000270', 1, 'Ikarus_TK_CIV_EP1', 0.15522, NULL, '[360,[12628.4,11741,0]]', '[]', '[]', 0.40540, '2014-01-26 10:08:29'),
(608, '0000000000009', 1, 'rth_ScrapBuggy', 0.33109, NULL, '[130,[1634,7604,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.09446, '2014-01-26 10:08:29'),
(609, '0000000000198', 1, 'TT650_Gue', 0.63875, NULL, '[261,[16877.2,8197.77,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(610, '0000500000423', 1, 'rth_copter_yellow', 0.62088, NULL, '[339,[10449.6,17614.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(611, '0000000000306', 1, 'AH6X_DZ', 0.15522, NULL, '[117,[11574.3,648.71,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(612, '0000500000453', 1, 'ori_vil_truck_civ1', 0.15522, NULL, '[73,[15118.6,14785.2,0]]', '[]', '[["sklo_p",1],["sklo_p1",0.8],["sklo_l1",0.3],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.4],["palivo",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(613, '0000000000273', 1, 'Ikarus', 0.73922, NULL, '[360,[16282.4,13657.6,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.04671, '2014-01-26 10:08:29'),
(614, '0000000000319', 1, 'Pickup_PK_DZ', 0.15522, NULL, '[229,[11035.2,6675.03,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(615, '0000000000144', 1, 'hilux1_civil_2_covered', 0.15500, NULL, '[320,[14881,18583,4.292e-05]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40500, '2014-01-29 21:31:18'),
(616, '0000000000352', 1, 'ATV_CZ_EP1', 0.77385, NULL, '[128,[8958.34,8343.56,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.31631, '2014-01-26 10:08:29'),
(730, '0000000000314', 1, 'UH1H_DZ', 0.15522, NULL, '[3,[16966.1,12568.3,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(582, '0000000000034', 1, 'rth_scrapbus', 0.62211, NULL, '[140,[9934.76,1390.8,0.005]]', '[[[],[]],[[],[]],[[],[]]]', '[["karoserie",1],["motor",0.8],["palivo",0.8],["wheel_1_1_steering",1],["wheel_1_2_steering",1],["wheel_2_1_steering",1],["wheel_2_2_steering",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87200, '2014-01-29 19:35:24'),
(26, '0000000000007', 1, 'Ural_TK_CIV_EP1', 0.19685, NULL, '[349,[5326.29,8603.67,-7.629e-06]]', '[[["Makarov","ItemFlashlight","ItemToolbox","ItemHatchet","M4A3_CCO_EP1","ItemRadio","ItemPickaxe","ItemEtool"],[1,1,4,8,1,1,6,2]],[["PartFueltank","ItemWaterbottle","Ori_20Rnd_APS","6Rnd_45ACP","2Rnd_shotgun_74Pellets","ItemBandage","PartGlass","30Rnd_762x39_AK47","8Rnd_9x18_Makarov","ItemPainkiller","ItemCementBag","ItemBpt_g_s","Ori_mosin_clip","PartScrap","ItemBpt_g_b","PartWheel","ItemJerrycanEmpty","ItemSodaCoke","30Rnd_545x39_AKSD","FoodCanBakedBeans","ItemAntibiotic","200Rnd_556x45_M249","ItemSodaPepsi","HandGrenade_West","PartGeneric","30Rnd_545x39_AK","7Rnd_45ACP_1911","HandRoadFlare","30Rnd_556x45_Stanag","HandGrenade","20Rnd_9x39_SP5_VSS","75Rnd_545x39_RPK","30Rnd_9x19_MP5","Ori_8Rnd_TT","Ori_20Rnd_APS_SD","Ori_12Rnd_maka","PartEngine"],[2,1,1,2,1,13,8,6,13,6,13,1,2,10,3,5,13,10,2,3,4,2,7,2,3,1,2,2,5,5,2,1,4,1,2,1,2]],[[],[]]]', '[["glass1",1],["glass2",1],["glass3",1],["glass4",1],["sklo predni P",1],["sklo predni L",1]]', 0.05915, '2014-01-26 17:30:41'),
(789, '0000000000014', 1, 'rth_ScrapApc', 0.33071, NULL, '[180,[3785,6933,-1.144e-05]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09400, '2014-01-30 22:57:00'),
(32, '0000000000321', 1, 'Pickup_PK_DZ', 0.71700, NULL, '[92,[5359.54,8586.66,0]]', '[[["ItemEtool","ItemPickaxe","Binocular","Makarov"],[1,1,1,1]],[["HandRoadFlare","ItemJerrycanEmpty","8Rnd_9x18_Makarov"],[1,3,4]],[[],[]]]', '[["motor",0.717],["sklo predni P",1],["sklo predni L",1],["karoserie",0.535],["palivo",0.368],["wheel_2_1_steering",0.677],["wheel_1_2_steering",0.025],["glass1",1],["glass2",1],["glass3",1]]', 0.19500, '2014-01-31 19:03:55'),
(36, '0000000000012', 1, 'Old_moto_TK_Civ_EP1', 0.17717, NULL, '[51,[3551.05,7560.32,-0.009]]', '[[[],[]],[[],[]],[[],[]]]', '[["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["Pravy predni tlumic",1],["Pravy zadni tlumic",1]]', 0.00000, '2014-01-26 10:36:03'),
(618, '0000500000399', 1, 'rth_amphicar', 0.62088, NULL, '[78,[21979.7,20095.1,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.87161, '2014-01-26 10:08:29'),
(787, '0000000000295', 1, 'Old_bike_TK_CIV_EP1', 0.36907, NULL, '[178,[3424.7,7552.19,0]]', '[]', '[]', 0.08720, '2014-01-26 12:39:26'),
(788, '0000500000404', 1, 'rth_raft', 0.70281, NULL, '[9,[23283.1,19244.2,0]]', '[]', '[["motor",0.8]]', 0.95020, '2014-01-26 12:39:26'),
(566, '0000000000296', 1, 'MMT_Civ', 0.35039, NULL, '[26,[3783.77,7205.59,0.029]]', '[[[],[]],[[],[]],[[],[]]]', '[["karoserie",0.421],["wheel_1_damper",0.421],["wheel_2_damper",0.421]]', 1.00000, '2014-01-30 22:09:13'),
(785, '0000000000142', 1, 'TT650_TK_CIV_EP1', 0.15522, NULL, '[230,[15135,18238,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 12:39:26'),
(786, '0000000000279', 1, 'Old_bike_TK_CIV_EP1', 0.41633, NULL, '[359,[14462.5,11394.3,0]]', '[]', '[]', 0.70111, '2014-01-26 12:39:26'),
(783, '0000000000155', 1, 'rth_raft_small', 0.62088, NULL, '[90,[17420,12576,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 12:39:26'),
(784, '0000000000194', 1, 'rth_ScrapApc', 0.97895, NULL, '[302,[16788,8455.63,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.18541, '2014-01-26 12:39:26'),
(782, '0000000000297', 1, 'TT650_TK_CIV_EP1', 0.62100, NULL, '[138,[3799.17,7098.59,-0.017]]', '[[[],[]],[[],[]],[[],[]]]', '[["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8]]', 0.87200, '2014-01-30 22:02:38'),
(981, '0000000000108', 1, 'LadaLM', 0.15522, NULL, '[320,[16704,10623,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(980, '0000500000338', 1, 'Fishing_Boat_DZ', 0.62088, NULL, '[334,[16789.4,4734.12,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-31 15:42:03'),
(554, '0000000000096', 1, 'Skoda', 0.62100, NULL, '[270,[5715,9903,-5.722e-05]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87200, '2014-01-26 14:15:22'),
(979, '0000000000098', 1, 'rth_scrapbus', 0.62088, NULL, '[1,[5693,9880,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-31 15:42:03'),
(978, '0000000000074', 1, 'ATV_CZ_EP1', 0.15522, NULL, '[180,[7566,7381,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(977, '0000000000343', 1, 'ATV_CZ_EP1', 0.62088, NULL, '[132,[3334.44,7605.02,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(975, '0000500000341', 1, 'Fishing_Boat_DZ', 0.63875, NULL, '[163,[9750.54,14107.1,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-31 15:42:03'),
(976, '0000500000340', 1, 'rth_raft_small', 0.15522, NULL, '[169,[10360.8,16778.9,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-31 15:42:03'),
(974, '0000000000266', 1, 'LandRover_CZ_EP1', 0.15522, NULL, '[8,[12521.9,13577.1,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(972, '0000000000231', 1, 'SkodaGreen', 0.15522, NULL, '[91,[14611.5,10154.7,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(973, '0000500000433', 1, 'ori_vil_lublin_truck', 0.15522, NULL, '[148,[4715.7,8207.52,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",0.2],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.2],["sklo predni P",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(971, '0000000000351', 1, 'TT650_Civ', 0.15522, NULL, '[228,[9080.3,7858.84,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(970, '0000000000384', 1, 'ATV_CZ_EP1', 0.63875, NULL, '[270,[16195.2,11601.9,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-31 15:42:03'),
(968, '0000000000175', 1, 'Old_bike_TK_CIV_EP1', 0.97895, NULL, '[2,[18421.7,5059.4,0]]', '[]', '[]', 0.18541, '2014-01-31 15:42:03'),
(969, '0000500000418', 1, 'rth_copter_yellow', 0.15522, NULL, '[0,[4632.15,6349.35,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(967, '0000500000445', 1, 'ori_vil_lublin_truck', 0.62088, NULL, '[144,[12459.6,11796.2,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",0.2],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.2],["sklo predni P",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-31 15:42:03'),
(965, '0000500000335', 1, 'Fishing_Boat_DZ', 0.62088, NULL, '[148,[10850.9,6061.89,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-31 15:42:03'),
(966, '0000500000452', 1, 'ori_vil_truck_civ', 0.62088, NULL, '[94,[16302.2,8816.24,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.9],["palivo",0.6],["motor",0.2],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-31 15:42:03'),
(964, '0000500000437', 1, 'p85_cucv_pickup', 0.15522, NULL, '[236,[8150.87,4992.57,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["sklo_z",0.4],["levy predni tlumic",1],["levy zadni tlumic",0.1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.8],["motor",0.6],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(963, '0000000000078', 1, 'LadaLM', 0.15522, NULL, '[210,[7453,8090,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(962, '0000000000033', 1, 'rth_scrapbus', 0.15522, NULL, '[320,[9922,1412,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(780, '0000000000029', 1, 'MMT_Civ', 0.15522, NULL, '[1,[8987,2235,0]]', '[]', '[]', 0.40540, '2014-01-26 12:39:26'),
(781, '0000000000189', 1, 'rth_ScrapBuggy', 0.33109, NULL, '[3,[16279.2,11705.8,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.09446, '2014-01-26 12:39:26'),
(961, '0000000000126', 1, 'rth_scrapbus', 0.33109, NULL, '[260,[10238,19038,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.09446, '2014-01-31 15:42:03'),
(960, '0000000000193', 1, 'Lada1', 0.62088, NULL, '[178,[17244.4,7422.91,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(959, '0000500000448', 1, 'p85_cucv_pickup', 0.62088, NULL, '[4,[12786.1,11704.3,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["sklo_z",0.4],["levy predni tlumic",1],["levy zadni tlumic",0.1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.8],["motor",0.6],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-31 15:42:03'),
(957, '0000000000167', 1, 'UAZ_Unarmed_TK_CIV_EP1', 0.15522, NULL, '[93,[15655.4,9620.11,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(958, '0000000000220', 1, 'rth_ScrapApc', 0.93237, NULL, '[183,[14533.3,10395.5,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.02531, '2014-01-31 15:42:03'),
(956, '0000500000459', 1, 'p85_cucv_pickup', 0.63875, NULL, '[268,[9009.84,19351.9,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["sklo_z",0.4],["levy predni tlumic",1],["levy zadni tlumic",0.1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.8],["motor",0.6],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-31 15:42:03'),
(955, '0000000000364', 1, 'Old_moto_TK_Civ_EP1', 0.15522, NULL, '[305,[7935.54,5362.72,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(954, '0000000000222', 1, 'UAZ_RU', 0.15522, NULL, '[274,[14646.1,9984.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(953, '0000000000129', 1, 'rth_scrapbus', 0.73922, NULL, '[150,[10929,18768,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.04671, '2014-01-31 15:42:03'),
(650, '0000000000261', 1, 'UAZ_Unarmed_TK_EP1', 0.62088, NULL, '[126,[11720.4,14881.3,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(951, '0000000000061', 1, 'SkodaBlue', 0.15522, NULL, '[270,[9172,5416,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(952, '0000000000308', 1, 'UH1H_DZ', 0.15522, NULL, '[252,[5317.76,8620.61,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(949, '0000500000469', 1, 'rth_amphicar', 0.62088, NULL, '[160,[17420.1,13182,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.87161, '2014-01-31 15:42:03'),
(950, '0000000000195', 1, 'Old_bike_TK_CIV_EP1', 0.93237, NULL, '[87,[16564.4,8259.9,0]]', '[]', '[]', 0.02531, '2014-01-31 15:42:03'),
(947, '0000000000079', 1, 'AN2_DZ', 0.15522, NULL, '[220,[7550,8009,0]]', '[]', '[]', 0.40540, '2014-01-31 15:42:03'),
(948, '0000000000105', 1, 'Lada1', 0.15522, NULL, '[350,[10636,6518,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(946, '0000000000104', 1, 'UAZ_RU', 0.15522, NULL, '[60,[10395,6751,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(944, '0000000000376', 1, 'TT650_Civ', 0.62088, NULL, '[315,[11776.9,15325.2,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(945, '0000000000259', 1, 'rth_ScrapApc', 0.90443, NULL, '[326,[11922.9,15458,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.81216, '2014-01-31 15:42:03'),
(941, '0000000000153', 1, 'Fishing_Boat_DZ', 0.15522, NULL, '[280,[11695,18963,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-31 15:42:03'),
(942, '0000000000111', 1, 'AN2_DZ', 0.62088, NULL, '[240,[10285,18406,0]]', '[]', '[]', 0.87161, '2014-01-31 15:42:03'),
(943, '0000500000397', 1, 'rth_raft_small', 0.62088, NULL, '[38,[21774.4,19523.4,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-31 15:42:03'),
(940, '0000000000169', 1, 'Volha_2_TK_CIV_EP1', 0.15522, NULL, '[2,[14993.4,9260.11,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(938, '0000000000123', 1, 'V3S_Civ', 0.15522, NULL, '[30,[9937,19091,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(937, '0000000000201', 1, 'UAZ_RU', 0.62088, NULL, '[130,[13405.5,8632.01,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(936, '0000000000367', 1, 'Skoda', 0.62088, NULL, '[282,[11295.9,17805.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(935, '0000500000413', 1, 'rth_raft', 0.63875, NULL, '[80,[7302.73,21060.3,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-31 15:42:03'),
(932, '0000000000003', 1, 'MMT_Civ', 0.15522, NULL, '[240,[1361,7954,0]]', '[]', '[]', 0.40540, '2014-01-31 15:42:03'),
(933, '0000000000217', 1, 'hilux1_civil_3_open_EP1', 0.62088, NULL, '[270,[14742,9858.23,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(934, '0000000000128', 1, 'V3S_Civ', 0.62088, NULL, '[250,[10177,19193,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(931, '0000500000422', 1, 'rth_copter_yellow', 0.62088, NULL, '[0,[9946.07,18675.1,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(930, '0000000000286', 1, 'Lada1_TK_CIV_EP1', 0.15522, NULL, '[241,[13994.2,12219.7,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(929, '0000000000360', 1, 'car_hatchback', 0.15522, NULL, '[228,[10017.9,1323.86,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(928, '0000000000178', 1, 'hilux1_civil_2_covered', 0.15522, NULL, '[0,[17683.4,6186.37,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(927, '0000000000232', 1, 'SkodaRed', 0.15522, NULL, '[111,[15348.2,9014.43,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(777, '0000000000094', 1, 'Old_bike_TK_CIV_EP1', 0.29642, NULL, '[270,[5850,9901,0]]', '[]', '[]', 0.61083, '2014-01-26 12:39:26'),
(778, '0000000000145', 1, 'ATV_CZ_EP1', 0.63875, NULL, '[260,[15715,17082,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 12:39:26'),
(926, '0000000000043', 1, 'SkodaRed', 0.15522, NULL, '[250,[11175,715,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(925, '0000000000307', 1, 'rth_copter_green', 0.15522, NULL, '[38,[9320.15,7765.53,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(923, '0000000000199', 1, 'rth_ScrapApc', 0.37364, NULL, '[167,[17301.6,8240.52,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.20358, '2014-01-31 15:42:03'),
(924, '0000000000276', 1, 'rth_ScrapBuggy', 0.37364, NULL, '[4,[15065.4,18458.4,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.20358, '2014-01-31 15:42:03'),
(922, '0000000000081', 1, 'MMT_Civ', 0.15522, NULL, '[340,[5375,8484,0]]', '[]', '[]', 0.40540, '2014-01-31 15:42:03'),
(920, '0000000000071', 1, 'SUV_Special', 0.15522, NULL, '[60,[7838,6529,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(921, '0000000000073', 1, 'V3S_Civ', 0.15522, NULL, '[160,[7942,6909,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(131, '0000000000017', 1, 'SkodaBlue', 0.62100, NULL, '[93,[3788.69,7278.76,-3.433e-05]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87200, '2014-01-30 22:07:08'),
(919, '0000000000323', 1, 'origins_bathmobile', 0.15522, NULL, '[9,[13368,8591.33,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["front_plow",1],["wheel_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(918, '0000000000320', 1, 'UAZ_MG_DZ', 0.15522, NULL, '[32,[9336.4,5230.6,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(916, '0000000000154', 1, 'Fishing_Boat_DZ', 0.62088, NULL, '[90,[14753,18757,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-31 15:42:03'),
(917, '0000000000025', 1, 'Lada1_TK_CIV_EP1', 0.15522, NULL, '[145,[8780,2383,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(776, '0000000000284', 1, 'rth_scrapbus', 0.97895, NULL, '[338,[14131.7,12000.6,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.18541, '2014-01-26 12:39:26'),
(790, '0000000000162', 1, 'MMT_Civ', 0.15522, NULL, '[185,[15391.3,9277.98,0]]', '[]', '[]', 0.40540, '2014-01-26 12:39:26'),
(791, '0000500000407', 1, 'rth_raft', 0.70281, NULL, '[134,[10265.7,16715.5,0]]', '[]', '[["motor",0.8]]', 0.95020, '2014-01-26 12:39:26'),
(915, '0000500000450', 1, 'ori_vil_truck_civ2', 0.15522, NULL, '[0,[17424.9,7501.15,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",0.7],["levy predni tlumic",0.1],["levy zadni tlumic",0.1],["pravy predni tlumic",0.3],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.6],["motor",0.5],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(913, '0000000000263', 1, 'Old_bike_TK_CIV_EP1', 0.92378, NULL, '[182,[11338.4,15214.4,0]]', '[]', '[]', 0.55428, '2014-01-31 15:42:03'),
(914, '0000000000223', 1, 'VWGolf', 0.15522, NULL, '[269,[15480.1,9470.94,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(851, '0000000000362', 1, 'Ikarus_TK_CIV_EP1', 0.15522, NULL, '[221,[7582.17,4367.27,0]]', '[]', '[]', 0.40540, '2014-01-31 15:42:03'),
(852, '0000500000429', 1, 'rth_ScrapBuggy', 0.90443, NULL, '[85,[16808.1,12630,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.81216, '2014-01-31 15:42:03'),
(488, '0000000000309', 1, 'AH6X_DZ', 0.15500, NULL, '[325,[5987.56,9657.04,-0.027]]', '[[[],[]],[[],[]],[[],[]]]', '[["glass1",1],["glass3",1],["motor",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1]]', 0.00000, '2014-01-26 14:17:29'),
(489, '0000500000434', 1, 'ori_vil_truck_civ1', 0.16142, NULL, '[63,[5315.89,8579.99,-0.009]]', '[[[],[]],[["20Rnd_9x39_SP5_VSS","ItemPainkiller","ItemSodaCoke","FoodCanBakedBeans","ItemCementBag","ItemCinderblocks","PartFueltank","ItemSodaPepsi","ItemBandage","30Rnd_545x39_AK","10Rnd_762x54_SVD","ItemBattery","ItemBloodbag","PartGeneric"],[2,3,8,4,4,3,3,1,4,2,1,1,1,1]],[[],[]]]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",0.673],["front_plow",0],["wheel_guards",0],["window_guards",0],["windshield_guard",0]]', 0.16500, '2014-01-26 12:50:09'),
(912, '0000000000146', 1, 'UAZ_RU', 0.62088, NULL, '[220,[15077,15937,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(911, '0000000000250', 1, 'SUV_Special', 0.62088, NULL, '[84,[13715.5,13634.7,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(910, '0000000000264', 1, 'ATV_US_EP1', 0.15522, NULL, '[301,[12340.2,15732.9,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(909, '0000500000446', 1, 'ori_vil_truck_civ1', 0.15522, NULL, '[142,[12605.4,12006.2,0]]', '[]', '[["sklo_p",1],["sklo_p1",0.8],["sklo_l1",0.3],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.4],["palivo",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(907, '0000000000106', 1, 'LandRover_TK_CIV_EP1', 0.15522, NULL, '[300,[10644,6569,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(908, '0000000000239', 1, 'Volha_2_TK_CIV_EP1', 0.62088, NULL, '[95,[15589.6,9575.94,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(906, '0000000000310', 1, 'Mi17_DZ', 0.15522, NULL, '[1,[15379.4,9707.99,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(856, '0000000000370', 1, 'SUV_Special', 0.33109, NULL, '[195,[12441.5,13807.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-31 15:42:03'),
(905, '0000000000134', 1, 'Ural_TK_CIV_EP1', 0.15522, NULL, '[100,[10976,19033,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(903, '0000500000424', 1, 'rth_copter_green', 0.63875, NULL, '[234,[13036.3,14384,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.14186, '2014-01-31 15:42:03'),
(904, '0000000000312', 1, 'AH6X_DZ', 0.15522, NULL, '[269,[14520.7,11411.9,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(767, '0000000000283', 1, 'Old_bike_TK_CIV_EP1', 0.59635, NULL, '[343,[14165,11955.4,0]]', '[]', '[]', 0.33264, '2014-01-26 11:54:09'),
(768, '0000000000185', 1, 'UAZ_RU', 0.33109, NULL, '[181,[17216.7,7662.86,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-26 11:54:09'),
(766, '0000000000062', 1, 'Old_bike_TK_CIV_EP1', 0.73922, NULL, '[1,[9055,5393,0]]', '[]', '[]', 0.04671, '2014-01-26 11:54:09'),
(902, '0000000000290', 1, 'hilux1_civil_2_covered', 0.62088, NULL, '[1,[9650,6007,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(901, '0000000000325', 1, 'Pickup_PK_DZ', 0.15522, NULL, '[89,[16428.8,14267.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(764, '0000000000205', 1, 'TT650_TK_CIV_EP1', 0.62088, NULL, '[108,[16432.5,6287.62,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 11:54:09'),
(900, '0000500000432', 1, 'ori_vil_truck_civ2', 0.15522, NULL, '[233,[5102.6,6293.02,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",0.7],["levy predni tlumic",0.1],["levy zadni tlumic",0.1],["pravy predni tlumic",0.3],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.6],["motor",0.5],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(899, '0000500000457', 1, 'ori_vil_lublin_truck', 0.63875, NULL, '[24,[15569.1,16019.5,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",0.2],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.2],["sklo predni P",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-31 15:42:03'),
(760, '0000000000010', 1, 'Old_bike_TK_CIV_EP1', 0.29642, NULL, '[330,[3290,7529,0]]', '[]', '[]', 0.61083, '2014-01-26 11:54:09'),
(761, '0000000000368', 1, 'rth_ScrapBuggy', 0.77385, NULL, '[28,[15335.2,16080.1,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.31631, '2014-01-26 11:54:09'),
(898, '0000000000234', 1, 'hilux1_civil_1_open', 0.15522, NULL, '[3,[15476.7,9622.34,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(896, '0000000000358', 1, 'ATV_CZ_EP1', 0.62088, NULL, '[263,[10655.4,6465.89,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(762, '0000500000412', 1, 'rth_raft_small', 0.70472, NULL, '[89,[7381.35,20815.199,0.341]]', '[[["G36a"],[1]],[["30Rnd_556x45_G36"],[1]],[[],[]]]', '[["motor",0.8]]', 0.92742, '2014-01-30 21:46:11'),
(897, '0000000000045', 1, 'rth_ScrapApc', 0.62088, NULL, '[270,[11649,773,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(619, '0000000000046', 1, 'SkodaGreen', 0.15522, NULL, '[120,[11701,749,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(893, '0000500000419', 1, 'rth_copter_yellow', 0.62088, NULL, '[0,[4349.91,8068.19,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(892, '0000000000028', 1, 'VWGolf', 0.15522, NULL, '[215,[8895,2265,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(890, '0000000000348', 1, 'MMT_Civ', 0.33109, NULL, '[186,[6735.83,9889.73,0]]', '[]', '[]', 0.09446, '2014-01-31 15:42:03'),
(891, '0000000000013', 1, 'LadaLM', 0.62088, NULL, '[1,[3796,6887,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(889, '0000000000363', 1, 'TT650_Civ', 0.62088, NULL, '[226,[7913.65,4156.75,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(888, '0000000000057', 1, 'UralCivil', 0.15522, NULL, '[90,[9281,4389,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(887, '0000000000274', 1, 'TT650_TK_CIV_EP1', 0.15522, NULL, '[8,[15724.4,13410.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(884, '0000000000109', 1, 'AN2_DZ', 0.62088, NULL, '[270,[16730,10484,0]]', '[]', '[]', 0.87161, '2014-01-31 15:42:03'),
(885, '0000500000337', 1, 'Zodiac_DZ', 0.15522, NULL, '[90,[10120.1,5358.97,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-31 15:42:03'),
(886, '0000500000406', 1, 'rth_amphicar', 0.15522, NULL, '[0,[22516.5,18786.4,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.40540, '2014-01-31 15:42:03'),
(883, '0000000000280', 1, 'SUV_Special', 0.63875, NULL, '[33,[14265.1,11259.9,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-31 15:42:03'),
(882, '0000000000272', 1, 'hilux1_civil_2_covered', 0.62088, NULL, '[306,[16137.5,13478.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(880, '0000000000327', 1, 'origins_bathmobile', 0.62088, NULL, '[59,[11098.3,18706.2,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["front_plow",1],["wheel_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-31 15:42:03'),
(881, '0000000000361', 1, 'rth_ScrapBuggy', 0.77385, NULL, '[136,[9638.87,1751.53,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.31631, '2014-01-31 15:42:03');
INSERT INTO `object_data` (`ObjectID`, `ObjectUID`, `Instance`, `Classname`, `Damage`, `CharacterID`, `Worldspace`, `Inventory`, `Hitpoints`, `Fuel`, `Datestamp`) VALUES
(853, '0000500000438', 1, 'ori_p85_cucv', 0.15522, NULL, '[145,[8238.77,5015.45,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_p2",0.6],["sklo_l1",1],["sklo_l2",0.5],["sklo_z",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.4],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(879, '0000000000233', 1, 'car_sedan', 0.15522, NULL, '[269,[14730.8,9807.05,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(878, '0000000000127', 1, 'hilux1_civil_1_open', 0.15522, NULL, '[260,[10314,19140,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(876, '0000500000439', 1, 'p85_cucv_pickup', 0.62088, NULL, '[232,[8157.2,5024.86,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["sklo_z",0.4],["levy predni tlumic",1],["levy zadni tlumic",0.1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.8],["motor",0.6],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-31 15:42:03'),
(877, '0000500000454', 1, 'p85_cucv_pickup', 0.63875, NULL, '[83,[15087.1,14873.6,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["sklo_z",0.4],["levy predni tlumic",1],["levy zadni tlumic",0.1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.8],["motor",0.6],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-31 15:42:03'),
(939, '0000500000415', 1, 'rth_raft', 0.63875, NULL, '[243,[16220.8,16089.3,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-31 15:42:03'),
(874, '0000000000093', 1, 'S1203_TK_CIV_EP1', 0.15522, NULL, '[140,[5895,9946,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(875, '0000000000207', 1, 'Ural_UN_EP1', 0.15522, NULL, '[9,[16773.2,6268.66,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(872, '0000000000315', 1, 'AH6X_DZ', 0.62088, NULL, '[338,[8109.2,21168,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(873, '0000500000408', 1, 'rth_raft_small', 0.63875, NULL, '[0,[10656.3,16642.5,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-31 15:42:03'),
(870, '0000000000218', 1, 'rth_scrapbus', 0.29642, NULL, '[290,[15089.2,9334.68,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.61083, '2014-01-31 15:42:03'),
(871, '0000500000466', 1, 'rth_amphicar', 0.62088, NULL, '[358,[8715.87,9137.31,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.87161, '2014-01-31 15:42:03'),
(868, '0000500000329', 1, 'PBX_DZ', 0.15522, NULL, '[210,[5305.11,9213.32,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-31 15:42:03'),
(869, '0000000000373', 1, 'Lada1_TK_CIV_EP1', 0.63875, NULL, '[228,[11063.1,15440.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-31 15:42:03'),
(867, '0000500000441', 1, 'ori_vil_truck_civ1', 0.15522, NULL, '[231,[11840.4,1420.83,0]]', '[]', '[["sklo_p",1],["sklo_p1",0.8],["sklo_l1",0.3],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.4],["palivo",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(729, '0000000000020', 1, 'tractor', 0.15400, NULL, '[100,[4044.82,6359.71,0.241]]', '[[["G36A_camo","BAF_L85A2_RIS_Holo"],[1,1]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.30200, '2014-01-31 19:03:16'),
(866, '0000000000188', 1, 'Old_moto_TK_Civ_EP1', 0.15522, NULL, '[1,[16149.9,11571.7,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(864, '0000000000300', 1, 'MMT_Civ', 0.33109, NULL, '[335,[3934.06,6942.25,0]]', '[]', '[]', 0.09446, '2014-01-31 15:42:03'),
(865, '0000500000443', 1, 'ori_p85_cucv', 0.15522, NULL, '[134,[9547.76,5737.86,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_p2",0.6],["sklo_l1",1],["sklo_l2",0.5],["sklo_z",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.4],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-31 15:42:03'),
(863, '0000000000100', 1, 'datsun1_civil_3_open', 0.15522, NULL, '[90,[6691,9909,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(862, '0000000000357', 1, 'datsun1_civil_2_covered', 0.15522, NULL, '[86,[10524.2,6581.97,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(860, '0000000000203', 1, 'hilux1_civil_1_open', 0.62088, NULL, '[267,[15628.2,8506.59,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(861, '0000000000210', 1, 'Ural_UN_EP1', 0.62088, NULL, '[181,[16312.4,10029.7,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(859, '0000000000255', 1, 'VolhaLimo_TK_CIV_EP1', 0.63875, NULL, '[269,[11225,15951.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-31 15:42:03'),
(894, '0000000000260', 1, 'TT650_Ins', 0.15522, NULL, '[22,[11965.7,15478.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(763, '0000000000091', 1, 'tractor', 0.15500, NULL, '[320,[5986.83,9604.02,0.003]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40500, '2014-01-26 14:18:03'),
(857, '0000000000112', 1, 'TowingTractor', 0.15522, NULL, '[160,[10233,18252,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(689, '0000000000221', 1, 'VolhaLimo_TK_CIV_EP1', 0.15522, NULL, '[180,[14860.6,9331.5,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(858, '0000500000449', 1, 'ori_vil_lublin_truck', 0.63875, NULL, '[289,[17224.3,6902.72,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",0.2],["pravy predni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.2],["sklo predni P",1],["motor",0.7],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-31 15:42:03'),
(758, '0000000000219', 1, 'rth_ScrapBuggy', 0.73922, NULL, '[183,[15442.3,9734.86,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.04671, '2014-01-26 11:54:09'),
(759, '0000000000004', 1, 'ATV_CZ_EP1', 0.62088, NULL, '[300,[3286,6879,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 11:54:09'),
(792, '0000000000103', 1, 'ATV_CZ_EP1', 0.62088, NULL, '[320,[11010,6726,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 12:39:26'),
(757, '0000000000066', 1, 'tractor', 0.15522, NULL, '[100,[8344,5538,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(755, '0000000000152', 1, 'PBX_DZ', 0.15522, NULL, '[90,[11930,20888,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-26 11:54:09'),
(756, '0000500000410', 1, 'rth_raft_small', 0.70281, NULL, '[192,[9886.85,14238.4,0]]', '[]', '[["motor",0.8]]', 0.95020, '2014-01-26 11:54:09'),
(753, '0000000000147', 1, 'PBX_DZ', 0.15522, NULL, '[330,[3735,2339,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-26 11:54:09'),
(754, '0000000000269', 1, 'datsun1_civil_3_open', 0.15522, NULL, '[152,[12645.3,11818.2,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(752, '0000000000051', 1, 'rth_ScrapBuggy', 0.15522, NULL, '[130,[9903,3177,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.40540, '2014-01-26 11:54:09'),
(750, '0000000000184', 1, 'Old_bike_TK_CIV_EP1', 0.90443, NULL, '[84,[17167.6,7385.58,0]]', '[]', '[]', 0.81216, '2014-01-26 11:54:09'),
(751, '0000000000026', 1, 'Ikarus', 0.15522, NULL, '[135,[8805,2318,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(749, '0000000000077', 1, 'Mi17_Civilian_DZ', 0.15522, NULL, '[180,[6927,8343,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(748, '0000000000095', 1, 'rth_ScrapApc', 0.73922, NULL, '[200,[5788,9981,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.04671, '2014-01-26 11:54:09'),
(747, '0000000000298', 1, 'TT650_Gue', 0.15354, NULL, '[115,[7756.91,4270.85,-0.03]]', '[[[],[]],[[],[]],[[],[]]]', '[["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8]]', 0.26612, '2014-01-30 23:06:17'),
(746, '0000000000238', 1, 'rth_ScrapApc', 0.79282, NULL, '[184,[15334.8,10203.3,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.20336, '2014-01-26 11:54:09'),
(744, '0000000000371', 1, 'Old_bike_TK_CIV_EP1', 0.14451, NULL, '[274,[12480.9,13607.9,0]]', '[]', '[]', 0.99974, '2014-01-26 11:54:09'),
(745, '0000000000097', 1, 'Ikarus', 0.62100, NULL, '[180,[5689,9856,0]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87200, '2014-01-26 14:06:49'),
(743, '0000000000037', 1, 'tractor', 0.15522, NULL, '[310,[10495,1086,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(854, '0000500000334', 1, 'Zodiac_DZ', 0.15522, NULL, '[345,[11426,6967.47,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-31 15:42:03'),
(855, '0000000000317', 1, 'UH1H_DZ', 0.62088, NULL, '[341,[12560.9,13713.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(741, '0000500000416', 1, 'rth_raft_small', 0.97895, NULL, '[357,[15392.6,18204.7,0]]', '[]', '[["motor",0.8]]', 0.18541, '2014-01-26 11:54:09'),
(742, '0000000000172', 1, 'UAZ_MG_DZ', 0.15522, NULL, '[171,[17473.5,5221.19,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(740, '0000000000131', 1, 'rth_ScrapBuggy', 0.73922, NULL, '[150,[10970,18710,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.04671, '2014-01-26 11:54:09'),
(739, '0000000000114', 1, 'ATV_CZ_EP1', 0.33109, NULL, '[20,[8126,21347,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-26 11:54:09'),
(738, '0000000000159', 1, 'rth_ScrapBuggy', 0.70281, NULL, '[181,[15445.5,9736.16,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.95020, '2014-01-26 11:54:09'),
(660, '0000500000458', 1, 'ori_vil_truck_civ', 0.15522, NULL, '[262,[11876.8,18618.3,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.9],["palivo",0.6],["motor",0.2],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(736, '0000500000468', 1, 'rth_amphicar', 0.15522, NULL, '[110,[15899.5,10823.5,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.40540, '2014-01-26 11:54:09'),
(737, '0000000000190', 1, 'rth_ScrapApc', 0.77385, NULL, '[11,[16832.1,12608.7,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.31631, '2014-01-26 11:54:09'),
(735, '0000000000294', 1, 'TT650_Gue', 0.15522, NULL, '[216,[3340.57,7630.28,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(733, '0000500000463', 1, 'rth_amphicar', 0.15522, NULL, '[0,[11519.7,329.167,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.40540, '2014-01-26 11:54:09'),
(734, '0000000000268', 1, 'Old_bike_TK_CIV_EP1', 0.87453, NULL, '[271,[12445.2,13531.9,0]]', '[]', '[]', 0.40160, '2014-01-26 11:54:09'),
(732, '0000000000326', 1, 'UAZ_MG_DZ', 0.63875, NULL, '[68,[12604.4,14406.3,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 11:54:09'),
(731, '0000000000372', 1, 'VWGolf', 0.15522, NULL, '[0,[11690.2,15167.7,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(720, '0000000000179', 1, 'Old_bike_TK_CIV_EP1', 0.90443, NULL, '[275,[17694.9,6214.7,0]]', '[]', '[]', 0.81216, '2014-01-26 11:54:09'),
(721, '0000000000052', 1, 'ATV_CZ_EP1', 0.62088, NULL, '[270,[9791,3913,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 11:54:09'),
(705, '0000500000472', 1, 'rth_amphicar', 0.63875, NULL, '[14,[10834.3,14053,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.14186, '2014-01-26 10:08:29'),
(706, '0000500000389', 1, 'UH1H_DZ', 0.62088, NULL, '[182,[22689,19845,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(261, '0000000000019', 1, 'V3S_Civ', 0.19291, NULL, '[270,[3902.85,7068.95,3.815e-06]]', '[[[],[]],[["ItemSodaPepsi","FoodCanBakedBeans","ItemSodaCoke","ItemMorphine"],[1,1,2,1]],[[],[]]]', '[["wheel_1_1_steering",1],["wheel_1_2_steering",1],["wheel_1_3_steering",0.154],["wheel_2_1_steering",1],["wheel_2_2_steering",1],["wheel_2_3_steering",0.174],["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8],["glass1",1],["glass2",1],["glass3",1],["glass4",1]]', 0.40427, '2014-01-30 22:52:12'),
(704, '0000000000302', 1, 'MMT_Civ', 0.05118, NULL, '[294,[5661.55,7314.21,0.007]]', '[[[],[]],[[],[]],[[],[]]]', '[["karoserie",0.231],["wheel_1_damper",0.097]]', 1.00000, '2014-01-29 20:33:45'),
(703, '0000000000224', 1, 'datsun1_civil_3_open', 0.62088, NULL, '[4,[15226.7,9457.74,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(701, '0000000000227', 1, 'MMT_Civ', 0.73922, NULL, '[94,[15234.6,10249.9,0]]', '[]', '[]', 0.04671, '2014-01-26 10:08:29'),
(702, '0000000000139', 1, 'tractor', 0.73922, NULL, '[100,[13502,19393,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.04671, '2014-01-26 10:08:29'),
(700, '0000000000345', 1, 'datsun1_civil_3_open', 0.33109, NULL, '[270,[5737.02,9900.18,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-26 10:08:29'),
(699, '0000000000304', 1, 'Mi17_DZ', 0.15354, NULL, '[136,[7753.99,4266.34,-0.044]]', '[[[],[]],[[],[]],[[],[]]]', '[["glass1",1],["glass3",1],["motor",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1]]', 0.00000, '2014-01-30 23:05:59'),
(725, '0000000000063', 1, 'rth_scrapbus', 0.63875, NULL, '[270,[8997,5424,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-26 11:54:09'),
(698, '0000000000377', 1, 'ATV_CZ_EP1', 0.77385, NULL, '[231,[12347.5,15379.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.31631, '2014-01-26 10:08:29'),
(696, '0000000000355', 1, 'Old_bike_TK_CIV_EP1', 0.41758, NULL, '[151,[9148.38,5465.5,0]]', '[]', '[]', 0.98787, '2014-01-26 10:08:29'),
(694, '0000500000336', 1, 'rth_raft_small', 0.33109, NULL, '[327,[11902.8,1556.55,0]]', '[]', '[["motor",0.8]]', 0.09446, '2014-01-26 10:08:29'),
(695, '0000000000002', 1, 'TT650_Gue', 0.15500, NULL, '[180,[2116.01,7061.91,-0.009]]', '[[[],[]],[[],[]],[[],[]]]', '[["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8]]', 0.40500, '2014-01-30 22:18:38'),
(693, '0000000000137', 1, 'MMT_Civ', 0.63875, NULL, '[90,[13248,19383,0]]', '[]', '[]', 0.14186, '2014-01-26 10:08:29'),
(692, '0000000000324', 1, 'UAZ_MG_DZ', 0.63875, NULL, '[163,[17207.3,5650.31,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(691, '0000000000230', 1, 'TT650_TK_CIV_EP1', 0.33109, NULL, '[0,[14719.8,10259,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-26 10:08:29'),
(690, '0000000000240', 1, 'hilux1_civil_3_open_EP1', 0.15522, NULL, '[90,[15624.2,9573.14,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(688, '0000000000346', 1, 'ATV_CZ_EP1', 0.37364, NULL, '[182,[5987.73,9882.42,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.20358, '2014-01-26 10:08:29'),
(280, '0000000000344', 1, 'MMT_Civ', 0.03150, NULL, '[18,[5283.08,8570.41,0.03]]', '[[[],[]],[[],[]],[[],[]]]', '[["karoserie",0.123],["wheel_1_damper",0.123],["wheel_2_damper",0.123]]', 1.00000, '2014-01-26 12:40:37'),
(686, '0000500000403', 1, 'rth_amphicar', 0.15522, NULL, '[121,[23300.9,19463.1,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.40540, '2014-01-26 10:08:29'),
(685, '0000000000041', 1, 'rth_scrapbus', 0.62088, NULL, '[280,[10968,800,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-26 10:08:29'),
(683, '0000500000342', 1, 'PBX_DZ', 0.63875, NULL, '[219,[7449.91,22134,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-26 10:08:29'),
(684, '0000000000285', 1, 'tractor', 0.70281, NULL, '[222,[14076,12119.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.95020, '2014-01-26 10:08:29'),
(681, '0000000000204', 1, 'datsun1_civil_3_open', 0.62088, NULL, '[267,[15627.7,8512.13,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(680, '0000000000305', 1, 'UH1H_DZ', 0.15522, NULL, '[180,[9349.95,4662.88,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(678, '0000000000254', 1, 'car_sedan', 0.15522, NULL, '[269,[11225.3,15922,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(677, '0000500000455', 1, 'ori_vil_volvo_fl290', 0.15522, NULL, '[289,[15137,14910.4,0]]', '[]', '[["sklo_p",0.7],["sklo_p1",1],["sklo_p2",0.9],["sklo_p3",0.3],["sklo_l1",0.1],["sklo_l2",0.1],["sklo_l3",1],["levy predni tlumic",0.5],["levy zadni tlumic",0.1],["pravy predni tlumic",0.2],["karoserie",0.1],["palivo",0.6],["motor",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(676, '0000000000225', 1, 'hilux1_civil_3_open_EP1', 0.62088, NULL, '[92,[14968.4,10162.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(675, '0000000000192', 1, 'UAZ_Unarmed_TK_EP1', 0.15522, NULL, '[181,[14473.2,11397.9,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(674, '0000000000375', 1, 'SUV_Special', 0.15522, NULL, '[232,[12223.3,15500.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(673, '0000500000456', 1, 'ori_vil_truck_civ2', 0.15522, NULL, '[90,[15359.8,16423.4,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",0.7],["levy predni tlumic",0.1],["levy zadni tlumic",0.1],["pravy predni tlumic",0.3],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.6],["motor",0.5],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(672, '0000500000451', 1, 'ori_vil_volvo_fl290', 0.15522, NULL, '[93,[17407.3,7677.6,0]]', '[]', '[["sklo_p",0.7],["sklo_p1",1],["sklo_p2",0.9],["sklo_p3",0.3],["sklo_l1",0.1],["sklo_l2",0.1],["sklo_l3",1],["levy predni tlumic",0.5],["levy zadni tlumic",0.1],["pravy predni tlumic",0.2],["karoserie",0.1],["palivo",0.6],["motor",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(380, '0000000000006', 1, 'UralCivil', 0.16100, NULL, '[74,[5696.32,7285.55,0.004]]', '[[["Winchester1866","LeeEnfield","ItemToolbox","ItemMap","ItemRadio","Binocular_Vector","AK_74","M24","M4A1","ItemHatchet","ItemKnife","Makarov","ItemCompass","ItemFlashlight","ItemPickaxe"],[1,1,2,2,3,1,1,1,1,4,1,1,1,1,3]],[["ItemWaterbottle","Ori_8Rnd_TT","Ori_20Rnd_APS","ItemJerrycanEmpty","15Rnd_W1866_Slug","ItemBpt_b2","ItemBpt_b3"],[3,1,3,1,1,1,1]],[[],[]]]', '[["glass1",1],["glass2",1],["glass3",1],["glass4",0.169],["wheel_1_1_steering",0.168],["wheel_2_1_steering",0.154],["wheel_1_3_steering",0.154],["wheel_2_3_steering",0.169],["wheel_1_2_steering",0.18],["motor",0.8],["sklo predni P",1],["sklo predni L",1]]', 0.16100, '2014-01-29 19:01:19'),
(670, '0000000000208', 1, 'TT650_Gue', 0.62088, NULL, '[6,[16517.8,9661.72,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(671, '0000000000151', 1, 'rth_raft', 0.62088, NULL, '[180,[11920,20885,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 10:08:29'),
(669, '0000000000369', 1, 'Old_moto_TK_Civ_EP1', 0.15522, NULL, '[359,[15455.9,16387.5,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(850, '0000000000168', 1, 'UAZ_Unarmed_TK_EP1', 0.15522, NULL, '[15,[14510.7,9801.27,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(667, '0000000000174', 1, 'PBX_DZ', 0.63875, NULL, '[321,[17442,4035.92,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-26 10:08:29'),
(668, '0000000000235', 1, 'SUV_Special', 0.15522, NULL, '[4,[15169.5,9692,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(666, '0000000000039', 1, 'datsun1_civil_3_open', 0.15522, NULL, '[220,[10920,819,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(664, '0000000000243', 1, 'MMT_Civ', 0.29642, NULL, '[184,[15415.4,9269.86,0]]', '[]', '[]', 0.61083, '2014-01-26 10:08:29'),
(665, '0000000000056', 1, 'car_sedan', 0.15522, NULL, '[270,[9675,4346,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(663, '0000000000135', 1, 'rth_ScrapBuggy', 0.70281, NULL, '[100,[11110,17900,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.95020, '2014-01-26 10:08:29'),
(662, '0000000000374', 1, 'hilux1_civil_3_open_EP1', 0.33109, NULL, '[186,[11485.4,15949.6,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-26 10:08:29'),
(661, '0000500000461', 1, 'ori_vil_volvo_fl290', 0.63875, NULL, '[319,[10622.9,17315.7,0]]', '[]', '[["sklo_p",0.7],["sklo_p1",1],["sklo_p2",0.9],["sklo_p3",0.3],["sklo_l1",0.1],["sklo_l2",0.1],["sklo_l3",1],["levy predni tlumic",0.5],["levy zadni tlumic",0.1],["pravy predni tlumic",0.2],["karoserie",0.1],["palivo",0.6],["motor",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-26 10:08:29'),
(658, '0000000000173', 1, 'Old_bike_TK_CIV_EP1', 0.34031, NULL, '[5,[17464.2,4106.35,0]]', '[]', '[]', 0.17762, '2014-01-26 10:08:29'),
(659, '0000500000440', 1, 'ori_p85_cucv', 0.15522, NULL, '[169,[11435.5,671.487,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_p2",0.6],["sklo_l1",1],["sklo_l2",0.5],["sklo_z",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.4],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(657, '0000000000092', 1, 'rth_ScrapBuggy', 0.33100, NULL, '[270,[5980,9939.01,-3.815e-06]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_1_2_steering",1],["wheel_2_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.09400, '2014-01-26 14:20:27'),
(656, '0000500000331', 1, 'rth_amphicar', 0.15522, NULL, '[72,[5725.44,10986,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.40540, '2014-01-26 10:08:29'),
(655, '0000500000470', 1, 'rth_amphicar', 0.73922, NULL, '[96,[15174.1,17240.7,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.04671, '2014-01-26 10:08:29'),
(651, '0000000000150', 1, 'rth_raft', 0.62088, NULL, '[60,[957,14105,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 10:08:29'),
(652, '0000000000191', 1, 'Old_bike_TK_CIV_EP1', 0.92378, NULL, '[271,[16972.3,12761.7,0]]', '[]', '[]', 0.55428, '2014-01-26 10:08:29'),
(653, '0000000000196', 1, 'V3S_Civ', 0.15522, NULL, '[87,[16515.1,8085.05,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(779, '0000000000122', 1, 'UAZ_RU', 0.63900, NULL, '[160,[9951,18910,0]]', '[]', '[["glass1",1],["glass2",1],["glass3",1],["wheel_1_1_steering",1],["wheel_1_2_steering",1],["wheel_2_1_steering",1],["wheel_2_2_steering",1],["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8]]', 0.14186, '2014-01-31 19:29:32'),
(649, '0000500000464', 1, 'rth_amphicar', 0.33109, NULL, '[345,[10089.3,3713.94,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.09446, '2014-01-26 10:08:29'),
(648, '0000000000067', 1, 'Skoda', 0.15522, NULL, '[60,[8486,5592,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(647, '0000000000001', 1, 'TT650_Gue', 0.15354, NULL, '[108,[3303.67,7406.67,-0.015]]', '[[[],[]],[[],[]],[[],[]]]', '[["sklo predni P",1],["sklo predni L",1],["karoserie",1],["palivo",0.8]]', 0.36220, '2014-01-30 22:25:57'),
(646, '0000000000328', 1, 'UAZ_MG_DZ', 0.73922, NULL, '[238,[14011.1,12408.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.04671, '2014-01-26 10:08:29'),
(645, '0000000000031', 1, 'LadaLM', 0.15522, NULL, '[300,[8995,2292,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(644, '0000000000115', 1, 'ATV_CZ_EP1', 0.29642, NULL, '[20,[8130,21345,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.61083, '2014-01-26 10:08:29'),
(643, '0000000000054', 1, 'Ikarus', 0.63875, NULL, '[1,[9711,4404,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(724, '0000000000040', 1, 'Ikarus', 0.62088, NULL, '[100,[10946,798,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 11:54:09'),
(641, '0000000000382', 1, 'SUV_Special', 0.63875, NULL, '[184,[16247.6,11578.6,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(640, '0000500000436', 1, 'ori_vil_truck_civ', 0.15522, NULL, '[252,[7834.52,4532.11,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",1],["levy predni tlumic",1],["levy zadni tlumic",1],["pravy zadni tlumic",1],["karoserie",0.9],["palivo",0.6],["motor",0.2],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(639, '0000000000183', 1, 'rth_ScrapApc', 0.77385, NULL, '[272,[17508.4,7194.23,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.31631, '2014-01-26 10:08:29'),
(638, '0000500000447', 1, 'ori_p85_cucv', 0.62088, NULL, '[72,[12791.6,11999.2,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_p2",0.6],["sklo_l1",1],["sklo_l2",0.5],["sklo_z",1],["levy zadni tlumic",1],["pravy predni tlumic",1],["karoserie",0.7],["palivo",0.4],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-26 10:08:29'),
(637, '0000000000206', 1, 'UAZ_MG_DZ', 0.62088, NULL, '[268,[16802.4,6322.28,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(636, '0000000000349', 1, 'datsun1_civil_3_open', 0.70281, NULL, '[130,[9057.69,8128.55,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.95020, '2014-01-26 10:08:29'),
(635, '0000000000215', 1, 'LadaLM', 0.63875, NULL, '[183,[15458.4,10112.1,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(634, '0000000000213', 1, 'UAZ_RU', 0.73922, NULL, '[267,[15457.4,10033.2,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.04671, '2014-01-26 10:08:29'),
(633, '0000000000030', 1, 'S1203_TK_CIV_EP1', 0.15522, NULL, '[120,[8978,2254,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(632, '0000000000347', 1, 'car_sedan', 0.63875, NULL, '[271,[6681.98,9811.98,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(631, '0000500000426', 1, 'rth_copter_green', 0.15522, NULL, '[312,[16438.4,10382.3,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(807, '0000000000060', 1, 'UAZ_RU', 0.15522, NULL, '[120,[9309,5289,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 15:44:23'),
(630, '0000500000420', 1, 'rth_copter_yellow', 0.15522, NULL, '[210,[5471.15,8590.72,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(629, '0000000000292', 1, 'MMT_Civ', 0.37364, NULL, '[339,[3281.25,7548.81,0]]', '[]', '[]', 0.20358, '2014-01-26 10:08:29'),
(628, '0000000000119', 1, 'Old_moto_TK_Civ_EP1', 0.15522, NULL, '[160,[10379,19486,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(722, '0000000000380', 1, 'Old_bike_TK_CIV_EP1', 0.65437, NULL, '[275,[16325.9,13604.8,0]]', '[]', '[]', 0.94014, '2014-01-26 11:54:09'),
(723, '0000000000022', 1, 'TT650_TK_CIV_EP1', 0.15522, NULL, '[90,[6174,5335,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(626, '0000500000471', 1, 'rth_amphicar', 0.29642, NULL, '[277,[11496.3,18552.3,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.61083, '2014-01-26 10:08:29'),
(625, '0000000000282', 1, 'hilux1_civil_3_open_EP1', 0.33109, NULL, '[64,[14114.1,12135.2,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-26 10:08:29'),
(624, '0000000000236', 1, 'SUV_Special', 0.62088, NULL, '[358,[15086.7,9690.3,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(623, '0000000000087', 1, 'Volha_2_TK_CIV_EP1', 0.15522, NULL, '[165,[5568,8952,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(622, '0000500000392', 1, 'UH1H_DZ', 0.33109, NULL, '[219,[22552.3,19667.4,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.09446, '2014-01-26 10:08:29'),
(621, '0000500000425', 1, 'rth_copter_green', 0.15522, NULL, '[358,[15142.1,15854.1,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(620, '0000000000136', 1, 'Old_moto_TK_Civ_EP1', 0.62088, NULL, '[60,[12917,19178,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(418, '37378731420353', 1, 'TentStorageR', 0.00064, 15, '[353,[3737.77,7314.21,0]]', '[[["Binocular"],[2]],[["ItemJerrycan","FoodCanSardines","ItemSodaPepsi","ItemWaterbottleUnfilled"],[2,1,1,1]],[[],[]]]', '[]', 0.00000, '2014-01-26 14:41:25'),
(895, '0000000000124', 1, 'S1203_TK_CIV_EP1', 0.15522, NULL, '[20,[10163,18965,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(682, '0000500000460', 1, 'ori_vil_truck_civ2', 0.15522, NULL, '[156,[10109.1,18055.1,0]]', '[]', '[["sklo_p",1],["sklo_p1",1],["sklo_l1",0.7],["levy predni tlumic",0.1],["levy zadni tlumic",0.1],["pravy predni tlumic",0.3],["pravy zadni tlumic",1],["karoserie",0.7],["palivo",0.6],["motor",0.5],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 10:08:29'),
(765, '0000000000293', 1, 'TT650_TK_CIV_EP1', 0.62088, NULL, '[58,[3301.71,7599.37,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 11:54:09'),
(769, '0000000000322', 1, 'UAZ_MG_DZ', 0.15522, NULL, '[5,[5837.59,9956.13,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 11:54:09'),
(617, '0000500000465', 1, 'rth_amphicar', 0.70281, NULL, '[0,[5207,5616.89,0]]', '[]', '[["LF_hit",1],["LM_hit",1],["LB_hit",0.4],["RF_hit",1],["RM_hit",1],["RB_hit",1],["motor",0.8]]', 0.95020, '2014-01-26 10:08:29'),
(606, '0000000000044', 1, 'SUV_Special', 0.15522, NULL, '[80,[11258,875,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(605, '0000000000246', 1, 'VolhaLimo_TK_CIV_EP1', 0.63875, NULL, '[233,[12494.5,15017.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(604, '0000000000140', 1, 'UAZ_RU', 0.33109, NULL, '[140,[14619,18538,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.09446, '2014-01-26 10:08:29'),
(603, '0000000000311', 1, 'UH1H_DZ', 0.62088, NULL, '[89,[11521.1,15306,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(601, '0000000000086', 1, 'Skoda', 0.62088, NULL, '[160,[5523,8957,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(602, '0000000000318', 1, 'AH6X_DZ', 0.62088, NULL, '[94,[17465.6,7161.06,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29');
INSERT INTO `object_data` (`ObjectID`, `ObjectUID`, `Instance`, `Classname`, `Damage`, `CharacterID`, `Worldspace`, `Inventory`, `Hitpoints`, `Fuel`, `Datestamp`) VALUES
(600, '0000000000068', 1, 'rth_ScrapApc', 0.63875, NULL, '[340,[8235,6094,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.14186, '2014-01-26 10:08:29'),
(598, '0000000000143', 1, 'hilux1_civil_1_open', 0.15354, NULL, '[280,[14849,18489.1,2.861e-06]]', '[[[],[]],[[],[]],[[],[]]]', '[["motor",0.8],["sklo predni P",1],["sklo predni L",1],["karoserie",1],["wheel_2_1_steering",1],["wheel_2_2_steering",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40500, '2014-01-29 21:32:34'),
(599, '0000000000120', 1, 'tractor', 0.73922, NULL, '[300,[10408,19291,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.04671, '2014-01-26 10:08:29'),
(596, '0000500000330', 1, 'Fishing_Boat_DZ', 0.15522, NULL, '[39,[4893.85,8662.77,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-26 10:08:29'),
(597, '0000000000125', 1, 'Ikarus', 0.73922, NULL, '[80,[10254,19037,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.04671, '2014-01-26 10:08:29'),
(595, '0000000000229', 1, 'SUV_Special', 0.62088, NULL, '[0,[15161.2,10052.9,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(594, '0000000000130', 1, 'Ikarus', 0.70281, NULL, '[325,[10934,18768,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.95020, '2014-01-26 10:08:29'),
(593, '0000500000421', 1, 'rth_copter_yellow', 0.62088, NULL, '[94,[8352.01,20842.8,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["elektronika",0.8],["mala vrtule",0.8],["velka vrtule",0.8],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass3",1]]', 0.87161, '2014-01-26 10:08:29'),
(592, '0000000000214', 1, 'Ikarus_TK_CIV_EP1', 0.15522, NULL, '[272,[15840.5,9551.82,0]]', '[]', '[]', 0.40540, '2014-01-26 10:08:29'),
(591, '0000000000035', 1, 'datsun1_civil_2_covered', 0.15522, NULL, '[245,[10051,1375,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(590, '0000000000032', 1, 'car_hatchback', 0.15522, NULL, '[210,[8957,2343,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 10:08:29'),
(419, '37240728900173', 1, 'TentStorageR', 0.00000, 15, '[173,[3723.98,7289.04,0]]', '[[[],[]],[[],[]],[[],[]]]', '[]', 0.00000, '2014-01-24 22:21:15'),
(420, '5690473114084', 1, 'large_shed_lvl_1', 0.00000, 159122886, '[84,[5690.38,7311.41,0],[0.05,0.029,0.998]]', '[[["Mk_48_DZ","M24","SVD_NSPU_EP1","M249_EP1_DZ","NVGoggles","M4A1_HWS_GL","M4A1_Aim","SVD_CAMO","FN_FAL_ANPVS4"],[1,1,1,1,1,1,1,1,1]],[["75Rnd_545x39_RPK","ItemBpt_h3","ItemBpt_g_s","100Rnd_762x54_PK","ItemSodaCoke","FoodCanSardines","FoodCanBakedBeans","20Rnd_762x51_DMR","PartGeneric","FoodCanFrankBeans","PartWheel","FoodCanPasta","Ori_10Rnd_SKS","ItemSodaPepsi","30Rnd_9x19_MP5","Ori_12Rnd_maka","Ori_20Rnd_APS","100Rnd_762x51_M240","64Rnd_9x19_Bizon","ItemPainkiller","ItemBandage","PartEngine","30Rnd_545x39_AKSD","ItemCeMix","PartScrap","ItemCementBag","ItemTankTrap","200Rnd_556x45_M249","ItemLimestone","ItemRWood","ItemRocks","PartWoodPile","10Rnd_762x54_SVD","30Rnd_556x45_G36","2Rnd_shotgun_74Slug","HandChemGreen","30Rnd_545x39_AK"],[2,2,1,2,22,2,12,4,17,2,2,2,2,10,3,1,3,3,1,4,2,4,1,1,5,5,1,2,2,1,112,5,2,4,2,1,1]],[[],[]]]', '[["stage_1",0],["stage_2",0],["Sitto",1.0e07],["passwordtut",8225]]', 0.00000, '2014-01-28 21:35:20'),
(421, '5686973302070', 1, 'large_shed_lvl_1', 0.00000, 162616006, '[70,[5686.9,7330.2,0],[0.05,0.029,0.998]]', '[[["M4A3_CCO_EP1","AKS_74_UN_kobra","BAF_L85A2_UGL_ACOG","SVD_NSPU_EP1","M24","M4A1_HWS_GL","SVD_CAMO","M4A1_Aim","Binocular_Vector"],[1,1,1,1,1,1,2,1,1]],[["FoodCanPasta","FoodCanSardines","ItemSodaCoke","ItemPainkiller","FoodSteakRaw","ItemBandage","ItemMorphine","FoodCanBakedBeans","ItemSodaPepsi","ItemPin","30Rnd_545x39_AK","10Rnd_762x54_SVD","Skin_Sniper1_DZ","30Rnd_545x39_AKSD","17Rnd_9x19_glock17","PartEngine","30Rnd_556x45_Stanag"],[2,1,8,3,1,3,3,4,2,1,2,4,6,4,2,1,10]],[[],[]]]', '[["stage_1",0],["stage_2",0],["Brolo",1.0e07],["passwordtut",2880]]', 0.00000, '2014-01-26 21:03:02'),
(422, '5693672943072', 1, 'large_shed_lvl_1', 0.00000, 159165638, '[72,[5693.56,7294.33,0],[0.032,0.03,0.999]]', '[[["M4A1_Aim","bizon_silenced","AKS_74_pso"],[1,1,1]],[["FoodCanBakedBeans","ItemSodaCoke"],[2,1]],[[],[]]]', '[["stage_1",0],["stage_2",0],["Leroy Jenkins",1.0e07],["passwordtut",1983]]', 0.00000, '2014-01-28 19:28:00'),
(849, '0000000000107', 1, 'TowingTractor', 0.15522, NULL, '[270,[16529,10209,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-31 15:42:03'),
(848, '0000000000278', 1, 'LandRover_TK_CIV_EP1', 0.62088, NULL, '[296,[16716.2,10631.3,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-31 15:42:03'),
(728, '0000500000462', 1, 'ori_vil_volvo_fl290', 0.15522, NULL, '[102,[10145.1,18735.2,0]]', '[]', '[["sklo_p",0.7],["sklo_p1",1],["sklo_p2",0.9],["sklo_p3",0.3],["sklo_l1",0.1],["sklo_l2",0.1],["sklo_l3",1],["levy predni tlumic",0.5],["levy zadni tlumic",0.1],["pravy predni tlumic",0.2],["karoserie",0.1],["palivo",0.6],["motor",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.40540, '2014-01-26 11:54:09'),
(583, '2887870777050', 1, 'small_house_lvl_2', 0.00000, 159122886, '[50,[2887.78,7077.65,0],[-0.015,0.107,0.994]]', '[[["FN_FAL_ANPVS4","M24"],[2,1]],[["ItemLimestone","ItemSodaCoke","30Rnd_545x39_AKSD","ItemBloodbag","FoodCanBakedBeans","Ori_8Rnd_TT","ItemCeMix","20Rnd_762x51_DMR","ItemBattery","20Rnd_762x51_FNFAL","ItemRWood","ItemCinderblocks"],[14,6,1,1,1,1,1,2,1,2,1,3]],[[],[]]]', '[["stage_1",0],["stage_2",0],["stage_2_hide",1],["stage_3",0],["stage_4",0],["Sitto",1.0e07],["passwordtut",8225]]', 0.00000, '2014-01-30 22:15:17'),
(726, '0000000000381', 1, 'MMT_Civ', 0.63875, NULL, '[271,[16326.1,13608.2,0]]', '[]', '[]', 0.14186, '2014-01-26 11:54:09'),
(727, '0000500000332', 1, 'rth_raft_small', 0.63875, NULL, '[131,[7179.07,10223,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-26 11:54:09'),
(793, '0000500000417', 1, 'rth_raft', 0.97895, NULL, '[0,[2451.93,8157.98,0]]', '[]', '[["motor",0.8]]', 0.18541, '2014-01-26 12:39:26'),
(794, '0000000000388', 1, 'rth_ScrapApc', 0.23753, NULL, '[78,[16464.1,9770.87,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.47279, '2014-01-26 12:39:26'),
(795, '0000000000245', 1, 'rth_ScrapBuggy', 0.33109, NULL, '[43,[12719.9,15140.6,0]]', '[]', '[["motor",0.8],["karoserie",0.6],["palivo",0.5],["wheel_1_1_steering",1],["wheel_2_2_steering",1],["front_plow",1]]', 0.09446, '2014-01-26 12:39:26'),
(796, '0000000000023', 1, 'ATV_CZ_EP1', 0.15522, NULL, '[135,[7950,5379,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 12:39:26'),
(797, '0000500000343', 1, 'rth_raft_small', 0.62088, NULL, '[332,[15919.9,6182.26,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 12:39:26'),
(798, '0000500000401', 1, 'rth_raft_small', 0.62088, NULL, '[233,[23116.7,20111,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 12:39:26'),
(799, '0000500000339', 1, 'rth_raft', 0.62088, NULL, '[188,[10521.4,16779.3,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 12:39:26'),
(808, '0000500000402', 1, 'rth_raft', 0.33109, NULL, '[35,[23262.6,19802.5,0]]', '[]', '[["motor",0.8]]', 0.09446, '2014-01-26 15:44:23'),
(809, '0000000000064', 1, 'rth_scrapbus', 0.63875, NULL, '[110,[9037,5416,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-26 15:44:23'),
(810, '0000500000414', 1, 'rth_raft_small', 0.63875, NULL, '[0,[17136.3,14103.9,0]]', '[]', '[["motor",0.8]]', 0.14186, '2014-01-26 15:44:23'),
(811, '0000000000102', 1, 'UAZ_RU', 0.15522, NULL, '[40,[7746,9082,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 15:44:23'),
(812, '0000500000409', 1, 'rth_raft', 0.33109, NULL, '[0,[9465.59,14576.5,0]]', '[]', '[["motor",0.8]]', 0.09446, '2014-01-26 15:44:23'),
(813, '0000000000366', 1, 'ATV_CZ_EP1', 0.62088, NULL, '[326,[10919.7,18760.9,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.87161, '2014-01-26 15:44:23'),
(814, '0000000000356', 1, 'ATV_CZ_EP1', 0.15522, NULL, '[334,[11019.4,6679.71,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 15:44:23'),
(815, '0000000000149', 1, 'rth_raft', 0.15522, NULL, '[270,[6085,1125,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-26 15:44:23'),
(816, '0000000000379', 1, 'ATV_CZ_EP1', 0.15522, NULL, '[92,[13551,13550.6,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1]]', 0.40540, '2014-01-26 15:44:23'),
(817, '0000500000405', 1, 'rth_raft_small', 0.62088, NULL, '[0,[22964.3,18910.3,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 15:44:23'),
(818, '0000000000076', 1, 'rth_scrapbus', 0.63875, NULL, '[20,[7880,7808,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.14186, '2014-01-26 15:44:23'),
(819, '0000000000148', 1, 'rth_raft_small', 0.15522, NULL, '[60,[3743,2331,0]]', '[]', '[["motor",0.8]]', 0.40540, '2014-01-26 15:44:23'),
(820, '0000000000133', 1, 'Old_bike_TK_CIV_EP1', 0.29642, NULL, '[60,[11022,18770,0]]', '[]', '[]', 0.61083, '2014-01-26 15:44:23'),
(821, '0000000000053', 1, 'rth_scrapbus', 0.62088, NULL, '[180,[9705,4389,0]]', '[]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1],["sklo predni P",1],["sklo predni L",1],["glass1",1],["glass2",1],["glass3",1],["front_plow",1],["wheel_guards",1],["window_guards",1],["windshield_guard",1]]', 0.87161, '2014-01-26 15:44:23'),
(822, '0000500000400', 1, 'rth_raft', 0.62088, NULL, '[42,[22818.6,20391.5,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 15:44:23'),
(823, '0000500000411', 1, 'rth_raft', 0.62088, NULL, '[0,[7833.28,19173.6,0]]', '[]', '[["motor",0.8]]', 0.87161, '2014-01-26 15:44:23'),
(842, '0000500001393', 1, 'UralCivil2', 0.05000, 0, '[180,[22462.2,19495.5,0]]', '[[[],[]],[["ItemAntibiotic","ItemBandage","ItemBloodbag","ItemEpinephrine","ItemMorphine","ItemPainkiller","FoodCanBakedBeans","FoodCanFrankBeans","FoodCanPasta","FoodCanSardines","ItemSodaCoke","ItemSodaPepsi","ItemHeatPack"],[15,15,15,15,15,15,15,15,15,15,15,15,15]],[["O_TravelerPack_1","O_MegaPack_1"],[1,1]]]', '[["motor",0.8],["karoserie",1],["palivo",0.8],["wheel_1_1_steering",1],["wheel_2_1_steering",1],["wheel_1_2_steering",1],["wheel_2_2_steering",1]]', 0.01000, '2014-01-31 15:42:03');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `object_spawns`
--

CREATE TABLE IF NOT EXISTS `object_spawns` (
  `ObjectUID` varchar(20) NOT NULL DEFAULT '',
  `Classname` varchar(32) DEFAULT NULL,
  `Worldspace` varchar(64) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ObjectUID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `object_spawns`
--

INSERT INTO `object_spawns` (`ObjectUID`, `Classname`, `Worldspace`, `Description`) VALUES
('0000000000018', 'Old_bike_TK_CIV_EP1', '[210,[3910,7357,0]]', 'Motrovice Statue'),
('0000000000019', 'V3S_Civ', '[270,[3903,7069,0]]', 'Motrovice Fulestation'),
('0000000000020', 'tractor', '[80,[4580,6319,0]]', 'Barn in 045|192'),
('0000000000021', 'Old_bike_TK_CIV_EP1', '[290,[5394,5885,0]]', 'Silos in 053|197'),
('0000000000022', 'TT650_TK_CIV_EP1', '[90,[6174,5335,0]]', 'Lighthouse in 061|202'),
('0000000000023', 'ATV_CZ_EP1', '[135,[7950,5379,0]]', 'Castle Grad Bled'),
('0000000000025', 'Lada1_TK_CIV_EP1', '[145,[8780,2383,0]]', '087|232'),
('0000000000026', 'Ikarus', '[135,[8805,2318,0]]', 'Busstop near Hotel 087|232'),
('0000000000028', 'VWGolf', '[215,[8895,2265,0]]', 'Garage at 086|233'),
('0000000000029', 'MMT_Civ', '[1,[8987,2235,0]]', 'Close to Hospital 089|233'),
('0000000000030', 'S1203_TK_CIV_EP1', '[120,[8978,2254,0]]', 'Hospital 089|233'),
('0000000000031', 'LadaLM', '[300,[8995,2292,0]]', 'Firestation 089|233'),
('0000000000032', 'car_hatchback', '[210,[8957,2343,0]]', '089|232'),
('0000000000033', 'rth_scrapbus', '[320,[9922,1412,0]]', 'Busstop near Hotel 099|241'),
('0000000000034', 'rth_scrapbus', '[140,[9935,1391,0]]', 'Busstop near Hotel 099|241'),
('0000000000035', 'datsun1_civil_2_covered', '[245,[10051,1375,0]]', '100|242'),
('0000000000037', 'tractor', '[310,[10495,1086,0]]', 'Barn 104|245'),
('0000000000038', 'Old_bike_TK_CIV_EP1', '[220,[10889,850,0]]', '108|247'),
('0000000000039', 'datsun1_civil_3_open', '[220,[10920,819,0]]', '109|248'),
('0000000000040', 'Ikarus', '[100,[10946,798,0]]', '109|247'),
('0000000000041', 'rth_scrapbus', '[280,[10968,800,0]]', '109|247'),
('0000000000042', 'rth_ScrapApc', '[130,[10939,868,0]]', '109|247'),
('0000000000043', 'SkodaRed', '[250,[11175,715,0]]', '111|248'),
('0000000000044', 'SUV_Special', '[80,[11258,875,0]]', '112|247'),
('0000000000045', 'rth_ScrapApc', '[270,[11649,773,0]]', 'Fulestation 116|248'),
('0000000000046', 'SkodaGreen', '[120,[11701,749,0]]', '117|258'),
('0000000000047', 'Old_bike_TK_CIV_EP1', '[120,[11760,886,0]]', 'Hotel 117|247'),
('0000000000048', 'UralCivil2', '[320,[11414,1153,0]]', 'Hotel 114|244'),
('0000000000049', 'ATV_CZ_EP1', '[145,[11798,1452,0]]', 'Hotel 117|241'),
('0000000000050', 'Old_bike_TK_CIV_EP1', '[220,[10151,2906,0]]', 'Farm at 101|226'),
('0000000000051', 'rth_ScrapBuggy', '[130,[9903,3177,0]]', 'Cowshed at 099|224'),
('0000000000052', 'ATV_CZ_EP1', '[270,[9791,3913,0]]', 'Farm at 097|216 '),
('0000000000053', 'rth_scrapbus', '[180,[9705,4389,0]]', 'Busstop in front of NPP'),
('0000000000054', 'Ikarus', '[1,[9711,4404,0]]', 'Busstop in front of NPP'),
('0000000000056', 'car_sedan', '[270,[9675,4346,0]]', 'NPP'),
('0000000000057', 'UralCivil', '[90,[9281,4389,0]]', 'NPP'),
('0000000000060', 'UAZ_RU', '[120,[9309,5289,0]]', 'FOB at Kryvoem'),
('0000000000061', 'SkodaBlue', '[270,[9172,5416,0]]', 'Kryvoem'),
('0000000000062', 'Old_bike_TK_CIV_EP1', '[1,[9055,5393,0]]', 'Kryvoem'),
('0000000000063', 'rth_scrapbus', '[270,[8997,5424,0]]', 'Kryvoem'),
('0000000000064', 'rth_scrapbus', '[110,[9037,5416,0]]', 'Kryvoem'),
('0000000000065', 'rth_ScrapBuggy', '[1,[8958,5399,0]]', 'Kryvoem'),
('0000000000066', 'tractor', '[100,[8344,5538,0]]', '083|200'),
('0000000000067', 'Skoda', '[60,[8486,5592,0]]', 'Poljanka'),
('0000000000068', 'rth_ScrapApc', '[340,[8235,6094,0]]', 'Stari Dvor'),
('0000000000069', 'Ikarus', '[160,[8228,6097,0]]', 'Stari Dvor'),
('0000000000070', 'MMT_Civ', '[340,[8248,6115,0]]', 'Stari Dvor'),
('0000000000071', 'SUV_Special', '[60,[7838,6529,0]]', 'Novi Dvor'),
('0000000000072', 'Old_bike_TK_CIV_EP1', '[320,[7914,6697,0]]', 'Novi Dvor'),
('0000000000073', 'V3S_Civ', '[160,[7942,6909,0]]', 'Novi Dvor Factory'),
('0000000000074', 'ATV_CZ_EP1', '[180,[7566,7381,0]]', 'Barn South of Krasnoznamensk Airport'),
('0000000000075', 'rth_scrapbus', '[200,[7873,7799,0]]', 'Busstop at Krasnoznamensk Airport'),
('0000000000076', 'rth_scrapbus', '[20,[7880,7808,0]]', 'Busstop at Krasnoznamensk Airport'),
('0000000000077', 'Mi17_Civilian_DZ', '[180,[6927,8343,0]]', 'Krasnoznamensk Airport'),
('0000000000078', 'LadaLM', '[210,[7453,8090,0]]', 'Krasnoznamensk Airport'),
('0000000000079', 'AN2_DZ', '[220,[7550,8009,0]]', 'Krasnoznamensk Airport'),
('0000000000080', 'rth_ScrapBuggy', '[1,[5180,8089,0]]', 'Barn near Primmorsk'),
('0000000000081', 'MMT_Civ', '[340,[5375,8484,0]]', 'Bilfrad na moru'),
('0000000000086', 'Skoda', '[160,[5523,8957,0]]', 'Bilfrad na moru'),
('0000000000087', 'Volha_2_TK_CIV_EP1', '[165,[5568,8952,0]]', 'Bilfrad na moru'),
('0000000000001', 'TT650_Gue', '[140,[2114,7055,0]]', 'Racetrack'),
('0000000000002', 'TT650_Gue', '[180,[2116,7062,0]]', 'Racetrack'),
('0000000000003', 'MMT_Civ', '[240,[1361,7954,0]]', 'Lighthouse 013|176'),
('0000000000004', 'ATV_CZ_EP1', '[300,[3286,6879,0]]', 'Radiotower 032|187'),
('0000000000005', 'hilux1_civil_3_open_EP1', '[359,[3311,7870,0]]', 'Stangrad Port, between containers'),
('0000000000006', 'UralCivil', '[180,[3413,7869,0]]', 'Stangrad Port'),
('0000000000007', 'Ural_TK_CIV_EP1', '[180,[3427,7869,0]]', 'Stangrad Port'),
('0000000000009', 'rth_ScrapBuggy', '[130,[1634,7604,0]]', 'Stangrad in front of a garage'),
('0000000000010', 'Old_bike_TK_CIV_EP1', '[330,[3290,7529,0]]', 'Stangrad on plaza by church'),
('0000000000011', 'rth_ScrapApc', '[330,[3342,7396,0]]', 'Stangrad firestation'),
('0000000000012', 'Old_moto_TK_Civ_EP1', '[70,[2979,7437,0]]', 'Barn, west of Stangrad'),
('0000000000013', 'LadaLM', '[1,[3796,6887,0]]', 'Motrovice Fire Station'),
('0000000000014', 'rth_ScrapApc', '[180,[3785,6933,0]]', 'Motrovice Bus Stop'),
('0000000000015', 'Ikarus', '[1,[3793,7072,0]]', 'Motrovice Bus Stop'),
('0000000000016', 'VolhaLimo_TK_CIV_EP1', '[1,[3821,7129,0]]', 'Motrovice Hotel'),
('0000000000017', 'SkodaBlue', '[90,[3789,7278,0]]', 'Motrovice Supermarket'),
('0000000000089', 'Old_bike_TK_CIV_EP1', '[260,[5666,8826,0]]', 'Bilfrad na moru'),
('0000000000090', 'rth_ScrapBuggy', '[250,[5504,8802,0]]', 'Bilfrad na moru'),
('0000000000091', 'tractor', '[320,[5987,9604,0]]', 'Barn near Cernovar'),
('0000000000092', 'rth_ScrapBuggy', '[270,[5980,9939,0]]', 'Cernovar'),
('0000000000093', 'S1203_TK_CIV_EP1', '[140,[5895,9946,0]]', 'Cernovar'),
('0000000000094', 'Old_bike_TK_CIV_EP1', '[270,[5850,9901,0]]', 'Cernovar'),
('0000000000095', 'rth_ScrapApc', '[200,[5788,9981,0]]', 'Cernovar'),
('0000000000096', 'Skoda', '[270,[5715,9903,0]]', 'Cernovar'),
('0000000000097', 'Ikarus', '[180,[5689,9856,0]]', 'Cernovar'),
('0000000000098', 'rth_scrapbus', '[1,[5693,9880,0]]', 'Cernovar'),
('0000000000099', 'UralCivil2', '[1,[5532,9750,0]]', 'Cernovar Port'),
('0000000000100', 'datsun1_civil_3_open', '[90,[6691,9909,0]]', 'Vedic'),
('0000000000101', 'Mi17_Civilian_DZ', '[180,[7799,9079,0]]', 'FOB near Berstuk'),
('0000000000102', 'UAZ_RU', '[40,[7746,9082,0]]', 'FOB near Berstuk'),
('0000000000103', 'ATV_CZ_EP1', '[320,[11010,6726,0]]', 'Grad Krkov'),
('0000000000104', 'UAZ_RU', '[60,[10395,6751,0]]', 'FOB near Komarovo'),
('0000000000105', 'Lada1', '[350,[10636,6518,0]]', 'Komarovo'),
('0000000000106', 'LandRover_TK_CIV_EP1', '[300,[10644,6569,0]]', 'Komarovo'),
('0000000000107', 'TowingTractor', '[270,[16529,10209,0]]', 'Airport Dubovo'),
('0000000000108', 'LadaLM', '[320,[16704,10623,0]]', 'Airport Dubovo'),
('0000000000109', 'AN2_DZ', '[270,[16730,10484,0]]', 'Airport Dubovo'),
('0000000000110', 'Mi17_Civilian_DZ', '[90,[16649,11577,0]]', 'Airport Dubovo'),
('0000000000111', 'AN2_DZ', '[240,[10285,18406,0]]', 'Jaroslavski Airport'),
('0000000000112', 'TowingTractor', '[160,[10233,18252,0]]', 'Jaroslavski Airport'),
('0000000000113', 'Mi17_Civilian_DZ', '[90,[10208,18667,0]]', 'Jaroslavski Airport'),
('0000000000114', 'ATV_CZ_EP1', '[20,[8126,21347,0]]', 'Helfenburg'),
('0000000000115', 'ATV_CZ_EP1', '[20,[8130,21345,0]]', 'Helfenburg'),
('0000000000116', 'rth_ScrapBuggy', '[150,[8878,19712,0]]', 'Barn North of Kameni'),
('0000000000117', 'rth_ScrapApc', '[330,[8839,19446,0]]', 'Kameni'),
('0000000000118', 'rth_ScrapApc', '[40,[8836,19438,0]]', 'Kameni'),
('0000000000119', 'Old_moto_TK_Civ_EP1', '[160,[10379,19486,0]]', 'Barn North of Yaroslav'),
('0000000000120', 'tractor', '[300,[10408,19291,0]]', 'Barn Nort of Yaroslav'),
('0000000000121', 'Mi17_Civilian_DZ', '[290,[9983,18892,0]]', 'FOB near Yaroslav'),
('0000000000122', 'UAZ_RU', '[160,[9951,18910,0]]', 'FOB near Yaroslav'),
('0000000000123', 'V3S_Civ', '[30,[9937,19091,0]]', 'Lumbermill west of Yaroslav'),
('0000000000124', 'S1203_TK_CIV_EP1', '[20,[10163,18965,0]]', 'Yaroslav Firestation'),
('0000000000125', 'Ikarus', '[80,[10254,19037,0]]', 'Yaroslav Busstop'),
('0000000000126', 'rth_scrapbus', '[260,[10238,19038,0]]', 'Yaroslav Busstop'),
('0000000000127', 'hilux1_civil_1_open', '[260,[10314,19140,0]]', 'Yaroslav'),
('0000000000128', 'V3S_Civ', '[250,[10177,19193,0]]', 'Yaroslav'),
('0000000000129', 'rth_scrapbus', '[150,[10929,18768,0]]', 'Ekaterinburg'),
('0000000000130', 'Ikarus', '[325,[10934,18768,0]]', 'Ekaterinburg'),
('0000000000131', 'rth_ScrapBuggy', '[150,[10970,18710,0]]', 'Ekaterinburg'),
('0000000000132', 'Lada1', '[300,[11056,18699,0]]', 'Ekaterinburg'),
('0000000000133', 'Old_bike_TK_CIV_EP1', '[60,[11022,18770,0]]', 'Ekaterinburg'),
('0000000000134', 'Ural_TK_CIV_EP1', '[100,[10976,19033,0]]', 'Ekaterinburg'),
('0000000000135', 'rth_ScrapBuggy', '[100,[11110,17900,0]]', 'Duge Selo'),
('0000000000136', 'Old_moto_TK_Civ_EP1', '[60,[12917,19178,0]]', 'Barn West of Khotanovsk'),
('0000000000137', 'MMT_Civ', '[90,[13248,19383,0]]', 'Barn West of Khotanovsk'),
('0000000000138', 'rth_scrapbus', '[110,[13443,19388,0]]', 'Khotanovsk'),
('0000000000139', 'tractor', '[100,[13502,19393,0]]', 'Khotanovsk'),
('0000000000140', 'UAZ_RU', '[140,[14619,18538,0]]', 'FOB near Dalnogorsk'),
('0000000000142', 'TT650_TK_CIV_EP1', '[230,[15135,18238,0]]', 'Dalnogorsk'),
('0000000000143', 'hilux1_civil_1_open', '[280,[14849,18489,0]]', 'Dalnogorsk Port'),
('0000000000144', 'hilux1_civil_2_covered', '[320,[14881,18583,0]]', 'Dalnogorsk Port'),
('0000000000145', 'ATV_CZ_EP1', '[260,[15715,17082,0]]', 'Antenna at Zeleny Vrh'),
('0000000000146', 'UAZ_RU', '[220,[15077,15937,0]]', 'FOB near Sevastopol'),
('0000000000147', 'PBX_DZ', '[330,[3735,2339,0]]', 'Ostrov Knin'),
('0000000000148', 'rth_raft_small', '[60,[3743,2331,0]]', 'Ostrov Knin'),
('0000000000149', 'rth_raft', '[270,[6085,1125,0]]', 'Ostrov Ash'),
('0000000000150', 'rth_raft', '[60,[957,14105,0]]', 'Isle Kres'),
('0000000000151', 'rth_raft', '[180,[11920,20885,0]]', 'Isle Shibenik'),
('0000000000152', 'PBX_DZ', '[90,[11930,20888,0]]', 'Isle Shibenik'),
('0000000000153', 'Fishing_Boat_DZ', '[280,[11695,18963,0]]', 'Ekatinburg Port'),
('0000000000154', 'Fishing_boat_DZ', '[90,[14753,18757,0]]', 'Balnogorsk Port'),
('0000000000155', 'rth_raft_small', '[90,[17420,12576,0]]', 'Molotovsk Port'),
('0000000000156', 'rth_ScrapApc', '[0,[14574.9,10474.6,0]]', NULL),
('0000000000158', 'Old_bike_TK_CIV_EP1', '[2,[15160.3,9868.98,0]]', NULL),
('0000000000159', 'rth_ScrapBuggy', '[181,[15445.5,9736.16,0]]', NULL),
('0000000000160', 'rth_ScrapApc', '[274,[15547.1,9505.82,0]]', NULL),
('0000000000161', 'VolhaLimo_TK_CIV_EP1', '[4,[15474.3,9375.65,0]]', NULL),
('0000000000162', 'MMT_Civ', '[185,[15391.3,9277.98,0]]', NULL),
('0000000000165', 'rth_ScrapApc', '[108,[15408.7,8961.51,0]]', NULL),
('0000000000167', 'UAZ_Unarmed_TK_CIV_EP1', '[93,[15655.4,9620.11,0]]', NULL),
('0000000000168', 'UAZ_Unarmed_TK_EP1', '[15,[14510.7,9801.27,0]]', NULL),
('0000000000169', 'Volha_2_TK_CIV_EP1', '[2,[14993.4,9260.11,0]]', NULL),
('0000000000170', 'Lada2_TK_CIV_EP1', '[208,[15186.7,9188.3,0]]', NULL),
('0000000000171', 'Mi17_Civilian_DZ', '[0,[17442,5212,0]]', NULL),
('0000000000172', 'UAZ_MG_DZ', '[171,[17473.5,5221.19,0]]', NULL),
('0000000000173', 'Old_bike_TK_CIV_EP1', '[5,[17464.2,4106.35,0]]', NULL),
('0000000000174', 'PBX_DZ', '[321,[17442,4035.92,0]]', NULL),
('0000000000175', 'Old_bike_TK_CIV_EP1', '[2,[18421.7,5059.4,0]]', NULL),
('0000000000178', 'hilux1_civil_2_covered', '[0,[17683.4,6186.37,0]]', NULL),
('0000000000179', 'Old_bike_TK_CIV_EP1', '[275,[17694.9,6214.7,0]]', NULL),
('0000000000182', 'datsun1_civil_3_open', '[130,[17837.9,6490.08,0]]', NULL),
('0000000000183', 'rth_ScrapApc', '[272,[17508.4,7194.23,0]]', NULL),
('0000000000184', 'Old_bike_TK_CIV_EP1', '[84,[17167.6,7385.58,0]]', NULL),
('0000000000185', 'UAZ_RU', '[181,[17216.7,7662.86,0]]', NULL),
('0000000000187', 'Old_bike_TK_CIV_EP1', '[357,[16243.7,11497,0]]', NULL),
('0000000000188', 'Old_moto_TK_Civ_EP1', '[1,[16149.9,11571.7,0]]', NULL),
('0000000000189', 'rth_ScrapBuggy', '[3,[16279.2,11705.8,0]]', NULL),
('0000000000190', 'rth_ScrapApc', '[11,[16832.1,12608.7,0]]', NULL),
('0000000000191', 'Old_bike_TK_CIV_EP1', '[271,[16972.3,12761.7,0]]', NULL),
('0000000000192', 'UAZ_Unarmed_TK_EP1', '[181,[14473.2,11397.9,0]]', NULL),
('0000000000193', 'Lada1', '[178,[17244.4,7422.91,0]]', NULL),
('0000000000194', 'rth_ScrapApc', '[302,[16788,8455.63,0]]', NULL),
('0000000000195', 'Old_bike_TK_CIV_EP1', '[87,[16564.4,8259.9,0]]', NULL),
('0000000000196', 'V3S_Civ', '[87,[16515.1,8085.05,0]]', NULL),
('0000000000197', 'Old_bike_TK_CIV_EP1', '[272,[16520,8380.6,0]]', NULL),
('0000000000198', 'TT650_Gue', '[261,[16877.2,8197.77,0]]', NULL),
('0000000000199', 'rth_ScrapApc', '[167,[17301.6,8240.52,0]]', NULL),
('0000000000201', 'UAZ_RU', '[130,[13405.5,8632.01,0]]', NULL),
('0000000000202', 'Old_bike_TK_CIV_EP1', '[88,[15526.4,8412.45,0]]', NULL),
('0000000000203', 'hilux1_civil_1_open', '[267,[15628.2,8506.59,0]]', NULL),
('0000000000204', 'datsun1_civil_3_open', '[267,[15627.7,8512.13,0]]', NULL),
('0000000000205', 'TT650_TK_CIV_EP1', '[108,[16432.5,6287.62,0]]', NULL),
('0000000000206', 'UAZ_MG_DZ', '[268,[16802.4,6322.28,0]]', NULL),
('0000000000207', 'Ural_UN_EP1', '[9,[16773.2,6268.66,0]]', NULL),
('0000000000208', 'TT650_Gue', '[6,[16517.8,9661.72,0]]', NULL),
('0000000000210', 'Ural_UN_EP1', '[181,[16312.4,10029.7,0]]', NULL),
('0000000000211', 'rth_ScrapApc', '[140,[17479.9,9193.12,0]]', NULL),
('0000000000212', 'rth_ScrapApc', '[335,[3102.28,2469.19,0]]', NULL),
('0000000000213', 'UAZ_RU', '[267,[15457.4,10033.2,0]]', NULL),
('0000000000214', 'Ikarus_TK_CIV_EP1', '[272,[15840.5,9551.82,0]]', NULL),
('0000000000215', 'LadaLM', '[183,[15458.4,10112.1,0]]', NULL),
('0000000000216', 'rth_ScrapApc', '[107,[15799.4,9042.73,0]]', NULL),
('0000000000217', 'hilux1_civil_3_open_EP1', '[270,[14742,9858.23,0]]', NULL),
('0000000000218', 'rth_scrapbus', '[290,[15089.2,9334.68,0]]', NULL),
('0000000000219', 'rth_ScrapBuggy', '[183,[15442.3,9734.86,0]]', NULL),
('0000000000220', 'rth_ScrapApc', '[183,[14533.3,10395.5,0]]', NULL),
('0000000000221', 'VolhaLimo_TK_CIV_EP1', '[180,[14860.6,9331.5,0]]', NULL),
('0000000000222', 'UAZ_RU', '[274,[14646.1,9984.8,0]]', NULL),
('0000000000223', 'VWGolf', '[269,[15480.1,9470.94,0]]', NULL),
('0000000000224', 'datsun1_civil_3_open', '[4,[15226.7,9457.74,0]]', NULL),
('0000000000225', 'hilux1_civil_3_open_EP1', '[92,[14968.4,10162.8,0]]', NULL),
('0000000000226', 'MMT_Civ', '[268,[15840.2,9385.28,0]]', NULL),
('0000000000227', 'MMT_Civ', '[94,[15234.6,10249.9,0]]', NULL),
('0000000000228', 'Old_bike_TK_CIV_EP1', '[3,[14736.3,9524.02,0]]', NULL),
('0000000000229', 'SUV_Special', '[0,[15161.2,10052.9,0]]', NULL),
('0000000000230', 'TT650_TK_CIV_EP1', '[0,[14719.8,10259,0]]', NULL),
('0000000000231', 'SkodaGreen', '[91,[14611.5,10154.7,0]]', NULL),
('0000000000232', 'SkodaRed', '[111,[15348.2,9014.43,0]]', NULL),
('0000000000233', 'car_sedan', '[269,[14730.8,9807.05,0]]', NULL),
('0000000000234', 'hilux1_civil_1_open', '[3,[15476.7,9622.34,0]]', NULL),
('0000000000235', 'SUV_Special', '[4,[15169.5,9692,0]]', NULL),
('0000000000236', 'SUV_Special', '[358,[15086.7,9690.3,0]]', NULL),
('0000000000237', 'rth_ScrapApc', '[207,[15179.4,9174.63,0]]', NULL),
('0000000000238', 'rth_ScrapApc', '[184,[15334.8,10203.3,0]]', NULL),
('0000000000239', 'Volha_2_TK_CIV_EP1', '[95,[15589.6,9575.94,0]]', NULL),
('0000000000240', 'hilux1_civil_3_open_EP1', '[90,[15624.2,9573.14,0]]', NULL),
('0000000000242', 'Lada2_TK_CIV_EP1', '[92,[14937.8,9863.08,0]]', NULL),
('0000000000243', 'MMT_Civ', '[184,[15415.4,9269.86,0]]', NULL),
('0000000000245', 'rth_ScrapBuggy', '[43,[12719.9,15140.6,0]]', NULL),
('0000000000246', 'VolhaLimo_TK_CIV_EP1', '[233,[12494.5,15017.8,0]]', NULL),
('0000000000247', 'MMT_Civ', '[224,[12617.1,15157.4,0]]', NULL),
('0000000000248', 'Old_bike_TK_CIV_EP1', '[184,[13583,13523.8,0]]', NULL),
('0000000000249', 'rth_ScrapBuggy', '[272,[13591.4,13550.2,0]]', NULL),
('0000000000250', 'SUV_Special', '[84,[13715.5,13634.7,0]]', NULL),
('0000000000252', 'rth_ScrapBuggy', '[272,[11225.3,15895.6,0]]', NULL),
('0000000000253', 'Skoda', '[272,[11225.3,15905.5,0]]', NULL),
('0000000000254', 'car_sedan', '[269,[11225.3,15922,0]]', NULL),
('0000000000255', 'VolhaLimo_TK_CIV_EP1', '[269,[11225,15951.4,0]]', NULL),
('0000000000256', 'Old_bike_TK_CIV_EP1', '[101,[11515.3,15963.1,0]]', NULL),
('0000000000257', 'Ikarus', '[180,[11634.9,15762.2,0]]', NULL),
('0000000000258', 'VWGolf', '[155,[11894.7,15692.8,0]]', NULL),
('0000000000259', 'rth_ScrapApc', '[326,[11922.9,15458,0]]', NULL),
('0000000000260', 'TT650_Ins', '[22,[11965.7,15478.4,0]]', NULL),
('0000000000261', 'UAZ_Unarmed_TK_EP1', '[126,[11720.4,14881.3,0]]', NULL),
('0000000000262', 'rth_ScrapApc', '[125,[11704.6,14860.7,0]]', NULL),
('0000000000263', 'Old_bike_TK_CIV_EP1', '[182,[11338.4,15214.4,0]]', NULL),
('0000000000264', 'ATV_US_EP1', '[301,[12340.2,15732.9,0]]', NULL),
('0000000000265', 'rth_ScrapBuggy', '[157,[12459.7,13732.3,0]]', NULL),
('0000000000266', 'LandRover_CZ_EP1', '[8,[12521.9,13577.1,0]]', NULL),
('0000000000267', 'rth_ScrapApc', '[80,[12627.7,13612.9,0]]', NULL),
('0000000000268', 'Old_bike_TK_CIV_EP1', '[271,[12445.2,13531.9,0]]', NULL),
('0000000000269', 'datsun1_civil_3_open', '[152,[12645.3,11818.2,0]]', NULL),
('0000000000270', 'Ikarus_TK_CIV_EP1', '[360,[12628.4,11741,0]]', NULL),
('0000000000271', 'Old_bike_TK_CIV_EP1', '[74,[12825.9,11892.3,0]]', NULL),
('0000000000272', 'hilux1_civil_2_covered', '[306,[16137.5,13478.8,0]]', NULL),
('0000000000273', 'Ikarus', '[360,[16282.4,13657.6,0]]', NULL),
('0000000000274', 'TT650_TK_CIV_EP1', '[8,[15724.4,13410.8,0]]', NULL),
('0000000000275', 'rth_ScrapApc', '[170,[14844.5,18574.7,0]]', NULL),
('0000000000276', 'rth_ScrapBuggy', '[4,[15065.4,18458.4,0]]', NULL),
('0000000000278', 'LandRover_TK_CIV_EP1', '[296,[16716.2,10631.3,0]]', NULL),
('0000000000279', 'Old_bike_TK_CIV_EP1', '[359,[14462.5,11394.3,0]]', NULL),
('0000000000280', 'SUV_Special', '[33,[14265.1,11259.9,0]]', NULL),
('0000000000281', 'VolhaLimo_TK_CIV_EP1', '[255,[14494.9,11287.3,0]]', NULL),
('0000000000282', 'hilux1_civil_3_open_EP1', '[64,[14114.1,12135.2,0]]', NULL),
('0000000000283', 'Old_bike_TK_CIV_EP1', '[343,[14165,11955.4,0]]', NULL),
('0000000000284', 'rth_scrapbus', '[338,[14131.7,12000.6,0]]', NULL),
('0000000000285', 'tractor', '[222,[14076,12119.8,0]]', NULL),
('0000000000286', 'Lada1_TK_CIV_EP1', '[241,[13994.2,12219.7,0]]', NULL),
('0000000000288', 'Old_bike_TK_CIV_EP1', '[177,[13943.9,12323.5,0]]', NULL),
('0000000000289', 'rth_ScrapApc', '[135,[13755.5,12224.9,0]]', NULL),
('0000000000290', 'hilux1_civil_2_covered', '[1,[9650,6007,0]]', 'Barn north of Repkov'),
('0000000000291', 'Old_bike_TK_CIV_EP1', '[113,[3278.82,7485.31,0]]', 'Spawn city'),
('0000000000292', 'MMT_Civ', '[339,[3281.25,7548.81,0]]', 'Spawn city'),
('0000000000293', 'TT650_TK_CIV_EP1', '[58,[3301.71,7599.37,0]]', 'Spawn city'),
('0000000000294', 'TT650_Gue', '[216,[3340.57,7630.28,0]]', 'Spawn city'),
('0000000000295', 'Old_bike_TK_CIV_EP1', '[178,[3424.7,7552.19,0]]', 'Spawn city'),
('0000000000296', 'MMT_Civ', '[4,[3804.54,7187.21,0]]', 'Spawn city'),
('0000000000297', 'TT650_TK_CIV_EP1', '[138,[3799.18,7098.58,0]]', 'Spawn city'),
('0000000000298', 'TT650_Gue', '[180,[3710.04,7017.32,0]]', 'Spawn city'),
('0000000000299', 'Old_bike_TK_CIV_EP1', '[230,[3821.48,6877.06,0]]', 'Spawn city'),
('0000000000300', 'MMT_Civ', '[335,[3934.06,6942.25,0]]', 'Spawn city'),
('0000000000301', 'Old_bike_TK_CIV_EP1', '[20,[3905.72,7077.5,0]]', 'Spawn city'),
('0000000000302', 'MMT_Civ', '[96,[3963.42,7156.45,0]]', 'Spawn city'),
('0000000000303', 'Old_bike_TK_CIV_EP1', '[21,[3985.11,7341.37,0]]', 'Spawn city'),
('0000000000304', 'Mi17_DZ', '[136,[7754.04,4266.49,0]]', 'Branibor Tv-tower'),
('0000000000305', 'UH1H_DZ', '[180,[9349.95,4662.88,0]]', 'NPP'),
('0000000000306', 'AH6X_DZ', '[117,[11574.3,648.71,0]]', 'Shore at Blato'),
('0000000000307', 'rth_copter_green', '[38,[9320.15,7765.53,0]]', 'Krasnoznamensk'),
('0000000000308', 'UH1H_DZ', '[252,[5317.76,8620.61,0]]', 'Bilgrad Na Moru'),
('0000000000309', 'AH6X_DZ', '[325,[5987.66,9657.02,0]]', 'Chernovar next to the broken barn'),
('0000000000310', 'Mi17_DZ', '[1,[15379.4,9707.99,0]]', 'Sabina Hospital'),
('0000000000311', 'UH1H_DZ', '[89,[11521.1,15306,0]]', 'Lypestok football stadium'),
('0000000000312', 'AH6X_DZ', '[269,[14520.7,11411.9,0]]', 'Novi Bor Construction Site'),
('0000000000313', 'rth_copter_green', '[88,[16754.3,6317.61,0]]', 'Stare Pol military base'),
('0000000000314', 'UH1H_DZ', '[3,[16966.1,12568.3,0]]', 'Molotovsk hotel'),
('0000000000315', 'AH6X_DZ', '[338,[8109.2,21168,0]]', 'Helfenburg'),
('0000000000316', 'Mi17_DZ', '[90,[15439.5,16282.2,0]]', 'Sevastopol firestation'),
('0000000000317', 'UH1H_DZ', '[341,[12560.9,13713.4,0]]', 'Doriyanov military base'),
('0000000000318', 'AH6X_DZ', '[94,[17465.6,7161.06,0]]', 'Byelov inner yard'),
('0000000000319', 'Pickup_PK_DZ', '[229,[11035.2,6675.03,0]]', 'Krkav'),
('0000000000320', 'UAZ_MG_DZ', '[32,[9336.4,5230.6,0]]', 'military base east of Kryvoe'),
('0000000000321', 'Pickup_PK_DZ', '[217,[7749.32,7894.98,0]]', 'Krasnoznamensk Airfield'),
('0000000000322', 'UAZ_MG_DZ', '[5,[5837.59,9956.13,0]]', 'Chernova Police Station'),
('0000000000323', 'origins_bathmobile', '[9,[13368,8591.33,0]]', 'Chertova Styena'),
('0000000000324', 'UAZ_MG_DZ', '[163,[17207.3,5650.31,0]]', 'military base south of Stare Pole'),
('0000000000325', 'Pickup_PK_DZ', '[89,[16428.8,14267.4,0]]', 'Martin military base ( barracks)'),
('0000000000326', 'UAZ_MG_DZ', '[68,[12604.4,14406.3,0]]', 'Chrveni Gradok firestation'),
('0000000000327', 'origins_bathmobile', '[59,[11098.3,18706.2,0]]', 'Ekaterinburg'),
('0000000000328', 'UAZ_MG_DZ', '[238,[14011.1,12408.4,0]]', 'Solibor military base'),
('0000500000329', 'PBX_DZ', '[210,[5305.11,9213.32,0]]', 'Shore near Bilgrad Na Moru'),
('0000500000330', 'Fishing_Boat_DZ', '[39,[4893.85,8662.77,0]]', 'Shore of Primorsk'),
('0000500000331', 'rth_amphicar', '[72,[5725.44,10986,0]]', 'Borovska Lighthouse'),
('0000500000332', 'rth_raft_small', '[131,[7179.07,10223,0]]', 'Shore near Vucor'),
('0000500000333', 'Fishing_Boat_DZ', '[131,[9016.48,8918.07,0]]', 'Shore near Nekmir'),
('0000500000334', 'Zodiac_DZ', '[345,[11426,6967.47,0]]', 'Krkav Shore'),
('0000500000335', 'Fishing_Boat_DZ', '[148,[10850.9,6061.89,0]]', 'Komarovo Lighthouse'),
('0000500000336', 'rth_raft_small', '[327,[11902.8,1556.55,0]]', 'Vodice'),
('0000500000337', 'Zodiac_DZ', '[90,[10120.1,5358.97,0]]', 'Bashka Luka shore'),
('0000500000338', 'Fishing_Boat_DZ', '[334,[16789.4,4734.12,0]]', 'Chertovo Oko Southwest shore'),
('0000500000339', 'rth_raft', '[188,[10521.4,16779.3,0]]', 'Lyubol harbor'),
('0000500000340', 'rth_raft_small', '[169,[10360.8,16778.9,0]]', 'Lyubol harbor'),
('0000500000341', 'Fishing_Boat_DZ', '[163,[9750.54,14107.1,0]]', 'Cherveny Les Lighthouse'),
('0000500000342', 'PBX_DZ', '[219,[7449.91,22134,0]]', 'Helfenburg northern Lighthouse'),
('0000500000343', 'rth_raft_small', '[332,[15919.9,6182.26,0]]', 'Stare pole Lighthouse'),
('0000000000346', 'ATV_CZ_EP1', '[182,[5987.73,9882.42,0]]', 'Chernovar'),
('0000000000347', 'car_sedan', '[271,[6681.98,9811.98,0]]', 'Vedich'),
('0000000000348', 'MMT_Civ', '[186,[6735.83,9889.73,0]]', 'Vedich'),
('0000000000349', 'datsun1_civil_3_open', '[130,[9057.69,8128.55,0]]', 'Krasnoznamensk'),
('0000000000350', 'Lada2_TK_CIV_EP1', '[220,[9535.59,7952.92,0]]', 'Krasnoznamensk'),
('0000000000351', 'TT650_Civ', '[228,[9080.3,7858.84,0]]', 'Krasnoznamensk'),
('0000000000352', 'ATV_CZ_EP1', '[128,[8958.34,8343.56,0]]', 'Krasnoznamensk'),
('0000000000353', 'rth_ScrapBuggy', '[326,[8066.62,6557.08,0]]', 'Novi Dvor'),
('0000000000354', 'MMT_Civ', '[60,[8483.98,5597.04,0]]', 'Polyanka'),
('0000000000355', 'Old_bike_TK_CIV_EP1', '[151,[9148.38,5465.5,0]]', 'Kryvoe'),
('0000000000356', 'ATV_CZ_EP1', '[334,[11019.4,6679.71,0]]', 'Krkav'),
('0000000000357', 'datsun1_civil_2_covered', '[86,[10524.2,6581.97,0]]', 'Komarovo'),
('0000000000358', 'ATV_CZ_EP1', '[263,[10655.4,6465.89,0]]', 'Komarovo'),
('0000000000359', 'Old_bike_TK_CIV_EP1', '[48,[10862.9,6126.65,0]]', 'Komarovo'),
('0000000000360', 'car_hatchback', '[228,[10017.9,1323.86,0]]', 'Marina'),
('0000000000361', 'rth_ScrapBuggy', '[136,[9638.87,1751.53,0]]', 'Kosovo'),
('0000000000362', 'Ikarus_TK_CIV_EP1', '[221,[7582.17,4367.27,0]]', 'Branibor'),
('0000000000363', 'TT650_Civ', '[226,[7913.65,4156.75,0]]', 'Branibor'),
('0000000000364', 'Old_moto_TK_Civ_EP1', '[305,[7935.54,5362.72,0]]', 'Bled'),
('0000000000366', 'ATV_CZ_EP1', '[326,[10919.7,18760.9,0]]', 'Ekaterinburg'),
('0000000000367', 'Skoda', '[282,[11295.9,17805.4,0]]', 'Duge Selo'),
('0000000000368', 'rth_ScrapBuggy', '[28,[15335.2,16080.1,0]]', 'Sevastopol'),
('0000000000369', 'Old_moto_TK_Civ_EP1', '[359,[15455.9,16387.5,0]]', 'Sevastopol'),
('0000000000370', 'SUV_Special', '[195,[12441.5,13807.4,0]]', 'Doriyanov'),
('0000000000371', 'Old_bike_TK_CIV_EP1', '[274,[12480.9,13607.9,0]]', 'Doriyanov'),
('0000000000372', 'VWGolf', '[0,[11690.2,15167.7,0]]', 'Lypestok'),
('0000000000373', 'Lada1_TK_CIV_EP1', '[228,[11063.1,15440.8,0]]', 'Lypestok'),
('0000000000374', 'hilux1_civil_3_open_EP1', '[186,[11485.4,15949.6,0]]', 'Lypestok'),
('0000000000375', 'SUV_Special', '[232,[12223.3,15500.4,0]]', 'Lypestok'),
('0000000000376', 'TT650_Civ', '[315,[11776.9,15325.2,0]]', 'Lypestok'),
('0000000000377', 'ATV_CZ_EP1', '[231,[12347.5,15379.8,0]]', 'Lypestok'),
('0000000000343', 'ATV_CZ_EP1', '[132,[3334.44,7605.02,0]]', 'Stangrad'),
('0000000000344', 'MMT_Civ', '[353,[5335.44,8844.42,0]]', 'Bilgrad Na Moru'),
('0000000000345', 'datsun1_civil_3_open', '[270,[5737.02,9900.18,0]]', 'Chernovar'),
('0000000000379', 'ATV_CZ_EP1', '[92,[13551,13550.6,0]]', 'Vinograd'),
('0000000000380', 'Old_bike_TK_CIV_EP1', '[275,[16325.9,13604.8,0]]', 'Martin'),
('0000000000381', 'MMT_Civ', '[271,[16326.1,13608.2,0]]', 'Martin'),
('0000000000382', 'SUV_Special', '[184,[16247.6,11578.6,0]]', 'Dubovo'),
('0000000000383', 'hilux1_civil_3_open_EP1', '[90,[16163,11495.5,0]]', 'Dubovo'),
('0000000000384', 'ATV_CZ_EP1', '[270,[16195.2,11601.9,0]]', 'Dubovo'),
('0000000000386', 'rth_ScrapApc', '[120,[15197.7,7772.87,0]]', 'Boye'),
('0000000000387', 'ATV_CZ_EP1', '[2,[16310.1,7380.83,0]]', 'Krushevich'),
('0000000000388', 'rth_ScrapApc', '[78,[16464.1,9770.87,0]]', ''),
('0000500000389', 'UH1H_DZ', '[182,[22689,19845,0]]', 'Sektor B'),
('0000500000390', 'Mi17_DZ', '[232,[22707.3,19614.5,0]]', 'Sektor B'),
('0000500000391', 'Mi17_DZ', '[2,[22689.2,19196,0]]', 'Sektor B Start AirF'),
('0000500000392', 'UH1H_DZ', '[219,[22552.3,19667.4,0]]', 'Sektor B'),
('0000500000393', 'rth_ScrapApc', '[95,[22558.3,19687.5,0]]', 'Sektor B Bonus'),
('0000500000394', 'rth_ScrapApc', '[309,[22741,19305.5,0]]', 'Sektor B Bonus'),
('0000500000395', 'rth_ScrapApc', '[221,[22750.3,19468.2,0]]', 'Sektor B Bonus'),
('0000500000396', 'rth_raft', '[7,[21902.6,19331.9,0]]', 'Sektor B Bereg'),
('0000500000397', 'rth_raft_small', '[38,[21774.4,19523.4,0]]', 'Sektor B Bereg'),
('0000500000398', 'rth_raft', '[29,[21770.2,19821.1,0]]', 'Sektor B Bereg'),
('0000500000399', 'rth_amphicar', '[78,[21979.7,20095.1,0]]', 'Sektor B Bereg'),
('0000500000400', 'rth_raft', '[42,[22818.6,20391.5,0]]', 'Sektor B Bereg'),
('0000500000401', 'rth_raft_small', '[233,[23116.7,20111,0]]', 'Sektor B Bereg'),
('0000500000402', 'rth_raft', '[35,[23262.6,19802.5,0]]', 'Sektor B Bereg'),
('0000500000403', 'rth_amphicar', '[121,[23300.9,19463.1,0]]', 'Sektor B Bereg'),
('0000500000404', 'rth_raft', '[9,[23283.1,19244.2,0]]', 'Sektor B Bereg'),
('0000500000405', 'rth_raft_small', '[0,[22964.3,18910.3,0]]', 'Sektor B Bereg'),
('0000500000406', 'rth_amphicar', '[0,[22516.5,18786.4,0]]', 'Sektor B Bereg'),
('0000500000407', 'rth_raft', '[134,[10265.7,16715.5,0]]', 'Lubol'),
('0000500000408', 'rth_raft_small', '[0,[10656.3,16642.5,0]]', 'Lubol'),
('0000500000409', 'rth_raft', '[0,[9465.59,14576.5,0]]', 'Proliv Lubol'),
('0000500000410', 'rth_raft_small', '[192,[9886.85,14238.4,0]]', 'Proliv Lubol'),
('0000500000411', 'rth_raft', '[0,[7833.28,19173.6,0]]', NULL),
('0000500000412', 'rth_raft_small', '[0,[7549.65,20378.8,0]]', NULL),
('0000500000413', 'rth_raft', '[80,[7302.73,21060.3,0]]', NULL),
('0000500000414', 'rth_raft_small', '[0,[17136.3,14103.9,0]]', NULL),
('0000500000415', 'rth_raft', '[243,[16220.8,16089.3,0]]', NULL),
('0000500000416', 'rth_raft_small', '[357,[15392.6,18204.7,0]]', NULL),
('0000500000417', 'rth_raft', '[0,[2451.93,8157.98,0]]', NULL),
('0000500000418', 'rth_copter_yellow', '[0,[4632.15,6349.35,0]]', ''),
('0000500000419', 'rth_copter_yellow', '[0,[4349.91,8068.19,0]]', NULL),
('0000500000420', 'rth_copter_yellow', '[210,[5471.15,8590.72,0]]', NULL),
('0000500000421', 'rth_copter_yellow', '[94,[8352.01,20842.8,0]]', NULL),
('0000500000422', 'rth_copter_yellow', '[0,[9946.07,18675.1,0]]', NULL),
('0000500000423', 'rth_copter_yellow', '[339,[10449.6,17614.4,0]]', NULL),
('0000500000424', 'rth_copter_green', '[234,[13036.3,14384,0]]', 'g'),
('0000500000425', 'rth_copter_green', '[358,[15142.1,15854.1,0]]', NULL),
('0000500000426', 'rth_copter_green', '[312,[16438.4,10382.3,0]]', NULL),
('0000500000427', 'rth_ScrapBuggy', '[66,[17097.7,7822.61,0]]', NULL),
('0000500000428', 'rth_ScrapBuggy', '[126,[17475.1,6208.98,0]]', NULL),
('0000500000429', 'rth_ScrapBuggy', '[85,[16808.1,12630,0]]', NULL),
('0000500000430', 'rth_ScrapBuggy', '[57,[15213.1,17015.3,0]]', NULL),
('0000500000431', 'DC3', '[20,[22852.6,19182.4,0]]', 'Sector B'),
('0000500000432', 'ori_vil_truck_civ2', '[233,[5102.6,6293.02,0]]', NULL),
('0000500000433', 'ori_vil_lublin_truck', '[148,[4715.7,8207.52,0]]', NULL),
('0000500000434', 'ori_vil_truck_civ1', '[267,[3426.43,7807.62,0]]', NULL),
('0000500000435', 'ori_vil_volvo_fl290', '[172,[7452.45,4101.49,0]]', NULL),
('0000500000436', 'ori_vil_truck_civ', '[252,[7834.52,4532.11,0]]', NULL),
('0000500000437', 'p85_cucv_pickup', '[236,[8150.87,4992.57,0]]', 'small car'),
('0000500000438', 'ori_p85_cucv', '[145,[8238.77,5015.45,0]]', NULL),
('0000500000439', 'p85_cucv_pickup', '[232,[8157.2,5024.86,0]]', NULL),
('0000500000440', 'ori_p85_cucv', '[169,[11435.5,671.487,0]]', NULL),
('0000500000441', 'ori_vil_truck_civ1', '[231,[11840.4,1420.83,0]]', NULL),
('0000500000442', 'ori_vil_volvo_fl290', '[313,[10940.7,2128.72,0]]', NULL),
('0000500000443', 'ori_p85_cucv', '[134,[9547.76,5737.86,0]]', 'small car'),
('0000500000444', 'ori_vil_truck_civ', '[49,[8806.59,8242.25,0]]', NULL),
('0000500000445', 'ori_vil_lublin_truck', '[144,[12459.6,11796.2,0]]', NULL),
('0000500000446', 'ori_vil_truck_civ1', '[142,[12605.4,12006.2,0]]', NULL),
('0000500000447', 'ori_p85_cucv', '[72,[12791.6,11999.2,0]]', 'small car'),
('0000500000448', 'p85_cucv_pickup', '[4,[12786.1,11704.3,0]]', 'small car'),
('0000500000449', 'ori_vil_lublin_truck', '[289,[17224.3,6902.72,0]]', NULL),
('0000500000450', 'ori_vil_truck_civ2', '[0,[17424.9,7501.15,0]]', NULL),
('0000500000451', 'ori_vil_volvo_fl290', '[93,[17407.3,7677.6,0]]', 'p'),
('0000500000452', 'ori_vil_truck_civ', '[94,[16302.2,8816.24,0]]', NULL),
('0000500000453', 'ori_vil_truck_civ1', '[73,[15118.6,14785.2,0]]', NULL),
('0000500000454', 'p85_cucv_pickup', '[83,[15087.1,14873.6,0]]', 'small car'),
('0000500000455', 'ori_vil_volvo_fl290', '[289,[15137,14910.4,0]]', 'p'),
('0000500000456', 'ori_vil_truck_civ2', '[90,[15359.8,16423.4,0]]', NULL),
('0000500000457', 'ori_vil_lublin_truck', '[24,[15569.1,16019.5,0]]', NULL),
('0000500000458', 'ori_vil_truck_civ', '[262,[11876.8,18618.3,0]]', NULL),
('0000500000459', 'p85_cucv_pickup', '[268,[9009.84,19351.9,0]]', NULL),
('0000500000460', 'ori_vil_truck_civ2', '[156,[10109.1,18055.1,0]]', NULL),
('0000500000461', 'ori_vil_volvo_fl290', '[319,[10622.9,17315.7,0]]', 'p'),
('0000500000462', 'ori_vil_volvo_fl290', '[102,[10145.1,18735.2,0]]', 'p'),
('0000500000463', 'rth_amphicar', '[0,[11519.7,329.167,0]]', NULL),
('0000500000464', 'rth_amphicar', '[345,[10089.3,3713.94,0]]', NULL),
('0000500000465', 'rth_amphicar', '[0,[5207,5616.89,0]]', NULL),
('0000500000466', 'rth_amphicar', '[358,[8715.87,9137.31,0]]', NULL),
('0000500000467', 'rth_amphicar', '[46,[10235.4,7841.43,0]]', NULL),
('0000500000468', 'rth_amphicar', '[110,[15899.5,10823.5,0]]', NULL),
('0000500000469', 'rth_amphicar', '[160,[17420.1,13182,0]]', NULL),
('0000500000470', 'rth_amphicar', '[96,[15174.1,17240.7,0]]', NULL),
('0000500000471', 'rth_amphicar', '[277,[11496.3,18552.3,0]]', NULL),
('0000500000472', 'rth_amphicar', '[14,[10834.3,14053,0]]', NULL),
('0000500000473', 'rth_amphicar', '[238,[9198.25,21524.6,0]]', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `player_data`
--

CREATE TABLE IF NOT EXISTS `player_data` (
  `PlayerUID` varchar(20) NOT NULL DEFAULT '',
  `PlayerName` varchar(128) NOT NULL DEFAULT '',
  `PlayerMorality` int(11) DEFAULT NULL,
  `PlayerSex` tinyint(3) DEFAULT NULL,
  `Datetime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PlayerUID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `player_data`
--

INSERT INTO `player_data` (`PlayerUID`, `PlayerName`, `PlayerMorality`, `PlayerSex`, `Datetime`) VALUES
('159122886', 'Sitto', NULL, NULL, NULL),
('159165638', 'Leroy Jenkins', NULL, NULL, NULL),
('162616006', 'Brolo', NULL, NULL, NULL),
('234775174', 'player2891', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `player_login`
--

CREATE TABLE IF NOT EXISTS `player_login` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PlayerUID` varchar(20) DEFAULT '',
  `CharacterID` int(11) DEFAULT NULL,
  `Action` tinyint(3) NOT NULL DEFAULT '0',
  `Datestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=375 ;

--
-- Volcado de datos para la tabla `player_login`
--

INSERT INTO `player_login` (`ID`, `PlayerUID`, `CharacterID`, `Action`, `Datestamp`) VALUES
(1, '159165638', 2, 0, '2014-01-15 20:42:01'),
(2, '159122886', 1, 0, '2014-01-15 20:42:02'),
(3, '159165638', 2, 2, '2014-01-15 21:09:49'),
(4, '159165638', 2, 0, '2014-01-15 21:12:47'),
(5, '159165638', 2, 2, '2014-01-15 21:57:57'),
(6, '159165638', 2, 0, '2014-01-15 22:39:00'),
(7, '159165638', 2, 2, '2014-01-15 22:42:28'),
(8, '159165638', 2, 0, '2014-01-15 22:46:15'),
(9, '159165638', 2, 2, '2014-01-16 00:08:35'),
(10, '159122886', 1, 2, '2014-01-16 03:15:35'),
(11, '159122886', 1, 0, '2014-01-16 03:20:24'),
(12, '159122886', 1, 2, '2014-01-16 03:32:59'),
(13, '159122886', 1, 0, '2014-01-16 13:54:57'),
(14, '159122886', 1, 2, '2014-01-16 14:06:40'),
(15, '159122886', 1, 0, '2014-01-16 14:50:47'),
(16, '159122886', 1, 2, '2014-01-16 14:58:02'),
(17, '159122886', 1, 0, '2014-01-16 15:40:39'),
(18, '159122886', 1, 2, '2014-01-16 15:41:22'),
(19, '159122886', 1, 0, '2014-01-16 16:35:22'),
(20, '159122886', 1, 2, '2014-01-16 16:37:06'),
(21, '159122886', 1, 0, '2014-01-16 18:56:27'),
(22, '159165638', 2, 0, '2014-01-16 19:43:40'),
(23, '159165638', 2, 2, '2014-01-16 20:06:21'),
(24, '159122886', 1, 2, '2014-01-16 20:11:35'),
(25, '159122886', 1, 0, '2014-01-16 20:31:32'),
(26, '159122886', 1, 2, '2014-01-16 20:35:41'),
(27, '159122886', 1, 0, '2014-01-16 20:46:08'),
(28, '159122886', 1, 2, '2014-01-16 21:50:09'),
(29, '159122886', 1, 0, '2014-01-17 15:26:59'),
(30, '159122886', 1, 2, '2014-01-17 15:29:10'),
(31, '159122886', 1, 0, '2014-01-17 15:38:23'),
(32, '159122886', 1, 2, '2014-01-17 15:40:13'),
(33, '159122886', 1, 0, '2014-01-17 15:47:04'),
(34, '159122886', 1, 2, '2014-01-17 15:49:07'),
(35, '159122886', 1, 0, '2014-01-17 18:06:04'),
(36, '159122886', 3, 0, '2014-01-17 18:25:55'),
(37, '159122886', 3, 0, '2014-01-17 18:31:50'),
(38, '159122886', 4, 0, '2014-01-17 18:47:37'),
(39, '159122886', 4, 2, '2014-01-17 19:02:11'),
(40, '159122886', 4, 0, '2014-01-17 21:15:34'),
(41, '159122886', 4, 2, '2014-01-17 21:15:50'),
(42, '159122886', 4, 0, '2014-01-17 21:18:57'),
(43, '159122886', 4, 2, '2014-01-17 21:24:26'),
(44, '159122886', 4, 0, '2014-01-17 21:58:20'),
(45, '159122886', 4, 2, '2014-01-17 22:18:43'),
(46, '159122886', 4, 0, '2014-01-17 22:32:36'),
(47, '159122886', 4, 2, '2014-01-17 22:37:11'),
(48, '159122886', 6, 0, '2014-01-17 23:02:13'),
(49, '162616006', 5, 0, '2014-01-17 23:02:15'),
(50, '162616006', 5, 2, '2014-01-17 23:22:11'),
(51, '159165638', 2, 0, '2014-01-18 00:08:23'),
(52, '159122886', 6, 2, '2014-01-18 01:17:50'),
(53, '159122886', 6, 0, '2014-01-18 01:19:20'),
(54, '159122886', 6, 2, '2014-01-18 01:24:11'),
(55, '159165638', 2, 2, '2014-01-18 01:24:11'),
(56, '159122886', 7, 0, '2014-01-18 01:31:34'),
(57, '159165638', 8, 0, '2014-01-18 01:33:53'),
(58, '159122886', 7, 2, '2014-01-18 02:07:33'),
(59, '159165638', 8, 2, '2014-01-18 02:07:34'),
(60, '159165638', 8, 0, '2014-01-18 02:11:45'),
(61, '159122886', 7, 0, '2014-01-18 02:11:49'),
(62, '159165638', 8, 2, '2014-01-18 03:39:30'),
(63, '159122886', 7, 2, '2014-01-18 03:39:57'),
(64, '159165638', 8, 0, '2014-01-18 03:41:02'),
(65, '159122886', 7, 0, '2014-01-18 03:41:29'),
(66, '159122886', 7, 2, '2014-01-18 03:41:43'),
(67, '159165638', 8, 2, '2014-01-18 03:42:08'),
(68, '159122886', 7, 0, '2014-01-18 04:03:58'),
(69, '159122886', 7, 2, '2014-01-18 04:41:58'),
(70, '159122886', 7, 0, '2014-01-18 11:30:34'),
(71, '159122886', 7, 2, '2014-01-18 11:40:01'),
(72, '159122886', 7, 0, '2014-01-18 12:54:09'),
(73, '159122886', 7, 2, '2014-01-18 13:21:45'),
(74, '159122886', 7, 0, '2014-01-18 13:24:50'),
(75, '159122886', 7, 2, '2014-01-18 14:36:49'),
(76, '159122886', 7, 0, '2014-01-18 15:53:23'),
(77, '159122886', 7, 2, '2014-01-18 15:55:47'),
(78, '159122886', 7, 0, '2014-01-18 16:03:43'),
(79, '159122886', 7, 2, '2014-01-18 16:04:44'),
(80, '159122886', 7, 0, '2014-01-18 16:17:10'),
(81, '159122886', 7, 2, '2014-01-18 16:20:54'),
(82, '159122886', 7, 0, '2014-01-18 16:35:54'),
(83, '159122886', 7, 2, '2014-01-18 16:38:23'),
(84, '159122886', 7, 0, '2014-01-18 16:43:24'),
(85, '159122886', 7, 2, '2014-01-18 16:44:56'),
(86, '159122886', 7, 0, '2014-01-18 16:57:27'),
(87, '159122886', 7, 2, '2014-01-18 16:58:57'),
(88, '159122886', 7, 0, '2014-01-18 17:04:40'),
(89, '159122886', 7, 2, '2014-01-18 17:06:04'),
(90, '159122886', 7, 0, '2014-01-18 17:10:01'),
(91, '159122886', 7, 2, '2014-01-18 17:10:58'),
(92, '159122886', 7, 0, '2014-01-18 17:14:56'),
(93, '159122886', 7, 2, '2014-01-18 17:23:43'),
(94, '159122886', 7, 0, '2014-01-18 17:33:48'),
(95, '159122886', 7, 2, '2014-01-18 17:36:56'),
(96, '159122886', 7, 0, '2014-01-18 17:43:33'),
(97, '159122886', 7, 2, '2014-01-18 17:46:27'),
(98, '159122886', 7, 0, '2014-01-18 17:51:04'),
(99, '159122886', 7, 2, '2014-01-18 17:51:39'),
(100, '159122886', 7, 0, '2014-01-18 17:57:58'),
(101, '159122886', 7, 2, '2014-01-18 17:58:23'),
(102, '159165638', 8, 0, '2014-01-18 18:05:00'),
(103, '159122886', 7, 0, '2014-01-18 18:05:50'),
(104, '159122886', 9, 0, '2014-01-18 18:09:23'),
(105, '159165638', 8, 2, '2014-01-18 19:05:42'),
(106, '159122886', 9, 2, '2014-01-18 19:05:42'),
(107, '159122886', 9, 0, '2014-01-18 19:14:53'),
(108, '159165638', 8, 0, '2014-01-18 19:16:27'),
(109, '162616006', 5, 0, '2014-01-18 20:01:19'),
(110, '159165638', 10, 0, '2014-01-18 20:01:34'),
(111, '159122886', 11, 0, '2014-01-18 20:02:20'),
(112, '159122886', 11, 2, '2014-01-18 20:03:09'),
(113, '162616006', 5, 2, '2014-01-18 20:03:14'),
(114, '159122886', 11, 0, '2014-01-18 20:09:02'),
(115, '162616006', 5, 0, '2014-01-18 20:10:27'),
(116, '159165638', 10, 0, '2014-01-18 20:13:42'),
(117, '162616006', 5, 2, '2014-01-18 20:16:41'),
(118, '159122886', 11, 2, '2014-01-18 20:16:42'),
(119, '159122886', 11, 0, '2014-01-18 20:23:25'),
(120, '162616006', 5, 0, '2014-01-18 20:23:28'),
(121, '159165638', 12, 0, '2014-01-18 20:23:40'),
(122, '159122886', 13, 0, '2014-01-18 20:36:13'),
(123, '159122886', 13, 2, '2014-01-18 20:39:17'),
(124, '159122886', 13, 0, '2014-01-18 20:41:51'),
(125, '162616006', 14, 0, '2014-01-18 21:24:09'),
(126, '159165638', 12, 2, '2014-01-18 21:25:43'),
(127, '159122886', 13, 2, '2014-01-18 21:29:04'),
(128, '162616006', 14, 2, '2014-01-18 21:30:35'),
(129, '159122886', 13, 0, '2014-01-18 22:07:15'),
(130, '159122886', 13, 2, '2014-01-18 22:34:16'),
(131, '159122886', 13, 0, '2014-01-18 22:41:22'),
(132, '162616006', 14, 0, '2014-01-18 22:59:01'),
(133, '159122886', 15, 0, '2014-01-18 23:35:20'),
(134, '162616006', 16, 0, '2014-01-18 23:35:28'),
(135, '162616006', 16, 0, '2014-01-19 00:01:37'),
(136, '159122886', 15, 2, '2014-01-19 00:38:57'),
(137, '162616006', 16, 2, '2014-01-19 00:38:59'),
(138, '159122886', 15, 0, '2014-01-19 00:56:08'),
(139, '159122886', 15, 2, '2014-01-19 00:57:42'),
(140, '159122886', 15, 0, '2014-01-19 11:17:56'),
(141, '159165638', 12, 0, '2014-01-19 11:53:38'),
(142, '159122886', 15, 2, '2014-01-19 12:05:27'),
(143, '159165638', 12, 2, '2014-01-19 12:05:56'),
(144, '159165638', 12, 0, '2014-01-19 12:09:31'),
(145, '159122886', 15, 0, '2014-01-19 12:11:08'),
(146, '159165638', 12, 2, '2014-01-19 12:35:05'),
(147, '159122886', 15, 2, '2014-01-19 12:35:12'),
(148, '159122886', 15, 0, '2014-01-19 12:43:42'),
(149, '159165638', 12, 0, '2014-01-19 12:44:52'),
(150, '159165638', 12, 2, '2014-01-19 13:05:07'),
(151, '159122886', 15, 2, '2014-01-19 13:06:27'),
(152, '159122886', 15, 0, '2014-01-19 13:13:58'),
(153, '159165638', 12, 2, '2014-01-19 13:20:29'),
(154, '159165638', 12, 0, '2014-01-19 13:25:09'),
(155, '159165638', 17, 2, '2014-01-19 13:28:14'),
(156, '159165638', 17, 0, '2014-01-19 13:29:31'),
(157, '159165638', 17, 2, '2014-01-19 14:06:07'),
(158, '159165638', 17, 0, '2014-01-19 15:43:12'),
(159, '159165638', 18, 0, '2014-01-19 17:08:52'),
(160, '162616006', 16, 0, '2014-01-19 17:45:18'),
(161, '162616006', 16, 2, '2014-01-19 18:09:29'),
(162, '159122886', 15, 2, '2014-01-19 18:09:48'),
(163, '159165638', 18, 2, '2014-01-19 18:09:51'),
(164, '162616006', 16, 0, '2014-01-19 18:12:47'),
(165, '159122886', 15, 0, '2014-01-19 18:12:49'),
(166, '159165638', 18, 0, '2014-01-19 18:12:49'),
(167, '159165638', 18, 2, '2014-01-19 18:52:03'),
(168, '159122886', 15, 2, '2014-01-19 18:56:41'),
(169, '162616006', 16, 2, '2014-01-19 18:56:48'),
(170, '159165638', 18, 0, '2014-01-20 19:09:49'),
(171, '159165638', 18, 0, '2014-01-20 20:02:12'),
(172, '159165638', 18, 2, '2014-01-20 20:33:58'),
(173, '159165638', 18, 0, '2014-01-20 20:37:49'),
(174, '159122886', 15, 0, '2014-01-20 20:37:50'),
(175, '159122886', 15, 2, '2014-01-20 20:39:39'),
(176, '159165638', 18, 2, '2014-01-20 20:46:34'),
(177, '159122886', 15, 0, '2014-01-20 21:20:03'),
(178, '159165638', 18, 0, '2014-01-20 21:20:36'),
(179, '159122886', 15, 2, '2014-01-20 21:21:31'),
(180, '159165638', 18, 2, '2014-01-20 21:21:39'),
(181, '159122886', 15, 0, '2014-01-20 21:30:03'),
(182, '159122886', 15, 2, '2014-01-20 21:35:48'),
(183, '159122886', 15, 0, '2014-01-20 21:46:45'),
(184, '159122886', 15, 0, '2014-01-20 21:52:38'),
(185, '159122886', 15, 0, '2014-01-20 22:05:33'),
(186, '159122886', 15, 0, '2014-01-20 22:10:41'),
(187, '159122886', 15, 0, '2014-01-20 22:29:28'),
(188, '159122886', 15, 0, '2014-01-20 22:59:00'),
(189, '159122886', 15, 0, '2014-01-20 23:19:38'),
(190, '159122886', 15, 0, '2014-01-20 23:42:37'),
(191, '159122886', 15, 2, '2014-01-21 00:17:42'),
(192, '159122886', 15, 0, '2014-01-21 00:18:52'),
(193, '159122886', 15, 2, '2014-01-21 00:42:12'),
(194, '159122886', 15, 0, '2014-01-21 14:54:16'),
(195, '159122886', 15, 2, '2014-01-21 15:03:02'),
(196, '159122886', 15, 0, '2014-01-21 15:26:47'),
(197, '159122886', 15, 2, '2014-01-21 15:30:09'),
(198, '159165638', 18, 0, '2014-01-21 19:01:39'),
(199, '159165638', 18, 2, '2014-01-21 19:03:12'),
(200, '159165638', 18, 0, '2014-01-21 19:04:51'),
(201, '159165638', 18, 2, '2014-01-21 19:05:44'),
(202, '159165638', 18, 0, '2014-01-21 19:08:04'),
(203, '159165638', 18, 2, '2014-01-21 19:15:46'),
(204, '159165638', 18, 0, '2014-01-21 20:01:48'),
(205, '159122886', 15, 0, '2014-01-21 20:04:22'),
(206, '159122886', 15, 2, '2014-01-21 20:23:06'),
(207, '159165638', 18, 2, '2014-01-21 20:23:09'),
(208, '159165638', 18, 0, '2014-01-21 20:32:58'),
(209, '159122886', 15, 0, '2014-01-21 20:32:59'),
(210, '159122886', 15, 2, '2014-01-21 21:04:47'),
(211, '159122886', 15, 0, '2014-01-21 21:06:08'),
(212, '159165638', 18, 2, '2014-01-21 21:19:33'),
(213, '159122886', 15, 2, '2014-01-21 21:22:58'),
(214, '159122886', 15, 0, '2014-01-21 23:16:51'),
(215, '159122886', 15, 2, '2014-01-21 23:18:25'),
(216, '159122886', 15, 0, '2014-01-21 23:52:35'),
(217, '159122886', 19, 0, '2014-01-22 00:39:01'),
(218, '159122886', 19, 0, '2014-01-22 00:50:27'),
(219, '159122886', 19, 0, '2014-01-22 01:09:00'),
(220, '159122886', 20, 0, '2014-01-22 15:25:05'),
(221, '162616006', 16, 0, '2014-01-22 21:14:59'),
(222, '159122886', 21, 0, '2014-01-22 21:16:55'),
(223, '162616006', 22, 0, '2014-01-22 21:55:25'),
(224, '159122886', 23, 0, '2014-01-22 21:59:47'),
(225, '159122886', 24, 0, '2014-01-22 22:03:06'),
(226, '159122886', 25, 0, '2014-01-22 22:08:22'),
(227, '159122886', 25, 2, '2014-01-22 22:22:09'),
(228, '162616006', 22, 2, '2014-01-22 22:22:52'),
(229, '159122886', 25, 0, '2014-01-22 22:40:03'),
(230, '159122886', 25, 2, '2014-01-22 23:26:01'),
(231, '159165638', 18, 0, '2014-01-23 19:06:02'),
(232, '162616006', 22, 0, '2014-01-23 20:14:10'),
(233, '159122886', 25, 0, '2014-01-23 20:20:59'),
(234, '159165638', 18, 2, '2014-01-23 21:15:18'),
(235, '159122886', 26, 0, '2014-01-23 21:18:04'),
(236, '162616006', 22, 2, '2014-01-23 21:27:26'),
(237, '159122886', 27, 0, '2014-01-24 17:59:21'),
(238, '159122886', 27, 2, '2014-01-24 18:01:02'),
(239, '159122886', 27, 0, '2014-01-24 19:00:52'),
(240, '159165638', 18, 0, '2014-01-24 19:02:55'),
(241, '159122886', 27, 2, '2014-01-24 19:27:08'),
(242, '159165638', 18, 2, '2014-01-24 19:31:03'),
(243, '159122886', 27, 0, '2014-01-24 19:35:50'),
(244, '159165638', 18, 0, '2014-01-24 19:50:00'),
(245, '159165638', 28, 0, '2014-01-24 19:55:03'),
(246, '159165638', 29, 0, '2014-01-24 21:09:57'),
(247, '159122886', 30, 0, '2014-01-24 22:40:44'),
(248, '159122886', 30, 2, '2014-01-24 23:58:09'),
(249, '159165638', 29, 2, '2014-01-24 23:58:18'),
(250, '159165638', 29, 0, '2014-01-25 00:00:19'),
(251, '159122886', 30, 0, '2014-01-25 00:01:28'),
(252, '159122886', 30, 0, '2014-01-25 00:38:12'),
(253, '159122886', 31, 0, '2014-01-25 00:47:38'),
(254, '159122886', 32, 0, '2014-01-25 00:55:23'),
(255, '159122886', 32, 2, '2014-01-25 01:12:06'),
(256, '159122886', 32, 0, '2014-01-25 12:53:15'),
(257, '159165638', 29, 0, '2014-01-25 12:53:56'),
(258, '159165638', 33, 0, '2014-01-25 14:54:35'),
(259, '159122886', 34, 0, '2014-01-25 14:55:20'),
(260, '159165638', 33, 2, '2014-01-25 15:10:25'),
(261, '159122886', 34, 2, '2014-01-25 15:11:24'),
(262, '162616006', 22, 0, '2014-01-25 16:44:32'),
(263, '159122886', 34, 0, '2014-01-25 16:44:32'),
(264, '159165638', 33, 0, '2014-01-25 17:19:17'),
(265, '162616006', 22, 2, '2014-01-25 17:30:07'),
(266, '159122886', 35, 0, '2014-01-25 19:18:32'),
(267, '159165638', 33, 2, '2014-01-25 21:04:03'),
(268, '159122886', 35, 2, '2014-01-25 21:12:40'),
(269, '159122886', 35, 0, '2014-01-26 11:13:10'),
(270, '159122886', 35, 2, '2014-01-26 11:13:38'),
(271, '159122886', 35, 0, '2014-01-26 11:14:53'),
(272, '159122886', 35, 2, '2014-01-26 11:22:01'),
(273, '159122886', 35, 0, '2014-01-26 11:33:15'),
(274, '159165638', 33, 0, '2014-01-26 11:47:33'),
(275, '159165638', 36, 0, '2014-01-26 12:18:59'),
(276, '159122886', 37, 0, '2014-01-26 12:40:08'),
(277, '162616006', 22, 0, '2014-01-26 13:12:17'),
(278, '162616006', 22, 2, '2014-01-26 13:40:29'),
(279, '159165638', 36, 2, '2014-01-26 13:40:45'),
(280, '159122886', 37, 0, '2014-01-26 13:42:43'),
(281, '159165638', 36, 0, '2014-01-26 13:42:45'),
(282, '162616006', 22, 0, '2014-01-26 13:44:07'),
(283, '159165638', 36, 2, '2014-01-26 14:37:56'),
(284, '162616006', 22, 2, '2014-01-26 15:42:32'),
(285, '159122886', 37, 2, '2014-01-26 15:43:49'),
(286, '159122886', 37, 0, '2014-01-26 17:04:27'),
(287, '159122886', 37, 2, '2014-01-26 17:04:33'),
(288, '159122886', 37, 0, '2014-01-26 17:10:23'),
(289, '159122886', 37, 2, '2014-01-26 17:10:29'),
(290, '159122886', 37, 0, '2014-01-26 17:15:07'),
(291, '159122886', 37, 0, '2014-01-26 17:35:01'),
(292, '159165638', 36, 0, '2014-01-26 17:36:48'),
(293, '159165638', 36, 2, '2014-01-26 18:09:56'),
(294, '159165638', 36, 0, '2014-01-26 18:15:04'),
(295, '159122886', 37, 0, '2014-01-26 18:15:07'),
(296, '159165638', 36, 2, '2014-01-26 20:30:36'),
(297, '159165638', 36, 0, '2014-01-26 20:32:13'),
(298, '159165638', 36, 2, '2014-01-26 20:34:44'),
(299, '159122886', 38, 0, '2014-01-26 21:50:22'),
(300, '162616006', 22, 0, '2014-01-26 21:53:05'),
(301, '159122886', 39, 0, '2014-01-26 22:14:07'),
(302, '159165638', 36, 0, '2014-01-27 19:45:34'),
(303, '159165638', 36, 2, '2014-01-27 19:47:57'),
(304, '159165638', 36, 0, '2014-01-28 20:26:45'),
(305, '159165638', 36, 2, '2014-01-28 20:28:23'),
(306, '159165638', 36, 0, '2014-01-28 20:35:53'),
(307, '159165638', 36, 2, '2014-01-28 20:36:05'),
(308, '159165638', 36, 0, '2014-01-28 20:58:17'),
(309, '159122886', 40, 0, '2014-01-28 20:58:20'),
(310, '234775174', 41, 0, '2014-01-28 20:59:04'),
(311, '234775174', 42, 0, '2014-01-28 21:05:17'),
(312, '159165638', 36, 2, '2014-01-28 21:05:19'),
(313, '159122886', 43, 0, '2014-01-28 22:38:18'),
(314, '234775174', 42, 2, '2014-01-28 22:49:55'),
(315, '159122886', 43, 2, '2014-01-28 22:49:59'),
(316, '159122886', 43, 0, '2014-01-29 20:01:19'),
(317, '159122886', 43, 2, '2014-01-29 20:02:21'),
(318, '159122886', 43, 0, '2014-01-29 20:06:27'),
(319, '159165638', 36, 0, '2014-01-29 20:08:06'),
(320, '159122886', 43, 2, '2014-01-29 20:41:28'),
(321, '159165638', 36, 2, '2014-01-29 20:41:41'),
(322, '234775174', 42, 0, '2014-01-29 21:29:26'),
(323, '159122886', 43, 0, '2014-01-29 21:29:29'),
(324, '162616006', 22, 0, '2014-01-29 21:29:35'),
(325, '159165638', 36, 0, '2014-01-29 21:30:05'),
(326, '159165638', 36, 2, '2014-01-29 21:30:47'),
(327, '162616006', 22, 2, '2014-01-29 21:54:30'),
(328, '234775174', 44, 0, '2014-01-29 22:43:59'),
(329, '234775174', 44, 2, '2014-01-29 22:54:36'),
(330, '159122886', 43, 2, '2014-01-29 22:58:17'),
(331, '159122886', 43, 0, '2014-01-29 23:03:25'),
(332, '159122886', 43, 2, '2014-01-29 23:03:41'),
(333, '159122886', 43, 0, '2014-01-29 23:15:17'),
(334, '159122886', 45, 0, '2014-01-29 23:34:20'),
(335, '159122886', 45, 2, '2014-01-29 23:45:21'),
(336, '159122886', 45, 0, '2014-01-30 00:04:12'),
(337, '159122886', 45, 2, '2014-01-30 00:04:39'),
(338, '159122886', 45, 0, '2014-01-30 00:11:46'),
(339, '159122886', 45, 0, '2014-01-30 00:15:27'),
(340, '159122886', 45, 2, '2014-01-30 00:15:51'),
(341, '159122886', 45, 0, '2014-01-30 00:35:08'),
(342, '159122886', 45, 2, '2014-01-30 00:35:51'),
(343, '159122886', 45, 0, '2014-01-30 22:35:47'),
(344, '234775174', 44, 0, '2014-01-30 22:45:38'),
(345, '159122886', 46, 0, '2014-01-30 22:50:50'),
(346, '159122886', 47, 0, '2014-01-30 23:12:07'),
(347, '234775174', 48, 0, '2014-01-30 23:13:20'),
(348, '159122886', 47, 2, '2014-01-31 00:13:32'),
(349, '234775174', 48, 2, '2014-01-31 00:13:37'),
(350, '159122886', 47, 0, '2014-01-31 17:26:31'),
(351, '159122886', 47, 2, '2014-01-31 17:26:37'),
(352, '159122886', 47, 0, '2014-01-31 17:29:39'),
(353, '159122886', 47, 2, '2014-01-31 17:29:49'),
(354, '159122886', 47, 0, '2014-01-31 17:33:51'),
(355, '159122886', 47, 2, '2014-01-31 17:34:02'),
(356, '159122886', 47, 0, '2014-01-31 17:44:53'),
(357, '159122886', 47, 0, '2014-01-31 17:49:11'),
(358, '159122886', 47, 2, '2014-01-31 17:49:14'),
(359, '159122886', 47, 0, '2014-01-31 17:57:15'),
(360, '159122886', 47, 2, '2014-01-31 17:57:20'),
(361, '159122886', 47, 0, '2014-01-31 18:46:15'),
(362, '159122886', 47, 2, '2014-01-31 18:46:58'),
(363, '159122886', 47, 0, '2014-01-31 19:11:19'),
(364, '159122886', 47, 2, '2014-01-31 19:11:26'),
(365, '159122886', 47, 0, '2014-01-31 19:17:07'),
(366, '159122886', 47, 2, '2014-01-31 19:17:12'),
(367, '159122886', 47, 0, '2014-01-31 19:45:11'),
(368, '159122886', 47, 2, '2014-01-31 19:46:51'),
(369, '159122886', 47, 0, '2014-01-31 19:51:51'),
(370, '159122886', 47, 2, '2014-01-31 19:52:34'),
(371, '159122886', 47, 0, '2014-01-31 20:00:46'),
(372, '159122886', 47, 2, '2014-01-31 20:08:14'),
(373, '159122886', 47, 0, '2014-01-31 20:30:29'),
(374, '159122886', 47, 2, '2014-01-31 20:33:32');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
